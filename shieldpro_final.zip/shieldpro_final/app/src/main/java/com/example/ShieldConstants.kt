package com.example

object ShieldConstants {
    const val PREF_NAME = "shieldpro_prefs"

    // Daily counters
    const val KEY_ADS_TODAY       = "ads_skipped_today"
    const val KEY_ADULT_TODAY     = "adult_blocked_today"
    const val KEY_REELS_TODAY     = "reels_blocked_today"

    // All-time totals
    const val KEY_ADS_TOTAL       = "ads_skipped_total"
    const val KEY_ADULT_TOTAL     = "adult_blocked_total"
    const val KEY_REELS_TOTAL     = "reels_blocked_total"

    // Date for daily reset
    const val KEY_LAST_RESET      = "last_reset_date"

    // Custom keyword list (Set<String>)
    const val KEY_CUSTOM_ADULT    = "custom_adult_keywords"

    // Whitelist (Set<String> of package names)
    const val KEY_WHITELIST       = "whitelist_packages"

    // PIN
    const val KEY_PIN_ENABLED     = "pin_enabled"
    const val KEY_PIN_HASH        = "pin_hash"

    // Schedule lock
    const val KEY_SCHEDULE_ON     = "schedule_lock_enabled"
    const val KEY_SCHED_START_H   = "schedule_start_h"
    const val KEY_SCHED_START_M   = "schedule_start_m"
    const val KEY_SCHED_END_H     = "schedule_end_h"
    const val KEY_SCHED_END_M     = "schedule_end_m"

    // Reels / Shorts block
    const val KEY_REELS_BLOCK     = "reels_block_enabled"

    // App timer
    const val KEY_APP_TIMER_ON    = "app_timer_enabled"
    const val KEY_TIMER_YT_MINS   = "timer_youtube_mins"
    const val KEY_TIMER_TT_MINS   = "timer_tiktok_mins"
    const val KEY_TIMER_IG_MINS   = "timer_instagram_mins"
    const val KEY_TIMER_FB_MINS   = "timer_facebook_mins"

    // App usage today (milliseconds)
    const val KEY_USE_YT_TODAY    = "use_youtube_today_ms"
    const val KEY_USE_TT_TODAY    = "use_tiktok_today_ms"
    const val KEY_USE_IG_TODAY    = "use_instagram_today_ms"
    const val KEY_USE_FB_TODAY    = "use_facebook_today_ms"

    // Custom auto-click actions: Set<String> where each entry = "label::pkg"
    // pkg can be "*" for all apps
    const val KEY_AUTO_ACTIONS    = "custom_auto_actions"

    // URL block: Set<String> of domain keywords
    const val KEY_URL_BLOCK       = "url_block_keywords"

    // Schedule lock whitelist — packages allowed even during schedule lock
    const val KEY_SCHED_WHITELIST = "schedule_whitelist_packages"
}
