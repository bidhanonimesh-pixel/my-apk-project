package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.app.admin.DeviceAdminReceiver

class ShieldBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.LOCKED_BOOT_COMPLETED",
            Intent.ACTION_REBOOT
        )
        if (intent.action in validActions) {
            Log.d("ShieldBoot", "Device restarted — Shield running via Accessibility Service.")
        }
    }
}

class ShieldDeviceAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("ShieldAdmin", "Device Administrator Enabled.")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Warning: Disabling ShieldPro will remove protection. Are you sure?"

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.d("ShieldAdmin", "Device Administrator Disabled.")
    }
}
