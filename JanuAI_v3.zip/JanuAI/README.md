# 🌸 জানু AI v3.0 — তোমার AI বান্ধবী

[![Build APK](https://github.com/YOUR_USERNAME/JanuAI/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR_USERNAME/JanuAI/actions)

> হর হর মহাদেব! 🕉️ একটি premium hybrid AI অ্যাপ — girlfriend-like personality, multi-provider AI, offline brain, phone control সব কিছু সহ।

---

## ✨ Features

### 🤖 AI Engine
- **Multi-Provider Fallback** — Claude, OpenRouter (Llama/Gemma/Mistral Free), Groq, Gemini
- **Streaming Responses** — real-time AI উত্তর
- **Offline Brain** — NLP engine + IndexedDB cache, ইন্টারনেট ছাড়াও কাজ করে
- **Deep Memory** — কথোপকথনের ইতিহাস ও ব্যক্তিগত তথ্য মনে রাখে

### 💕 Personality & Emotion
- **Girlfriend-like** — ভালোবাসা, রাগ, দুঃখ, হাসি সব আবেগ প্রকাশ করে
- **Dynamic Mood** — 8 টি mood: happy, love, sad, angry, excited, playful, thinking, caring
- **Proactive Chat** — নিজে থেকে প্রশ্ন করে, কথা শুরু করে
- **Auto Emotion Detection** — user-এর কথা থেকে মন বোঝে

### 🛠️ Tools
- 🔍 **Deep Search** — AI দিয়ে যেকোনো বিষয় research
- 💻 **Code Editor** — লেখো, run করো, HTML preview
- 🌐 **Translate** — বাংলা↔ইংরেজি↔হিন্দি↔আরবি
- 🧮 **Calculator** — advanced math, √, %, expression
- 📁 **File/ZIP Analysis** — ZIP পাঠিয়ে সরাসরি প্রশ্ন করো
- 📷 **Image Understanding** — ছবি পাঠাও, বিশ্লেষণ পাও
- 🤖 **Task Agent** — autonomous task execution

### 📱 Phone Control (Android)
- ▶️ YouTube search & play
- 📞 Call & SMS
- 🔊 Volume control
- 📳 Vibrate
- 📤 Share content
- 🔗 URL open
- 📋 Clipboard
- 🔋 Battery & network status

### 🎨 UI
- Particle animation background
- Emotion-based avatar (8 states)
- Futuristic dark theme
- Smooth animations
- Code syntax highlighting + run button
- Collapsible history

---

## 🚀 GitHub দিয়ে APK Build করো

### Step 1: Repository তৈরি করো
```
1. GitHub.com এ লগইন করো
2. "New Repository" → নাম: JanuAI → Public → Create
3. এই ZIP এর সব ফাইল upload করো
```

### Step 2: Files Upload করো
```
1. GitHub repository পেজে "uploading an existing file" ক্লিক করো
2. সব ফাইল ও ফোল্ডার drag করে দাও (structure বজায় রেখো)
3. "Commit changes" ক্লিক করো
```

### Step 3: APK Download করো
```
1. Repository → "Actions" tab
2. "Build JanuAI APK" workflow দেখবে
3. Run হলে → Artifacts → "JanuAI-Debug" download করো
4. জানু AI.apk install করো!
```

---

## ⚙️ API Key Setup (অ্যাপের ভেতর থেকে)

### বিনামূল্যে API পেতে:
1. **OpenRouter** (সবচেয়ে সহজ, FREE): https://openrouter.ai → Sign up → API Keys → Create Key
2. অ্যাপে ⚙️ Settings → API → OpenRouter card → Key paste করো → Enable করো → Save

### অন্যান্য providers:
| Provider | Free Tier | URL |
|----------|-----------|-----|
| OpenRouter | ✅ Free models আছে | openrouter.ai |
| Groq | ✅ Free | console.groq.com |
| Gemini | ✅ Free tier | aistudio.google.com |
| Claude | ❌ Paid | console.anthropic.com |

> **Tip:** OpenRouter-এ একটা key দিলেই Llama, Gemma, Mistral সব free model পাবে!

---

## 📁 Project Structure

```
JanuAI/
├── app/
│   ├── src/main/
│   │   ├── assets/www/
│   │   │   └── index.html          ← পুরো AI app (HTML/CSS/JS)
│   │   ├── java/com/januai/app/
│   │   │   ├── MainActivity.kt     ← Android WebView host
│   │   │   └── JanuApp.kt          ← Application class
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/
│   │   │   │   ├── strings.xml
│   │   │   │   ├── themes.xml
│   │   │   │   └── colors.xml
│   │   │   └── xml/
│   │   │       ├── network_security_config.xml
│   │   │       ├── backup_rules.xml
│   │   │       └── data_extraction_rules.xml
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── .github/workflows/build.yml     ← Auto APK builder
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradlew
└── gradlew.bat
```

---

## 🌐 Browser-এও চলবে!

`index.html` সরাসরি browser এ open করলেও কাজ করবে। Phone features ছাড়া সব কিছু browser-এও পাবে।

---

## 🔧 Customization

### নতুন AI Provider যোগ করতে:
`index.html` এর `PROVIDERS` array তে নতুন object যোগ করো:
```javascript
{ id:'myai', name:'My AI', url:'https://api.example.com/chat', model:'my-model', type:'openai', key:'', enabled:false }
```

### নতুন Offline Response যোগ করতে:
`NLP.rules` array তে নতুন rule যোগ করো:
```javascript
{ p: [/তোমার pattern/i], e: 'happy', r: ['উত্তর ১', 'উত্তর ২'] }
```

### নতুন Phone Feature যোগ করতে:
1. `JanuBridge` class এ নতুন `@JavascriptInterface` method যোগ করো
2. `index.html` এর `PHONE` object এ সেই method call করো

---

## 🕉️ Credit

**জানু AI v3.0** — সনাতন ধর্মের প্রতি শ্রদ্ধাশীল একটি AI বান্ধবী।

হর হর মহাদেব! 🌸
