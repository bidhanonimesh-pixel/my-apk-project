package com.januai.app

import android.Manifest
import android.app.DownloadManager
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.view.*
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceCallback: ValueCallback<Array<Uri>>? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        const val REQ_SPEECH = 101
        const val REQ_PERMISSIONS = 102
        const val REQ_FILE_CHOOSER = 103
        val REQUIRED_PERMS = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.VIBRATE,
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full screen immersive
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT

        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)

        setupWebView()
        setupTTS()
        requestPermissions()

        webView.loadUrl("file:///android_asset/www/index.html")
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = "JanuAI/3.0 Android"
        }

        webView.addJavascriptInterface(JanuBridge(this), "JanuBridge")
        webView.setBackgroundColor(android.graphics.Color.parseColor("#050510"))

        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Inject Android bridge flag
                view?.evaluateJavascript("window.IS_ANDROID=true;", null)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    return true
                }
                if (url.startsWith("tel:")) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url)))
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "ফাইল বেছে নাও"), REQ_FILE_CHOOSER)
                return true
            }
            override fun onConsoleMessage(msg: ConsoleMessage?) = true
        }

        // Handle back press
        webView.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                if (webView.canGoBack()) { webView.goBack(); true }
                else false
            } else false
        }
    }

    private fun setupTTS() {
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                tts?.setLanguage(Locale.ENGLISH)
                ttsReady = true
            }
        }
    }

    private fun requestPermissions() {
        val missing = REQUIRED_PERMS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_SPEECH -> {
                if (resultCode == RESULT_OK) {
                    val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    val text = results?.firstOrNull() ?: ""
                    webView.evaluateJavascript("window.onVoiceResult('${text.replace("'","\\'")}');", null)
                }
            }
            REQ_FILE_CHOOSER -> {
                val results = if (resultCode == RESULT_OK && data != null) {
                    if (data.clipData != null) {
                        val count = data.clipData!!.itemCount
                        Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                    } else { data.data?.let { arrayOf(it) } ?: emptyArray() }
                } else emptyArray()
                fileChooserCallback?.onReceiveValue(results)
                fileChooserCallback = null
            }
        }
    }

    // JavaScript Bridge inner class
    inner class JanuBridge(private val ctx: Context) {

        @JavascriptInterface
        fun isAndroid(): Boolean = true

        @JavascriptInterface
        fun getVersion(): String = "3.0"

        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                if (ttsReady) {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "janu_${System.currentTimeMillis()}")
                }
            }
        }

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread { tts?.stop() }
        }

        @JavascriptInterface
        fun vibrate(ms: Long) {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (ctx.getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(ms)
            }
        }

        @JavascriptInterface
        fun playYouTube(query: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage("com.google.android.youtube")
                        putExtra("query", query)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    ctx.startActivity(intent)
                } catch (e: Exception) {
                    // Fallback to browser
                    val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                }
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }

        @JavascriptInterface
        fun callPhone(number: String) {
            runOnUiThread {
                val intent = if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                } else {
                    Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                }
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(intent)
            }
        }

        @JavascriptInterface
        fun sendSMS(number: String, text: String) {
            try {
                val sms = SmsManager.getDefault()
                val parts = sms.divideMessage(text)
                sms.sendMultipartTextMessage(number, null, parts, null, null)
                webView.post { toast("SMS পাঠানো হয়েছে") }
            } catch (e: Exception) {
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("sms:$number")).apply {
                        putExtra("sms_body", text)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    ctx.startActivity(intent)
                }
            }
        }

        @JavascriptInterface
        fun setVolume(percent: Int) {
            val audio = ctx.getSystemService(AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val vol = (max * percent / 100)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0)
        }

        @JavascriptInterface
        fun getVolume(): Int {
            val audio = ctx.getSystemService(AUDIO_SERVICE) as AudioManager
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            return if (max > 0) (cur * 100 / max) else 0
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                ctx.startActivity(Intent.createChooser(intent, "শেয়ার করো").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }

        @JavascriptInterface
        fun openSettings() {
            runOnUiThread {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }

        @JavascriptInterface
        fun setWallpaper(imageUrl: String) {
            webView.post { toast("Wallpaper feature সীমিত। ⚙️ Settings থেকে ম্যানুয়ালি করো।") }
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun getBatteryLevel(): Int {
            val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.BATTERY_PROPERTY_CAPACITY, -1) ?: -1
            val scale = intent?.getIntExtra("scale", 100) ?: 100
            return if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        }

        @JavascriptInterface
        fun isCharging(): Boolean {
            val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = intent?.getIntExtra(BatteryManager.BATTERY_PROPERTY_STATUS, -1) ?: -1
            return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        }

        @JavascriptInterface
        fun getNetworkType(): String {
            val cm = ctx.getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val net = cm.activeNetworkInfo
            return when {
                net == null || !net.isConnected -> "none"
                net.type == android.net.ConnectivityManager.TYPE_WIFI -> "wifi"
                net.type == android.net.ConnectivityManager.TYPE_MOBILE -> "mobile"
                else -> "other"
            }
        }

        @JavascriptInterface
        fun getApiFromApp(): String {
            val prefs = ctx.getSharedPreferences("JanuPrefs", MODE_PRIVATE)
            return prefs.getString("api_key", "") ?: ""
        }

        @JavascriptInterface
        fun saveApiToApp(key: String) {
            val prefs = ctx.getSharedPreferences("JanuPrefs", MODE_PRIVATE)
            prefs.edit().putString("api_key", key).apply()
        }

        @JavascriptInterface
        fun savePreference(key: String, value: String) {
            val prefs = ctx.getSharedPreferences("JanuPrefs", MODE_PRIVATE)
            prefs.edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun getPreference(key: String, default: String): String {
            val prefs = ctx.getSharedPreferences("JanuPrefs", MODE_PRIVATE)
            return prefs.getString(key, default) ?: default
        }

        @JavascriptInterface
        fun openCamera() {
            runOnUiThread {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                ctx.startActivity(intent)
            }
        }

        @JavascriptInterface
        fun openGallery() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                ctx.startActivity(intent)
            }
        }

        @JavascriptInterface
        fun getDeviceInfo(): String {
            return """{"model":"${Build.MODEL}","brand":"${Build.BRAND}","android":"${Build.VERSION.RELEASE}","sdk":${Build.VERSION.SDK_INT}}"""
        }

        @JavascriptInterface
        fun closeApp() {
            runOnUiThread { finishAffinity() }
        }

        @JavascriptInterface
        fun copyToClipboard(text: String) {
            val clipboard = ctx.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("জানু AI", text))
            webView.post { toast("কপি হয়েছে!") }
        }

        @JavascriptInterface
        fun pasteFromClipboard(): String {
            val clipboard = ctx.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            return clipboard.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
        }

        @JavascriptInterface
        fun flashlight(on: Boolean) {
            webView.post { toast("ফ্ল্যাশলাইট: Camera API প্রয়োজন") }
        }

        @JavascriptInterface
        fun searchWeb(query: String) {
            runOnUiThread {
                val url = "https://www.google.com/search?q=${Uri.encode(query)}"
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        webView.pauseTimers()
    }

    override fun onDestroy() {
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
