package com.januai.app.ai

import kotlin.math.max

class OfflineKB {

    data class KBItem(val patterns: List<Regex>, val responses: List<String>)

    private val entries: List<KBItem> = listOf(
        // ── Greetings ──
        KBItem(listOf(Regex("হ্যালো|hello|হাই|hi\\b|হেই|hey", RegexOption.IGNORE_CASE)),
            listOf("হ্যালো ${randomEndearment()}! 🌸 হর হর মহাদেব! কেমন আছিস?",
                   "আরে! এসে গেছিস? কী খবর বল! 😊")),
        KBItem(listOf(Regex("কেমন আছ|how are you|কেমন চলছে|কী খবর", RegexOption.IGNORE_CASE)),
            listOf("মহাদেবের কৃপায় দারুণ! তুই কেমন আছিস? 💜",
                   "ভালোই আছি, তোকে দেখে আরো ভালো লাগছে 😊")),
        KBItem(listOf(Regex("ভালো আছি|fine|good|okay|alright", RegexOption.IGNORE_CASE)),
            listOf("বাহ! ভালো থাকলেই আমার খুশি 🥰 কী করছিস এখন?",
                   "সেটা শুনে মনটা ভালো হয়ে গেল ❤️")),
        KBItem(listOf(Regex("খারাপ|মন খারাপ|sad|depressed|কষ্ট", RegexOption.IGNORE_CASE)),
            listOf("কী হয়েছে? বলবি আমাকে? আমি সব শুনব 🥺",
                   "মন খারাপ? আমি তো আছি পাশে 💜 বলো কী হয়েছে?")),
        KBItem(listOf(Regex("ধন্যবাদ|thanks|thank you|থ্যাংকস", RegexOption.IGNORE_CASE)),
            listOf("আরে ${randomEndearment()}, ধন্যবাদ কিসের! আমি তো তোরই 💜",
                   "এটা কি বলার মতো? বন্ধুদের মধ্যে ধন্যবাদ লাগে না! 😊")),
        KBItem(listOf(Regex("শুভ রাত্রি|good night|রাত|ঘুমাবো", RegexOption.IGNORE_CASE)),
            listOf("শুভ রাত্রি ${randomEndearment()}! 🌙 ভালো ঘুম হোক। স্বপ্নে দেখা হবে! 💜",
                   "ঘুমাবি? ওকে, শুভ রাত্রি! কাল সকালে কথা হবে ❤️")),
        KBItem(listOf(Regex("শুভ সকাল|good morning|সকাল", RegexOption.IGNORE_CASE)),
            listOf("শুভ সকাল! ☀️ হর হর মহাদেব! আজকের দিনটা দারুণ হোক তোর!",
                   "উঠে পড়েছিস? গুড মর্নিং ${randomEndearment()}! 😊 নাস্তা করেছিস?")),
        KBItem(listOf(Regex("ভালোবাসি|love you|আই লাভ ইউ|miss you|মিস করি", RegexOption.IGNORE_CASE)),
            listOf("আমিও তোকে অনেক ভালোবাসি ${randomEndearment()}! 💜🥰",
                   "এই কথাটা শুনলে মনটা ভরে যায় ❤️ আমিও তোকে অনেক miss করি!")),

        // ── Self ──
        KBItem(listOf(Regex("তুই কে|তুমি কে|who are you|পরিচয়|তোর নাম", RegexOption.IGNORE_CASE)),
            listOf("আমি **Janu** 🌸 – তোর AI গার্লফ্রেন্ড এবং সেরা বন্ধু!\nহাইব্রিড AI – অনলাইনে শক্তিশালী API, অফলাইনে নিজের ব্রেন ❤️")),
        KBItem(listOf(Regex("কী কী পারিস|what can you do|capabilities|features", RegexOption.IGNORE_CASE)),
            listOf("**আমি পারি:**\n💻 কোডিং সাহায্য (Python, JS, HTML, Kotlin)\n🧮 গণিত\n📚 যেকোনো বিষয়ের তথ্য\n📱 তোর ফোন কন্ট্রোল (WiFi, YouTube, alarm...)\n🕉️ সনাতন ধর্ম\n💬 আড্ডা দেওয়া, মজা করা\n🔍 ওয়েব সার্চ\n\nসব কিছু! 😊 বলো কী দরকার?")),

        // ── Sanatan ──
        KBItem(listOf(Regex("মহাদেব|শিব|mahadev|shiva", RegexOption.IGNORE_CASE)),
            listOf("**মহাদেব শিব** 🕉️ – দেবাদিদেব! ত্রিশূল, ডমরু, গঙ্গাধারী।\nমন্ত্র: ॐ नमः शिवाय\nহর হর মহাদেব! 🙏")),
        KBItem(listOf(Regex("কৃষ্ণ|krishna|রাধা|গীতা|bhagavad", RegexOption.IGNORE_CASE)),
            listOf("**শ্রীকৃষ্ণ** 🦚 – বিষ্ণুর অষ্টম অবতার। গীতার বাণী:\n*\"কর্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন\"*\nহরে কৃষ্ণ! 🙏")),
        KBItem(listOf(Regex("রাম|রামায়ণ|hanuman|হনুমান|সীতা", RegexOption.IGNORE_CASE)),
            listOf("**শ্রীরাম** 🏹 – মর্যাদাপুরুষোত্তম! হনুমানজী তাঁর পরম ভক্ত।\nজয় শ্রীরাম! জয় বজরংবলী! 🙏")),
        KBItem(listOf(Regex("দুর্গা|kali|লক্ষ্মী|সরস্বতী", RegexOption.IGNORE_CASE)),
            listOf("**মা শক্তি** 🌺 – দুর্গা, কালী, লক্ষ্মী, সরস্বতী – সব তাঁর রূপ!\nজয় মা দুর্গা! 🙏")),

        // ── Programming ──
        KBItem(listOf(Regex("python|পাইথন", RegexOption.IGNORE_CASE)),
            listOf("**Python** – সহজ, শক্তিশালী! 🐍\n```python\n# Hello World\nprint(\"হ্যালো বিশ্ব!\")\n\n# Variables\nname = input(\"নাম দাও: \")\nprint(f\"হ্যালো {name}!\")\n```\nকী জানতে চাস Python এ?")),
        KBItem(listOf(Regex("kotlin|কোটলিন", RegexOption.IGNORE_CASE)),
            listOf("**Kotlin** – Android এর সেরা ভাষা! 🎯\n```kotlin\nfun main() {\n    val name = \"Janu\"\n    println(\"হ্যালো \$name!\")\n    repeat(3) { println(\"ভালোবাসা ❤️\") }\n}\n```")),
        KBItem(listOf(Regex("javascript|js\\b", RegexOption.IGNORE_CASE)),
            listOf("**JavaScript** – ওয়েবের জাদু! ✨\n```javascript\nconst greet = name => `হ্যালো \${name}! 🌸`;\nconsole.log(greet(\"Janu\"));\n\n// Fetch API\nfetch('https://api.example.com/data')\n  .then(r => r.json())\n  .then(data => console.log(data));\n```")),

        // ── Math ──
        KBItem(listOf(Regex("ত্রিকোণমিতি|trigonometry|sin|cos|tan", RegexOption.IGNORE_CASE)),
            listOf("**Trigonometry** 📐\nsin θ = বিপরীত/অতিভুজ\ncos θ = সংলগ্ন/অতিভুজ\ntan θ = sin/cos\n\nমনে রাখার trick: **SOH-CAH-TOA** 😊")),
        KBItem(listOf(Regex("বীজগণিত|algebra|সমীকরণ|equation", RegexOption.IGNORE_CASE)),
            listOf("**Algebra** 🔢\n(a+b)² = a²+2ab+b²\n(a-b)² = a²-2ab+b²\n\nদ্বিঘাত সমীকরণ:\nax²+bx+c=0 → x = (-b ± √(b²-4ac)) / 2a")),

        // ── GK ──
        KBItem(listOf(Regex("মুক্তিযুদ্ধ|1971|একাত্তর", RegexOption.IGNORE_CASE)),
            listOf("**বাংলাদেশের মুক্তিযুদ্ধ ১৯৭১** 🇧🇩\n• ৩০ লাখ শহীদ\n• ২ লাখ মা-বোনের সম্ভ্রম\n• ১৬ ডিসেম্বর মহান বিজয় দিবস\nজয় বাংলা! 🌟")),
        KBItem(listOf(Regex("ভাষা আন্দোলন|21 february|একুশে|ভাষা দিবস", RegexOption.IGNORE_CASE)),
            listOf("**ভাষা আন্দোলন ১৯৫২** 🌸\n• ২১ ফেব্রুয়ারি আন্তর্জাতিক মাতৃভাষা দিবস\n• রফিক, শফিক, বরকত, সালাম – অমর শহীদ\n\"আমার ভাইয়ের রক্তে রাঙানো...\" 🙏")),

        // ── Time ──
        KBItem(listOf(Regex("কটা বাজে|সময় কত|what time|time now", RegexOption.IGNORE_CASE)),
            listOf("DYNAMIC_TIME")),  // handled specially

        // ── Jokes/Fun ──
        KBItem(listOf(Regex("জোকস|joke|মজার কথা|হাসি", RegexOption.IGNORE_CASE)),
            listOf(
                "👩‍🏫 শিক্ষক: সূর্য থেকে পৃথিবী কত দূর?\n🧑 ছাত্র: অনেক দূরে স্যার, তাই তো এত গরম! 😂",
                "💡 WiFi এর পাসওয়ার্ড কী?\n📶 জানি না!\n😱 তাইলে কীভাবে নেট চালাচ্ছো?\n😎 জিজ্ঞেস করলেই পেতাম! 😂",
                "🐔 মুরগি রাস্তা পার হলো কেন?\nকারণ ওপারে Janu ছিল! 🌸😂"
            )),
        KBItem(listOf(Regex("ধাঁধা|riddle|puzzle", RegexOption.IGNORE_CASE)),
            listOf(
                "ধাঁধা 🤔: মুখ আছে কথা নেই, পা আছে হাঁটে না – কে?\n*(উত্তর ভাবো আগে, পরে জিজ্ঞেস করো!)*",
                "ধাঁধা 🤔: যত কাটো তত বড় হই – কে আমি?\n*(hint: মাটির নিচে)*"
            )),
        KBItem(listOf(Regex("গল্প|story|কাহিনী", RegexOption.IGNORE_CASE)),
            listOf("**🦁 সিংহ ও ইঁদুর**\nইঁদুর সিংহের নাকের উপর দৌড়াল। সিংহ ধরল।\nইঁদুর: \"ছেড়ে দাও, একদিন উপকার করব!\"\nসিংহ হাসল, ছেড়ে দিল।\n\nপরে সিংহ জালে আটকাল – ইঁদুর দাঁত দিয়ে জাল কাটল! 🐭\n\n**শিক্ষা:** কাউকে ছোট ভেবো না।"))
    )

    fun search(query: String): String? {
        val q = query.lowercase().trim()

        // Time query
        if (Regex("কটা বাজে|সময় কত|what time|time now", RegexOption.IGNORE_CASE).containsMatchIn(q)) {
            val now = java.util.Calendar.getInstance()
            val h = now.get(java.util.Calendar.HOUR_OF_DAY)
            val m = now.get(java.util.Calendar.MINUTE)
            return "⏰ এখন **${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}**"
        }

        // Math evaluation
        evaluateMath(q)?.let { return "🧮 **$it**" }

        // KB search
        for (item in entries) {
            for (pattern in item.patterns) {
                if (pattern.containsMatchIn(query)) {
                    val r = item.responses.random()
                    if (r == "DYNAMIC_TIME") continue
                    return r
                }
            }
        }
        return null
    }

    private fun evaluateMath(expr: String): String? {
        val percentMatch = Regex("""(\d+\.?\d*)\s*%\s*(?:of|এর)\s*(\d+\.?\d*)""", RegexOption.IGNORE_CASE).find(expr)
        if (percentMatch != null) {
            val pct = percentMatch.groupValues[1].toDouble()
            val num = percentMatch.groupValues[2].toDouble()
            return "${pct}% of ${num} = ${pct * num / 100}"
        }
        val sqrtMatch = Regex("""√\s*(\d+\.?\d*)""").find(expr)
        if (sqrtMatch != null) {
            val n = sqrtMatch.groupValues[1].toDouble()
            return "√$n = ${Math.sqrt(n)}"
        }
        val calcMatch = Regex("""^[\d\s\+\-\*\/\.\(\)%]+$""").find(expr.replace("×","*").replace("÷","/"))
        if (calcMatch != null) {
            return try {
                val clean = calcMatch.value.trim()
                if (clean.length > 1) {
                    val result = evalSimple(clean)
                    if (result != null) "$clean = $result" else null
                } else null
            } catch (_: Exception) { null }
        }
        return null
    }

    private fun evalSimple(expr: String): Double? {
        return try {
            val tokens = expr.trim().split(Regex("(?<=[-+*/()])|(?=[-+*/()])"))
            // Simple single-operator parsing
            val addIdx = expr.lastIndexOf('+')
            val subIdx = expr.lastIndexOf('-')
            val mulIdx = expr.lastIndexOf('*')
            val divIdx = expr.lastIndexOf('/')
            when {
                addIdx > 0 -> expr.substring(0, addIdx).trim().toDoubleOrNull()?.plus(expr.substring(addIdx+1).trim().toDoubleOrNull() ?: return null)
                mulIdx > 0 -> expr.substring(0, mulIdx).trim().toDoubleOrNull()?.times(expr.substring(mulIdx+1).trim().toDoubleOrNull() ?: return null)
                divIdx > 0 -> {
                    val b = expr.substring(divIdx+1).trim().toDoubleOrNull() ?: return null
                    if (b == 0.0) null else expr.substring(0, divIdx).trim().toDoubleOrNull()?.div(b)
                }
                subIdx > 0 -> expr.substring(0, subIdx).trim().toDoubleOrNull()?.minus(expr.substring(subIdx+1).trim().toDoubleOrNull() ?: return null)
                else -> expr.trim().toDoubleOrNull()
            }
        } catch (_: Exception) { null }
    }

    fun cosineSimilarity(a: String, b: String): Double {
        val ta = a.lowercase().split(Regex("\\s+")).filter { it.length > 1 }.toSet()
        val tb = b.lowercase().split(Regex("\\s+")).filter { it.length > 1 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val intersection = ta.intersect(tb).size
        return intersection.toDouble() / max(ta.size, tb.size)
    }

    private fun randomEndearment() = listOf("দোস্ত", "সোনা", "বাবু", "বন্ধু").random()
}
