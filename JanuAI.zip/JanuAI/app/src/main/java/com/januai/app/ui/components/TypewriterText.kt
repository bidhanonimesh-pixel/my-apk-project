package com.januai.app.ui.components

import androidx.compose.runtime.*
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.TextUnit
import kotlinx.coroutines.delay
import com.januai.app.ui.theme.TextPrimary

@Composable
fun TypewriterText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = TextPrimary,
    fontSize: TextUnit = TextUnit.Unspecified,
    speedMs: Long = 20L
) {
    var displayed by remember(text) { mutableStateOf("") }
    LaunchedEffect(text) {
        displayed = ""
        text.forEachIndexed { i, _ ->
            displayed = text.substring(0, i + 1)
            delay(speedMs)
        }
    }
    Text(text = parseMarkdown(displayed), modifier = modifier, color = color, fontSize = fontSize)
}
