package com.januai.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.januai.app.data.ApiConfigEntity
import com.januai.app.ui.theme.*
import com.januai.app.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: ChatViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val configs by viewModel.getApiConfigs().collectAsState(initial = emptyList())
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🌐 API", "🧠 Brain", "📜 ইতিহাস", "ℹ️ About")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(GradientBg))
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgDeep)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text("⚙️ সেটিংস", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        HorizontalDivider(color = BorderNorm)

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = BgSurface1,
            contentColor = AccentPurple,
            edgePadding = 0.dp
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, fontSize = 12.sp) }
                )
            }
        }

        when (selectedTab) {
            0 -> APITab(configs, onSave = { scope.launch { viewModel.saveApiConfig(it) } }, onDelete = { scope.launch { viewModel.deleteApiConfig(it) } })
            1 -> BrainTab()
            2 -> HistoryTab(viewModel)
            3 -> AboutTab()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun APITab(
    configs: List<ApiConfigEntity>,
    onSave: (ApiConfigEntity) -> Unit,
    onDelete: (String) -> Unit
) {
    var editingConfig by remember { mutableStateOf<ApiConfigEntity?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            InfoCard("💡 API Setup", "API Key বসাও নিচে। একাধিক API সেট করো – একটা ব্যর্থ হলে পরেরটা ব্যবহার হবে!")
        }
        items(configs) { cfg ->
            ApiConfigCard(
                config = cfg,
                onEdit = { editingConfig = cfg },
                onToggle = { onSave(cfg.copy(enabled = !cfg.enabled)) },
                onDelete = { onDelete(cfg.name) }
            )
        }
        item {
            Button(
                onClick = { showAdd = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = BgSurface2, contentColor = AccentPurple),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("নতুন API যোগ করো")
            }
        }
    }

    editingConfig?.let { cfg ->
        ApiEditDialog(
            config = cfg,
            onSave = { onSave(it); editingConfig = null },
            onDismiss = { editingConfig = null }
        )
    }
    if (showAdd) {
        ApiEditDialog(
            config = ApiConfigEntity("", "https://openrouter.ai/api/v1/chat/completions", "", "meta-llama/llama-3.1-8b-instruct:free"),
            onSave = { onSave(it); showAdd = false },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
fun ApiConfigCard(config: ApiConfigEntity, onEdit: () -> Unit, onToggle: () -> Unit, onDelete: () -> Unit) {
    SectionCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(config.name.ifBlank { "Unnamed" }, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (config.enabled) {
                        Badge(containerColor = AccentGreen.copy(0.15f)) { Text("ON", color = AccentGreen, fontSize = 9.sp) }
                    } else {
                        Badge(containerColor = TextMuted.copy(0.15f)) { Text("OFF", color = TextMuted, fontSize = 9.sp) }
                    }
                    if (config.key.isNotBlank()) {
                        Badge(containerColor = AccentTeal.copy(0.15f)) { Text("✓ Key", color = AccentTeal, fontSize = 9.sp) }
                    }
                }
                Text(config.model, color = TextDim, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                Text("Priority: ${config.priority}", color = TextMuted, fontSize = 10.sp)
            }
            IconButton(onClick = onToggle) {
                Icon(if (config.enabled) Icons.Default.ToggleOn else Icons.Default.ToggleOff,
                    contentDescription = null, tint = if (config.enabled) AccentGreen else TextMuted)
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = AccentPurple)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiEditDialog(config: ApiConfigEntity, onSave: (ApiConfigEntity) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(config.name) }
    var url by remember { mutableStateOf(config.url) }
    var key by remember { mutableStateOf(config.key) }
    var model by remember { mutableStateOf(config.model) }
    var priority by remember { mutableStateOf(config.priority.toString()) }
    var showKey by remember { mutableStateOf(false) }

    val presets = listOf(
        "Anthropic" to "https://api.anthropic.com/v1/messages",
        "OpenRouter" to "https://openrouter.ai/api/v1/chat/completions",
        "Groq" to "https://api.groq.com/openai/v1/chat/completions",
        "Gemini" to "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
    )
    val modelSuggestions = mapOf(
        "https://api.anthropic.com/v1/messages" to listOf("claude-3-5-haiku-20241022","claude-3-5-sonnet-20241022"),
        "https://openrouter.ai/api/v1/chat/completions" to listOf("meta-llama/llama-3.1-8b-instruct:free","google/gemma-2-9b-it:free","mistralai/mistral-7b-instruct:free"),
        "https://api.groq.com/openai/v1/chat/completions" to listOf("llama-3.1-8b-instant","gemma2-9b-it"),
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions" to listOf("gemini-2.0-flash","gemini-1.5-flash")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = BgSurface1,
        title = { Text(if (config.name.isBlank()) "নতুন API" else "API Edit", color = TextPrimary) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Provider presets
                Text("Provider:", color = TextDim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    presets.forEach { (n, u) ->
                        FilterChip(
                            selected = url == u,
                            onClick = { url = u; if (name.isBlank()) name = n; model = modelSuggestions[u]?.firstOrNull() ?: model },
                            label = { Text(n, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentPurple.copy(0.2f),
                                selectedLabelColor = AccentPurple
                            )
                        )
                    }
                }
                SettingsField("নাম", name, { name = it })
                SettingsField("API URL", url, { url = it })
                SettingsField("API Key", key, { key = it },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null, tint = TextDim, modifier = Modifier.size(18.dp))
                        }
                    }
                )
                // Model suggestions
                val suggs = modelSuggestions[url] ?: emptyList()
                if (suggs.isNotEmpty()) {
                    Text("Model:", color = TextDim, fontSize = 12.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        suggs.forEach { m ->
                            FilterChip(
                                selected = model == m,
                                onClick = { model = m },
                                label = { Text(m, fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AccentTeal.copy(0.2f),
                                    selectedLabelColor = AccentTeal
                                )
                            )
                        }
                    }
                }
                SettingsField("Model Name", model, { model = it })
                SettingsField("Priority (0=highest)", priority, { priority = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(ApiConfigEntity(name, url, key, model, true, priority.toIntOrNull() ?: 0)) },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
            ) { Text("💾 সেভ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল", color = TextDim) }
        }
    )
}

@Composable
fun BrainTab() {
    Column(modifier = Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoCard("🧠 Brain Features", "Janu এর AI ক্ষমতা সম্পর্কে জানো")
        SectionCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureRow("🔄", "Multi-API Fallback", "একটা fail হলে পরেরটা try করে")
                FeatureRow("💾", "Smart Cache", "পুরনো উত্তর মনে রাখে")
                FeatureRow("🧬", "Memory System", "তোমার তথ্য মনে রাখে")
                FeatureRow("📱", "Phone Control", "ফোনের কাজ করতে পারে")
                FeatureRow("🎤", "Voice Input", "বাংলায় কথা বলো")
                FeatureRow("💬", "Streaming", "Real-time টাইপিং দেখো")
                FeatureRow("🕉️", "Sanatan KB", "সনাতন ধর্মের জ্ঞান")
                FeatureRow("😊", "Emotion AI", "আবেগ বোঝে ও প্রকাশ করে")
            }
        }
    }
}

@Composable
fun HistoryTab(viewModel: ChatViewModel) {
    val messages by viewModel.uiState.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (messages.messages.isEmpty()) {
            item { Text("কোনো ইতিহাস নেই", color = TextDim, modifier = Modifier.padding(20.dp)) }
        }
        items(messages.messages.takeLast(30).reversed()) { msg ->
            SectionCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (msg.role == "user") "😊" else "🌸", fontSize = 16.sp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (msg.role == "user") "তুমি" else "Janu",
                            color = if (msg.role == "user") AccentGreen else AccentPurple,
                            fontSize = 11.sp, fontWeight = FontWeight.Bold
                        )
                        Text(
                            msg.text.take(120) + if (msg.text.length > 120) "..." else "",
                            color = TextDim, fontSize = 12.sp, lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AboutTab() {
    Column(modifier = Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(GradientAvatar)).padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🌸", fontSize = 56.sp)
                Text("Janu AI v2.0", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("তোমার AI গার্লফ্রেন্ড", color = Color.White.copy(0.8f), fontSize = 14.sp)
            }
        }
        SectionCard {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoRow("Version", "2.0.0")
                InfoRow("Engine", "Multi-API + Offline KB")
                InfoRow("Language", "Bengali (বাংলা)")
                InfoRow("Mode", "Hybrid AI")
                InfoRow("Personality", "AI Girlfriend 💜")
                InfoRow("Built With", "Kotlin + Jetpack Compose")
            }
        }
        InfoCard("❤️ Made with Love", "Janu তোমার জন্য তৈরি। হর হর মহাদেব! 🕉️")
    }
}

// ── Reusable components ──

@Composable
fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(BgSurface2)
            .border(1.dp, BorderNorm, RoundedCornerShape(13.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
fun InfoCard(title: String, body: String) {
    SectionCard {
        Text(title, color = AccentPurple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text(body, color = TextDim, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsField(
    label: String, value: String, onChange: (String) -> Unit,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    trailingIcon: (@Composable () -> Unit)? = null
) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label, fontSize = 12.sp) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        visualTransformation = visualTransformation,
        trailingIcon = trailingIcon,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = AccentPurple.copy(0.6f), unfocusedBorderColor = BorderNorm,
            focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
            cursorColor = AccentPurple,
            focusedContainerColor = BgSurface3, unfocusedContainerColor = BgSurface3,
            focusedLabelColor = AccentPurple, unfocusedLabelColor = TextDim
        ),
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
    )
}

@Composable
fun FeatureRow(icon: String, title: String, desc: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(icon, fontSize = 18.sp)
        Column {
            Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = TextDim, fontSize = 11.sp)
        }
    }
}

@Composable
fun InfoRow(key: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key, color = TextDim, fontSize = 13.sp)
        Text(value, color = AccentPurple, fontSize = 13.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
    }
}
