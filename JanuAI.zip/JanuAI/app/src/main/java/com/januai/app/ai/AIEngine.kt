package com.januai.app.ai

import android.content.Context
import android.util.Log
import com.januai.app.data.AppDatabase
import com.januai.app.data.CacheEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ResponseMode { LIVE, CACHE, OFFLINE, ERROR }

data class AIResponse(
    val text: String,
    val mode: ResponseMode,
    val toolResult: ToolResult? = null
)

class AIEngine(private val context: Context, private val db: AppDatabase) {

    private val api = APIManager(db)
    private val kb = OfflineKB()
    val emotion = EmotionEngine()
    val memory = MemorySystem(db)
    val tools = ToolSystem(context)

    companion object {
        private const val TAG = "AIEngine"
        private const val CACHE_THRESHOLD = 0.60
        private const val MAX_HISTORY = 16
    }

    suspend fun respond(
        userMessage: String,
        history: List<ChatMessage>,
        onChunk: ((String) -> Unit)? = null
    ): AIResponse = withContext(Dispatchers.IO) {

        emotion.processUserMessage(userMessage)
        memory.extractAndSave(userMessage, "")

        // 1. KB search (instant)
        val kbHit = kb.search(userMessage)
        if (kbHit != null) {
            emotion.processAIResponse(kbHit)
            return@withContext AIResponse(kbHit, ResponseMode.OFFLINE)
        }

        // 2. Try API (online with fallback)
        return@withContext try {
            val msgs = buildMessages(userMessage, history)
            val raw = api.call(msgs) { chunk ->
                onChunk?.invoke(chunk)
            }
            val trimmed = raw.trim()

            // Check for tool call in response
            val toolResult = if (trimmed.startsWith("{") || trimmed.contains("\"action\"")) {
                tools.parseAndExecute(trimmed)
            } else null

            val displayText = toolResult?.userFeedback ?: trimmed
            emotion.processAIResponse(displayText)

            // Cache the response
            try {
                db.cacheDao().insert(CacheEntity(question = userMessage, answer = displayText))
            } catch (_: Exception) {}

            AIResponse(displayText, ResponseMode.LIVE, toolResult)

        } catch (apiError: Exception) {
            Log.w(TAG, "API failed: ${apiError.message}")

            // 3. Semantic cache search
            val cached = findInCache(userMessage)
            if (cached != null) {
                return@withContext AIResponse(cached, ResponseMode.CACHE)
            }

            // 4. Fallback response
            val fallback = getFallback(userMessage)
            AIResponse(fallback, ResponseMode.OFFLINE)
        }
    }

    private fun buildMessages(userMessage: String, history: List<ChatMessage>): List<ChatMessage> {
        val msgs = mutableListOf<ChatMessage>()
        val memCtx = ""  // memory context can be added here

        // Add recent history
        val recentHistory = history.takeLast(MAX_HISTORY)
        msgs.addAll(recentHistory)

        // Add current message
        msgs.add(ChatMessage("user", userMessage))
        return msgs
    }

    private suspend fun findInCache(query: String): String? = withContext(Dispatchers.IO) {
        val all = db.cacheDao().getAll()
        var best: String? = null
        var bestScore = CACHE_THRESHOLD
        for (entry in all) {
            val score = kb.cosineSimilarity(query, entry.question)
            if (score > bestScore) {
                bestScore = score
                best = entry.answer
            }
        }
        best
    }

    private fun getFallback(userMessage: String): String {
        val fallbacks = listOf(
            "দোস্ত, এখন ইন্টারনেট নেই বলে পুরো উত্তর দিতে পারছি না 😔\nSettings এ API Key দিলে সব উত্তর পাবি!",
            "উফফ! এই প্রশ্নের উত্তর এখন নেই আমার কাছে 🥺\nঅনলাইন হলে বলো, তখন ভালো করে বলব!",
            "আচ্ছা এটা একটু কঠিন প্রশ্ন! 🤔 Settings থেকে API Key সেট করো, তারপর আমি সব পারব!"
        )
        return fallbacks.random()
    }

    fun getModeLabel(mode: ResponseMode): String = when (mode) {
        ResponseMode.LIVE    -> "⚡ AI Live"
        ResponseMode.CACHE   -> "💾 Cache"
        ResponseMode.OFFLINE -> "🧠 Offline Brain"
        ResponseMode.ERROR   -> "⚠️ Error"
    }
}
