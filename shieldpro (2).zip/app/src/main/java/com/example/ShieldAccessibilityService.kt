package com.example

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import android.os.Handler
import android.os.Looper

class ShieldAccessibilityService : AccessibilityService() {
    private val TAG = "ShieldAccess"
    
    // Using broad keywords to search, then we will strictly verify text before clicking
    private val searchKeywords = listOf("skip", "close", "no thanks", "dismiss")
    
    // Explicit content keywords that will trigger an immediate block
    private val adultKeywords = listOf(
        "pornhub", "xnxx", "xvideos", "xhamster", "brazzers", "eporner",
        "spankbang", "youporn", "redtube", "tube8", "javhd", "rule34", "hentai",
        "sex", "nhentai", "javdo"
    )

    private var lastCheckTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        
        // Battery Health Optimization: Throttle events to max 1 per 300ms
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastCheckTime < 300) {
            return
        }
        lastCheckTime = currentTime

        // Prevent actions inside our own app or critical system processes
        val packageName = event.packageName?.toString() ?: ""
        if (packageName.contains("systemui") || packageName == "com.aistudio.shieldpro.pxrtz") {
            return
        }

        // Fast check on the event's immediate text to intercept searches quickly
        val eventText = event.text.joinToString(" ").lowercase()
        val descText = event.contentDescription?.toString()?.lowercase() ?: ""
        val combinedText = "$eventText $descText"
        
        for (keyword in adultKeywords) {
             if (combinedText.contains(keyword)) {
                 blockContent(keyword, packageName)
                 return
             }
        }

        try {
            val rootNode = rootInActiveWindow ?: return
            
            // Deep check for adult keywords in the UI tree
            for (keyword in adultKeywords) {
                val nodes = rootNode.findAccessibilityNodeInfosByText(keyword)
                if (nodes.isNotEmpty()) {
                    for (node in nodes) node.recycle()
                    blockContent(keyword, packageName)
                    rootNode.recycle()
                    return
                }
            }
            
            // Check for ad skips
            for (keyword in searchKeywords) {
                val nodes = rootNode.findAccessibilityNodeInfosByText(keyword)
                for (node in nodes) {
                    val text = (node.text ?: node.contentDescription)?.toString()?.trim()?.lowercase() ?: ""
                    
                    // Verifying if the text matches common ad-skip patterns exactly or contains them
                    if (text == "skip" || text == "close" || text == "no thanks" || text == "dismiss" || 
                        text.contains("skip ad") || text.contains("skip video") || text.contains("close ad")) {
                        
                        if (clickNodeOrParent(node)) {
                            Log.d(TAG, "Ad skipped successfully in $packageName (Matched text: $text)")
                            node.recycle()
                            rootNode.recycle()
                            return // Stop checking once we successfully click
                        }
                    }
                    node.recycle()
                }
            }
            rootNode.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "Error in AccessibilityService", e)
        }
    }

    private fun blockContent(keyword: String, pkg: String) {
        Log.d(TAG, "Blocked explicit keyword: $keyword in $pkg")
        // Force the app to the home screen immediately when explicit content is seen
        performGlobalAction(GLOBAL_ACTION_HOME)
        
        // Show a system-wide toast
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "🛡️ ShieldPro: Blocked Explicit Content!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return true
        }
        
        // If the node itself is not clickable, check its parents (up to 5 levels up)
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < 5) {
            if (parent.isClickable) {
                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                parent.recycle()
                return true
            }
            val nextParent = parent.parent
            parent.recycle()
            parent = nextParent
            depth++
        }
        return false
    }

    override fun onInterrupt() {
        Log.d(TAG, "Service interrupted")
    }
}
