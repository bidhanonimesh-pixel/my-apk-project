package com.example

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShieldProTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF0B0A1A),
                                    Color(0xFF0B142E),
                                    Color(0xFF041528)
                                )
                            )
                        )
                ) {
                    // Ambient glow shapes in background
                    Box(modifier = Modifier
                        .offset(x = (-50).dp, y = (-50).dp)
                        .size(200.dp)
                        .background(
                            Brush.radialGradient(listOf(Color(0xFF00FFCC).copy(alpha = 0.15f), Color.Transparent)),
                            shape = CircleShape
                        ))
                    Box(modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 50.dp, y = 150.dp)
                        .size(300.dp)
                        .background(
                            Brush.radialGradient(listOf(Color(0xFF8A2BE2).copy(alpha = 0.15f), Color.Transparent)),
                            shape = CircleShape
                        ))

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = Color.Transparent,
                        bottomBar = {
                            GlassBottomNavigation()
                        }
                    ) { innerPadding ->
                        ShieldDashboard(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GlassBottomNavigation() {
    Box(
        modifier = Modifier
            .navigationBarsPadding()
            .fillMaxWidth()
            .padding(16.dp)
            .height(72.dp)
            .clip(RoundedCornerShape(36.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(36.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavBarItem(icon = Icons.Default.Lock, isSelected = true)
            NavBarItem(icon = Icons.Default.Build, isSelected = false)
            NavBarItem(icon = Icons.Default.Warning, isSelected = false)
        }
    }
}

@Composable
fun NavBarItem(icon: androidx.compose.ui.graphics.vector.ImageVector, isSelected: Boolean) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(if (isSelected) Color(0xFF00FFCC).copy(alpha = 0.2f) else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) Color(0xFF00FFCC) else Color.Gray,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun ShieldProTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = Color(0xFF00FFCC),
        onPrimary = Color(0xFF000000),
        background = Color(0xFF05050A),
        surface = Color(0xFF0F1626),
        onSurface = Color.White
    )
    MaterialTheme(
        colorScheme = darkColorScheme,
        content = content
    )
}


@Composable
fun ShieldDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var isAccessibilityEnabled by remember { mutableStateOf(false) }
    var isBatteryOptimizedIgnored by remember { mutableStateOf(false) }
    var isDeviceAdminEnabled by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isAccessibilityEnabled = checkAccessibilityStatus(context)
                isBatteryOptimizedIgnored = checkBatteryOptimization(context)
                isDeviceAdminEnabled = checkDeviceAdmin(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "SHIELD PRO",
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 5.sp,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            text = "ULTIMATE CYBER DEFENSE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00FFCC),
            letterSpacing = 3.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 40.dp)
        )

        // Center Static Shield
        Box(
            modifier = Modifier.size(240.dp),
            contentAlignment = Alignment.Center
        ) {
            // Faint outer waves - Made static for smooth performance
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .scale(1.2f)
                    .clip(CircleShape)
                    .border(1.dp, Color(0xFF00FFCC).copy(alpha = 0.3f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(190.dp)
                    .scale(1.1f)
                    .clip(CircleShape)
                    .border(2.dp, Color(0xFF00FFCC).copy(alpha = 0.1f), CircleShape)
            )
            
            // Outer glowing aura
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF00FFCC).copy(alpha = 0.2f),
                                Color.Transparent
                            )
                        )
                    )
            )
            // Inner Core
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF081C17),
                                Color(0xFF093144)
                            )
                        )
                    )
                    .border(2.dp, Brush.linearGradient(listOf(Color(0xFF00FFCC), Color(0xFF8A2BE2))), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(56.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
        
        Text(
            text = "Active Protection Shield Running\nBlocking 100% Ads & Threats.",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Actions
        Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
            
            var showBlockedSitesDialog by remember { mutableStateOf(false) }
            
            if (showBlockedSitesDialog) {
                AlertDialog(
                    onDismissRequest = { showBlockedSitesDialog = false },
                    containerColor = Color(0xFF0B142E),
                    title = { Text("Blocked Threat Database", color = Color(0xFF00FFCC), fontWeight = FontWeight.Bold) },
                    text = { 
                        Text("The following explicit search terms and websites are actively monitored and immediately blocked by the ShieldPro Accessibility Engine:\n\npornhub, xnxx, xvideos, xhamster, brazzers, eporner, spankbang, youporn, redtube, tube8, javhd, rule34, hentai, sex, nhentai, javdo\n\nAdditionally, millions of adult and ad domains are blocked at the network level via the DNS Cloaking Engine.", 
                        color = Color.White.copy(alpha = 0.9f)) 
                    },
                    confirmButton = {
                        TextButton(onClick = { showBlockedSitesDialog = false }) {
                            Text("CLOSE", color = Color(0xFF00FFCC))
                        }
                    }
                )
            }

            // DNS / Adult Block
            NeonGlassCard(
                title = "Total Ad & Adult Block",
                subtitle = "DNS Firewall. Blocks 100% bad sites.",
                icon = Icons.Default.Lock,
                statusColor = Color(0xFF00FFCC),
                isActive = true,
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("DNS", "family.adguard-dns.com")
                    clipboard.setPrimaryClip(clip)
                    
                    Toast.makeText(context, "Copied: family.adguard-dns.com", Toast.LENGTH_LONG).show()
                    val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    try {
                        context.startActivity(intent)
                        Toast.makeText(context, "Go to 'Private DNS', select Private DNS provider hostname, and paste.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {}
                }
            )

            // Auto-Skip Ads (Accessibility)
            NeonGlassCard(
                title = "Auto-Skip AI Engine",
                subtitle = "Detects and clicks 'Skip Ad' in milliseconds.",
                icon = Icons.Default.CheckCircle,
                statusColor = if (isAccessibilityEnabled) Color(0xFF00FFCC) else Color(0xFFFF3366),
                isActive = isAccessibilityEnabled,
                onClick = {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    context.startActivity(intent)
                    Toast.makeText(context, "Turn on ShieldPro in Settings", Toast.LENGTH_LONG).show()
                }
            )

            // Battery Optimization Avoidance
            NeonGlassCard(
                title = "Smart Eco Mode (Battery)",
                subtitle = "Preserves battery health while fully active.",
                icon = Icons.Default.Warning,
                statusColor = if (isBatteryOptimizedIgnored) Color(0xFF00FFCC) else Color(0xFFFFB800),
                isActive = isBatteryOptimizedIgnored,
                onClick = {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = Uri.parse("package:${context.packageName}")
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Could not open Battery Settings.", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            // Uninstall Protection
            NeonGlassCard(
                title = "Uninstall Protection",
                subtitle = "Lock ShieldPro so no one can remove it.",
                icon = Icons.Default.Lock,
                statusColor = if (isDeviceAdminEnabled) Color(0xFF00FFCC) else Color(0xFF8A2BE2),
                isActive = isDeviceAdminEnabled,
                onClick = {
                    if (!isDeviceAdminEnabled) {
                        val compName = ComponentName(context, ShieldDeviceAdmin::class.java)
                        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "ShieldPro requires this to prevent unauthorized uninstallation and keep your device ad-free and safe.")
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    } else {
                        Toast.makeText(context, "Protection is already ACTIVE.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            
            // View Database
            NeonGlassCard(
                title = "View Blocked Database",
                subtitle = "Review exactly what ShieldPro filters.",
                icon = Icons.Default.CheckCircle,
                statusColor = Color(0xFF3B82F6),
                isActive = true,
                onClick = {
                    showBlockedSitesDialog = true
                }
            )
        }
        
        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun NeonGlassCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    statusColor: Color,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Gorgeous Icon Box
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(statusColor.copy(alpha = 0.15f))
                    .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(20.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, lineHeight = 18.sp)
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Upgraded Toggle Switch
            Box(
                modifier = Modifier
                    .width(48.dp)
                    .height(26.dp)
                    .clip(CircleShape)
                    .background(if (isActive) statusColor.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.1f))
                    .border(1.dp, if (isActive) statusColor else Color.White.copy(alpha = 0.2f), CircleShape)
                    .padding(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .align(if (isActive) Alignment.CenterEnd else Alignment.CenterStart)
                        .clip(CircleShape)
                        .background(if (isActive) statusColor else Color.Gray)
                        .let {
                            if (isActive) it.border(1.dp, Color.White.copy(alpha = 0.8f), CircleShape) else it
                        }
                )
            }
        }
    }
}

// OS Check Functions
fun checkAccessibilityStatus(context: Context): Boolean {
    var accessibilityEnabled = 0
    try {
        accessibilityEnabled = Settings.Secure.getInt(
            context.applicationContext.contentResolver,
            Settings.Secure.ACCESSIBILITY_ENABLED
        )
    } catch (e: Settings.SettingNotFoundException) {
        return false
    }
    if (accessibilityEnabled == 1) {
        val settingValue = Settings.Secure.getString(
            context.applicationContext.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        if (settingValue != null) {
            return settingValue.contains(context.packageName + "/" + ShieldAccessibilityService::class.java.canonicalName)
        }
    }
    return false
}

fun checkBatteryOptimization(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    return pm?.isIgnoringBatteryOptimizations(context.packageName) == true
}

fun checkDeviceAdmin(context: Context): Boolean {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    val comp = ComponentName(context, ShieldDeviceAdmin::class.java)
    return dpm?.isAdminActive(comp) == true
}
