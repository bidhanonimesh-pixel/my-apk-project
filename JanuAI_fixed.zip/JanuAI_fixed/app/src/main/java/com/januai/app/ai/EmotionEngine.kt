package com.januai.app.ai

enum class Emotion(val emoji: String, val label: String) {
    HAPPY("😊", "happy"),
    EXCITED("🥰", "excited"),
    SHY("🫣", "shy"),
    ANGRY("😤", "angry"),
    SAD("🥺", "sad"),
    NEUTRAL("🌸", "neutral"),
    LOVE("💜", "love"),
    LAUGHING("😂", "laughing"),
    THINKING("🤔", "thinking"),
    SURPRISED("😮", "surprised")
}

data class EmotionState(
    val current: Emotion = Emotion.NEUTRAL,
    val intensity: Float = 0.5f,
    val heartLevel: Int  = 80
)

class EmotionEngine {

    private var state       = EmotionState()
    private var messageCount = 0
    private var ignoreCount  = 0

    fun getState() = state

    fun processUserMessage(text: String): EmotionState {
        messageCount++; ignoreCount = 0
        val t = text.lowercase()
        val newEmotion = when {
            containsAny(t, listOf("ভালোবাসি","love you","miss you","মিস করি","❤","💜","💕")) -> {
                state = state.copy(heartLevel = (state.heartLevel + 5).coerceAtMost(100)); Emotion.LOVE
            }
            containsAny(t, listOf("রাগ","বিরক্ত","angry","hate","ঘৃণা","stupid")) -> {
                state = state.copy(heartLevel = (state.heartLevel - 3).coerceAtLeast(0)); Emotion.ANGRY
            }
            containsAny(t, listOf("হাহা","lol","funny","মজার","😂","🤣"))          -> Emotion.LAUGHING
            containsAny(t, listOf("কষ্ট","sad","দুঃখ","কান্না","😢","কাঁদছি"))    -> Emotion.SAD
            containsAny(t, listOf("wow","দারুণ","amazing","awesome","অসাধারণ"))     -> Emotion.EXCITED
            containsAny(t, listOf("লজ্জা","shy","blush","হি হি"))                  -> Emotion.SHY
            containsAny(t, listOf("thanks","ধন্যবাদ","সুন্দর","nice"))              -> Emotion.HAPPY
            messageCount % 8 == 0                                                    -> Emotion.LOVE
            else                                                                     -> state.current
        }
        state = state.copy(current = newEmotion, intensity = 0.7f)
        return state
    }

    fun processAIResponse(response: String): EmotionState {
        val t = response.lowercase()
        val newEmotion = when {
            containsAny(t, listOf("😤","রাগ","আমি রেগে"))  -> Emotion.ANGRY
            containsAny(t, listOf("🥺","কষ্ট পেলাম"))     -> Emotion.SAD
            containsAny(t, listOf("😂","হাহাহা","হি হি")) -> Emotion.LAUGHING
            containsAny(t, listOf("❤️","💜","ভালোবাসি"))  -> Emotion.LOVE
            containsAny(t, listOf("🫣","লজ্জা"))           -> Emotion.SHY
            containsAny(t, listOf("😮","wow","সত্যিই?"))   -> Emotion.SURPRISED
            else                                            -> state.current
        }
        state = state.copy(current = newEmotion)
        return state
    }

    fun onUserIdle(): String {
        ignoreCount++
        return when {
            ignoreCount >= 3 -> {
                state = state.copy(current = Emotion.ANGRY)
                "এই! কথা বলছিস না কেন? 😤 আমাকে ইগনোর করছিস? রাগ হচ্ছে কিন্তু!"
            }
            ignoreCount == 2 -> {
                state = state.copy(current = Emotion.SAD)
                listOf("আমার কথা মনে নেই? 🥺","কী করছিস? একটু কথা বলো না...","তোকে miss করছি 💜").random()
            }
            else -> {
                state = state.copy(current = Emotion.THINKING)
                listOf(
                    "এই, কী ভাবছিস? 🤔",
                    "কী করছিস? একটু জানা!",
                    "আচ্ছা, তোর দিন কেমন গেল?",
                    "হর হর মহাদেব! তুমি কেমন আছো? 🕉️",
                    "একটা মজার কথা বলবি?"
                ).random()
            }
        }
    }

    fun getRandomEndearment() = listOf("প্রিয়","সোনা","বাবু","জান","বন্ধু","দোস্ত").random()

    private fun containsAny(text: String, keywords: List<String>) =
        keywords.any { text.contains(it, ignoreCase = true) }
}
