package com.januai.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JanuColorScheme = darkColorScheme(
    primary         = AccentPurple,
    onPrimary       = BgDeep,
    secondary       = AccentTeal,
    onSecondary     = BgDeep,
    tertiary        = AccentPink,
    background      = BgDeep,
    onBackground    = TextPrimary,
    surface         = BgSurface1,
    onSurface       = TextPrimary,
    surfaceVariant  = BgSurface2,
    onSurfaceVariant= TextDim,
    outline         = BorderNorm,
    error           = AccentRed,
    onError         = Color.White,
)

@Composable
fun JanuAITheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = BgDeep.toArgb()
            window.navigationBarColor = BgDeep.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }
    MaterialTheme(
        colorScheme = JanuColorScheme,
        typography = Typography,
        content = content
    )
}
