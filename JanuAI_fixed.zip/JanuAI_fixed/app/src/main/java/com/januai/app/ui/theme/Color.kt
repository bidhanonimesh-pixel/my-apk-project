package com.januai.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Futuristic Palette
val BgDeep      = Color(0xFF06060F)
val BgSurface1  = Color(0xFF0D0D1C)
val BgSurface2  = Color(0xFF131325)
val BgSurface3  = Color(0xFF191930)
val BorderNorm  = Color(0xFF252545)
val BorderBright= Color(0xFF2A2A50)

val AccentPurple= Color(0xFF818CF8)
val AccentGreen = Color(0xFF34D399)
val AccentYellow= Color(0xFFFBBF24)
val AccentRed   = Color(0xFFF87171)
val AccentTeal  = Color(0xFF2DD4BF)
val AccentPink  = Color(0xFFF472B6)
val AccentOrange= Color(0xFFFB923C)
val AccentBlue  = Color(0xFF60A5FA)

val TextPrimary = Color(0xFFEAE8FF)
val TextDim     = Color(0xFF9896C8)
val TextMuted   = Color(0xFF525070)

// Gradient combos
val GradientUser     = listOf(Color(0xFF2D2A7A), Color(0xFF5B21B6))
val GradientAI       = listOf(Color(0xFF131325), Color(0xFF191930))
val GradientBg       = listOf(Color(0xFF06060F), Color(0xFF0D0D1C), Color(0xFF06060F))
val GradientAvatar   = listOf(Color(0xFF1E1B4B), Color(0xFF818CF8))
val GradientButton   = listOf(Color(0xFF312E81), Color(0xFF818CF8))
val GradientEmotionHappy   = listOf(Color(0xFF34D399), Color(0xFF2DD4BF))
val GradientEmotionSad     = listOf(Color(0xFF60A5FA), Color(0xFF818CF8))
val GradientEmotionAngry   = listOf(Color(0xFFF87171), Color(0xFFFB923C))
val GradientEmotionShy     = listOf(Color(0xFFF472B6), Color(0xFFF87171))
val GradientEmotionExcited = listOf(Color(0xFFFBBF24), Color(0xFFFB923C))
