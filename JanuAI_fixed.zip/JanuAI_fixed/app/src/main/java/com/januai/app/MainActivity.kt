package com.januai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.januai.app.ui.screens.ChatScreen
import com.januai.app.ui.screens.SettingsScreen
import com.januai.app.ui.screens.SplashScreen
import com.januai.app.ui.theme.JanuAITheme
import com.januai.app.ui.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JanuAITheme {
                JanuNavigation()
            }
        }
    }
}

@Composable
fun JanuNavigation() {
    var screen by remember { mutableStateOf("splash") }
    val chatViewModel: ChatViewModel = viewModel()

    when (screen) {
        "splash" -> SplashScreen(onFinish = { screen = "chat" })
        "chat"   -> ChatScreen(viewModel = chatViewModel, onOpenSettings = { screen = "settings" })
        "settings" -> SettingsScreen(viewModel = chatViewModel, onBack = { screen = "chat" })
    }
}
