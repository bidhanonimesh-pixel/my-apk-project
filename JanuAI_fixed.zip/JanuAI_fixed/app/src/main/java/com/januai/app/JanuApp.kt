package com.januai.app

import android.app.Application
import com.januai.app.data.AppDatabase

class JanuApp : Application() {
    val database by lazy { AppDatabase.get(this) }
    override fun onCreate() {
        super.onCreate()
        // Pre-warm database
        database
    }
}
