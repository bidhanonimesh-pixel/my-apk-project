package com.januai.app.ui.screens

import android.Manifest
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.januai.app.ai.Emotion
import com.januai.app.ai.EmotionState
import com.januai.app.ai.ResponseMode
import com.januai.app.ui.components.AIBubble
import com.januai.app.ui.components.UserBubble
import com.januai.app.ui.theme.*
import com.januai.app.ui.viewmodel.ChatViewModel
import com.januai.app.ui.viewmodel.UiMessage
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    var textValue by remember { mutableStateOf(TextFieldValue("")) }
    val keyboard = LocalSoftwareKeyboardController.current
    val quickReplies = listOf("হর হর মহাদেব! 🕉️", "একটা ধাঁধা দাও 🤔", "গান বাজাও 🎵", "কী কী পারিস?")

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!matches.isNullOrEmpty()) textValue = TextFieldValue(matches[0])
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty())
            listState.animateScrollToItem(uiState.messages.size - 1)
    }

    Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(GradientBg))) {
        Column(Modifier.fillMaxSize()) {
            ChatHeader(
                emotion    = uiState.emotionState,
                statusText = uiState.statusText,
                isBusy     = uiState.isBusy,
                onSettings = onOpenSettings,
                onClear    = { viewModel.clearChat() }
            )
            StatsBar(uiState.cacheCount, uiState.isOnline)

            LazyColumn(
                state            = listState,
                modifier         = Modifier.weight(1f).fillMaxWidth(),
                contentPadding   = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (uiState.messages.isEmpty()) item { EmptyState() }
                items(uiState.messages, key = { it.id }) { msg -> MessageRow(msg) }
            }

            if (!uiState.isBusy && uiState.messages.size <= 2) {
                QuickRepliesRow(quickReplies) { reply ->
                    viewModel.sendMessage(reply)
                }
            }

            InputRow(
                text       = textValue,
                onTextChange = { textValue = it; viewModel.onInputChange(it.text) },
                isBusy     = uiState.isBusy,
                onSend     = {
                    if (textValue.text.isNotBlank()) {
                        viewModel.sendMessage(textValue.text)
                        textValue = TextFieldValue("")
                        keyboard?.hide()
                    }
                },
                onVoice    = {
                    permLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "বলো... 🎤")
                    }
                    try { voiceLauncher.launch(intent) } catch (_: Exception) {}
                }
            )
        }
    }
}

private fun emotionToGradient(emotion: Emotion) = when (emotion) {
    Emotion.HAPPY, Emotion.LOVE          -> GradientEmotionHappy
    Emotion.SAD                          -> GradientEmotionSad
    Emotion.ANGRY                        -> GradientEmotionAngry
    Emotion.SHY                          -> GradientEmotionShy
    Emotion.EXCITED, Emotion.LAUGHING    -> GradientEmotionExcited
    else                                 -> GradientAvatar
}

@Composable
fun ChatHeader(
    emotion: EmotionState, statusText: String, isBusy: Boolean,
    onSettings: () -> Unit, onClear: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val rotation by infiniteTransition.animateFloat(
        0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), "rot"
    )
    val pipScale by infiniteTransition.animateFloat(
        0.85f, 1.15f, infiniteRepeatable(tween(700), RepeatMode.Reverse), "pip"
    )
    val gradient = emotionToGradient(emotion.current)

    Row(
        modifier = Modifier.fillMaxWidth().background(BgDeep.copy(alpha = 0.97f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Spinning avatar ring
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                modifier = Modifier.size(48.dp).rotate(rotation).clip(CircleShape)
                    .background(Brush.sweepGradient(gradient))
            )
            Box(
                modifier = Modifier.size(42.dp).clip(CircleShape).background(BgSurface1),
                contentAlignment = Alignment.Center
            ) { Text(emotion.current.emoji, fontSize = 22.sp) }
            Box(
                modifier = Modifier
                    .size((10 * pipScale).dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isBusy -> AccentYellow
                            statusText.contains("AI") -> AccentGreen
                            else -> TextMuted
                        }
                    )
                    .border(2.dp, BgDeep, CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Janu", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AccentPurple.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AccentPurple.copy(alpha = 0.3f))
                ) {
                    Text(
                        "Brain Lv.${emotion.heartLevel / 20 + 1}",
                        color = AccentPurple, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                if (isBusy) "● ভাবছি..." else statusText,
                color = when {
                    isBusy -> AccentYellow
                    statusText.contains("AI") -> AccentGreen
                    else -> TextMuted
                },
                fontSize = 11.sp, fontFamily = FontFamily.Monospace
            )
        }
        IconButton(onClick = onClear) {
            Icon(Icons.Default.Refresh, contentDescription = "Clear", tint = TextDim)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextDim)
        }
    }
    HorizontalDivider(color = BorderNorm, thickness = 1.dp)
}

@Composable
fun StatsBar(cacheCount: Int, isOnline: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().background(BgDeep.copy(alpha = 0.92f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatChip(if (isOnline) AccentGreen else TextMuted, if (isOnline) "AI LIVE" else "OFFLINE")
        StatChip(AccentBlue,   "Cache $cacheCount")
        StatChip(AccentPurple, "Hybrid AI")
        StatChip(AccentTeal,   "Bengali 🇧🇩")
        StatChip(AccentPink,   "Girlfriend AI 💜")
    }
    HorizontalDivider(color = BorderNorm, thickness = 1.dp)
}

@Composable
fun StatChip(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(label, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun MessageRow(msg: UiMessage) {
    val ts = SimpleDateFormat("HH:mm", Locale.getDefault()).format(msg.timestamp)
    if (msg.role == "user") {
        UserBubble(text = msg.text, timestamp = ts)
    } else {
        AIBubble(text = msg.text, isStreaming = msg.isStreaming, modeLabel = msg.modeLabel, timestamp = ts)
    }
}

@Composable
fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🌸", fontSize = 56.sp)
        Spacer(Modifier.height(12.dp))
        Text("Janu AI", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("কথা বলতে শুরু করো! 💜", color = TextDim, fontSize = 13.sp)
    }
}

@Composable
fun QuickRepliesRow(replies: List<String>, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        replies.forEach { reply ->
            OutlinedButton(
                onClick = { onSelect(reply) },
                shape   = RoundedCornerShape(20.dp),
                border  = BorderStroke(1.dp, BorderNorm),
                colors  = ButtonDefaults.outlinedButtonColors(containerColor = BgSurface2, contentColor = TextPrimary),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) { Text(reply, fontSize = 12.sp) }
        }
    }
}

@Composable
fun InputRow(
    text: TextFieldValue, onTextChange: (TextFieldValue) -> Unit,
    isBusy: Boolean, onSend: () -> Unit, onVoice: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(BgDeep.copy(alpha = 0.98f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = text, onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("যা মনে চায় লেখো...", color = TextMuted, fontSize = 14.sp) },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = AccentPurple.copy(alpha = 0.6f),
                unfocusedBorderColor = BorderNorm,
                focusedTextColor     = TextPrimary,
                unfocusedTextColor   = TextPrimary,
                cursorColor          = AccentPurple,
                focusedContainerColor   = BgSurface3,
                unfocusedContainerColor = BgSurface3
            ),
            maxLines  = 5,
            textStyle = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
            enabled   = !isBusy
        )
        // Voice
        IconButton(
            onClick  = onVoice,
            modifier = Modifier.size(46.dp).clip(CircleShape)
                .background(BgSurface3).border(1.dp, BorderNorm, CircleShape)
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Voice", tint = TextDim, modifier = Modifier.size(20.dp))
        }
        // Send
        IconButton(
            onClick  = onSend,
            enabled  = text.text.isNotBlank() && !isBusy,
            modifier = Modifier.size(46.dp).clip(CircleShape).background(
                if (text.text.isNotBlank() && !isBusy) Brush.linearGradient(GradientButton)
                else Brush.linearGradient(listOf(BgSurface2, BgSurface3))
            )
        ) {
            if (isBusy) {
                CircularProgressIndicator(color = AccentPurple, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Icon(
                    Icons.Default.Send, contentDescription = "Send",
                    tint = if (text.text.isNotBlank()) Color.White else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
