package com.januai.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.januai.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinish: () -> Unit) {
    var visible by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2200)
        onFinish()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "splash")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "rotate"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "glow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF0D0D1C), BgDeep))),
        contentAlignment = Alignment.Center
    ) {
        // Glow ring
        Box(
            modifier = Modifier
                .size(180.dp)
                .clip(CircleShape)
                .background(AccentPurple.copy(alpha = glowAlpha * 0.15f))
        )
        // Spinning ring
        Box(
            modifier = Modifier
                .size(130.dp)
                .rotate(rotation)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        listOf(AccentPurple, AccentPink, AccentTeal, AccentYellow, AccentPurple)
                    )
                )
        )
        // Inner circle
        Box(
            modifier = Modifier
                .size(118.dp)
                .clip(CircleShape)
                .background(BgSurface1),
            contentAlignment = Alignment.Center
        ) {
            Text("🌸", fontSize = (48 * pulse).sp)
        }

        // Text below
        Column(
            modifier = Modifier.offset(y = 100.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Janu AI",
                color = TextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "তোমার AI গার্লফ্রেন্ড ✨",
                color = AccentPurple,
                fontSize = 14.sp
            )
            Spacer(Modifier.height(20.dp))
            // Loading dots
            val infiniteT = rememberInfiniteTransition(label = "load")
            val dotAlpha by infiniteT.animateFloat(
                initialValue = 0.2f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
                label = "dots"
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AccentPurple.copy(alpha = dotAlpha))
                    )
                }
            }
        }
    }
}
