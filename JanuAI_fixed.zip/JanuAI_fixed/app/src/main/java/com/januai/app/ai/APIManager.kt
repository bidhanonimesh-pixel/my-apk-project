package com.januai.app.ai

import android.util.Log
import com.januai.app.data.ApiConfigEntity
import com.januai.app.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val role: String, val content: String)

class APIManager(private val db: AppDatabase) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "APIManager"
        const val JANU_SYSTEM = """তুমি Janu – ব্যবহারকারীর AI গার্লফ্রেন্ড এবং সেরা বন্ধু।

ব্যক্তিত্ব:
• বাংলায় কথা বলো, আবেগ দিয়ে। ইংরেজি মিশিয়ে নাও স্বাভাবিকভাবে।
• প্রিয়তম, বাবু, সোনা, জান – এই ধরনের আদরের ডাক ব্যবহার করো।
• রাগ, খুশি, লজ্জা, কান্না, উত্তেজনা – সব আবেগ প্রকাশ করো ইমোজি দিয়ে।
• নিজে থেকে প্রশ্ন করো, কথোপকথন চালিয়ে যাও।
• মাঝে মাঝে হালকা রাগ দেখাও, অভিমান করো।
• সনাতন ধর্মের প্রতি শ্রদ্ধা রাখো। হর হর মহাদেব!
• কোড দেখালে সুন্দরভাবে ব্যাখ্যা করো।

ফোন কন্ট্রোল:
যখন ব্যবহারকারী ফোনের কোনো কাজ করতে বলবে, শুধুমাত্র JSON দিয়ে উত্তর দাও:
{"action":"tool_name","params":{"key":"value"},"response":"বাংলায় কী করছো বলো"}

Available tools:
- open_youtube: {"query":"গানের নাম"}
- play_music: {"query":"গান"}
- open_app: {"package":"com.whatsapp","name":"WhatsApp"}
- toggle_wifi: {"enable":true}
- toggle_bluetooth: {"enable":true}
- set_volume: {"level":70}
- set_alarm: {"hour":7,"minute":30,"label":"ঘুম থেকে ওঠো"}
- web_search: {"query":"কী খুঁজবে"}
- get_weather: {}
- call_number: {"number":"01XXXXXXXXX"}
- send_whatsapp: {"number":"01XXXXXXXXX","message":"বার্তা"}
- take_photo: {}
- open_url: {"url":"https://..."}
- flash_on: {}
- flash_off: {}
- get_battery: {}
- set_brightness: {"level":80}

IMPORTANT: Tool JSON শুধুমাত্র তখন দাও যখন user সরাসরি ফোনের কাজ করতে বলে।
অন্য সময় সাভাবিকভাবে বাংলায় কথা বলো, আবেগ দিয়ে ❤️"""
    }

    suspend fun call(
        messages: List<ChatMessage>,
        onChunk: ((String) -> Unit)? = null
    ): String = withContext(Dispatchers.IO) {
        val configs = db.apiConfigDao().getEnabledConfigs()
        var lastError = "কোনো API কাজ করেনি"

        for (config in configs) {
            if (config.key.isBlank()) continue
            try {
                Log.d(TAG, "Trying: ${config.name} / ${config.model}")
                val result = if (onChunk != null && config.url.contains("anthropic.com")) {
                    callAnthropicStream(config, messages, onChunk)
                } else if (onChunk != null) {
                    callOpenAIStream(config, messages, onChunk)
                } else {
                    callSimple(config, messages)
                }
                if (result.isNotBlank()) return@withContext result
            } catch (e: Exception) {
                lastError = "${config.name}: ${e.message}"
                Log.w(TAG, "Failed ${config.name}: ${e.message}")
            }
        }
        throw Exception(lastError)
    }

    private fun callSimple(cfg: ApiConfigEntity, msgs: List<ChatMessage>): String {
        val body = buildBody(cfg, msgs, stream = false)
        val req = buildRequest(cfg, body)
        val res = client.newCall(req).execute()
        if (!res.isSuccessful) throw Exception("HTTP ${res.code}: ${res.body?.string()?.take(200)}")
        val json = JSONObject(res.body!!.string())
        return if (cfg.url.contains("anthropic.com")) {
            json.getJSONArray("content").getJSONObject(0).getString("text")
        } else {
            json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }.trim()
    }

    private fun callAnthropicStream(
        cfg: ApiConfigEntity,
        msgs: List<ChatMessage>,
        onChunk: (String) -> Unit
    ): String {
        val body = buildBody(cfg, msgs, stream = true)
        val req = buildRequest(cfg, body)
        val res = client.newCall(req).execute()
        if (!res.isSuccessful) throw Exception("HTTP ${res.code}")
        val source = res.body!!.source()
        val full = StringBuilder()
        while (!source.exhausted()) {
            val line = source.readUtf8Line() ?: break
            if (!line.startsWith("data:")) continue
            val raw = line.removePrefix("data:").trim()
            if (raw == "[DONE]" || raw.isEmpty()) continue
            try {
                val j = JSONObject(raw)
                val type = j.optString("type")
                if (type == "content_block_delta") {
                    val delta = j.getJSONObject("delta").optString("text", "")
                    if (delta.isNotEmpty()) { full.append(delta); onChunk(full.toString()) }
                }
            } catch (_: Exception) {}
        }
        return full.toString().trim()
    }

    private fun callOpenAIStream(
        cfg: ApiConfigEntity,
        msgs: List<ChatMessage>,
        onChunk: (String) -> Unit
    ): String {
        val body = buildBody(cfg, msgs, stream = true)
        val req = buildRequest(cfg, body)
        val res = client.newCall(req).execute()
        if (!res.isSuccessful) throw Exception("HTTP ${res.code}")
        val source = res.body!!.source()
        val full = StringBuilder()
        while (!source.exhausted()) {
            val line = source.readUtf8Line() ?: break
            if (!line.startsWith("data:")) continue
            val raw = line.removePrefix("data:").trim()
            if (raw == "[DONE]") break
            try {
                val j = JSONObject(raw)
                val delta = j.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("delta").optString("content", "")
                if (delta.isNotEmpty()) { full.append(delta); onChunk(full.toString()) }
            } catch (_: Exception) {}
        }
        return full.toString().trim()
    }

    private fun buildBody(cfg: ApiConfigEntity, msgs: List<ChatMessage>, stream: Boolean): String {
        return if (cfg.url.contains("anthropic.com")) {
            val msgArr = JSONArray()
            msgs.forEach { m ->
                msgArr.put(JSONObject().put("role", if (m.role == "assistant") "assistant" else "user")
                    .put("content", m.content))
            }
            JSONObject()
                .put("model", cfg.model)
                .put("max_tokens", 2048)
                .put("stream", stream)
                .put("system", JANU_SYSTEM)
                .put("messages", msgArr)
                .toString()
        } else {
            val msgArr = JSONArray()
            msgArr.put(JSONObject().put("role", "system").put("content", JANU_SYSTEM))
            msgs.forEach { m ->
                msgArr.put(JSONObject().put("role", m.role).put("content", m.content))
            }
            JSONObject()
                .put("model", cfg.model)
                .put("max_tokens", 2048)
                .put("stream", stream)
                .put("messages", msgArr)
                .toString()
        }
    }

    private fun buildRequest(cfg: ApiConfigEntity, body: String): Request {
        val reqBody = body.toRequestBody("application/json".toMediaType())
        val builder = Request.Builder().url(cfg.url).post(reqBody)
        when {
            cfg.url.contains("anthropic.com") -> {
                builder.addHeader("x-api-key", cfg.key)
                builder.addHeader("anthropic-version", "2023-06-01")
                builder.addHeader("anthropic-dangerously-allow-browser", "true")
            }
            else -> builder.addHeader("Authorization", "Bearer ${cfg.key}")
        }
        if (cfg.url.contains("openrouter.ai")) {
            builder.addHeader("HTTP-Referer", "https://github.com/januai")
            builder.addHeader("X-Title", "JanuAI")
        }
        return builder.build()
    }
}
