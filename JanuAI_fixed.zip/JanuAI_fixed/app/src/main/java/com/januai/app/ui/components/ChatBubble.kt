package com.januai.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.januai.app.ui.theme.*

@Composable
fun UserBubble(text: String, timestamp: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Column(horizontalAlignment = Alignment.End) {
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                    .background(Brush.linearGradient(GradientUser))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = parseMarkdown(text),
                    color = Color.White,
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )
            }
            Text(
                text = timestamp,
                color = TextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(end = 4.dp, top = 3.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF1E3A5F), Color(0xFF3B82F6)))),
            contentAlignment = Alignment.Center
        ) { Text("😊", fontSize = 16.sp) }
    }
}

@Composable
fun AIBubble(text: String, isStreaming: Boolean, modeLabel: String, timestamp: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(GradientAvatar)),
            contentAlignment = Alignment.Center
        ) { Text("🌸", fontSize = 16.sp) }
        Spacer(Modifier.width(8.dp))
        Column {
            if (modeLabel.isNotBlank()) {
                ModeBadge(modeLabel)
                Spacer(Modifier.height(3.dp))
            }
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp))
                    .background(BgSurface2)
                    .border(1.dp, BorderNorm, RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (isStreaming && text.isEmpty()) {
                    TypingDotsIndicator()
                } else {
                    Text(
                        text = parseMarkdown(text),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 22.sp
                    )
                }
            }
            if (!isStreaming) {
                Text(
                    text = timestamp,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(start = 4.dp, top = 3.dp)
                )
            }
        }
    }
}

@Composable
fun TypingDotsIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "typing")
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        repeat(3) { index ->
            val alpha by infiniteTransition.animateFloat(
                initialValue = 0.3f, targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 200),
                    repeatMode = RepeatMode.Reverse
                ), label = "dot$index"
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(AccentPurple.copy(alpha = alpha))
            )
            if (index < 2) Spacer(Modifier.width(4.dp))
        }
    }
}

@Composable
fun ModeBadge(label: String) {
    val (color, bg) = when {
        label.contains("Live") -> Pair(AccentGreen, AccentGreen.copy(alpha = 0.08f))
        label.contains("Cache") -> Pair(AccentTeal, AccentTeal.copy(alpha = 0.08f))
        else -> Pair(TextMuted, Color.Transparent)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(label, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

fun parseMarkdown(text: String) = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = AccentPurple))
                    append(text.substring(i + 2, end))
                    pop(); i = end + 2
                } else { append(text[i]); i++ }
            }
            text.startsWith("*", i) && !text.startsWith("**", i) -> {
                val end = text.indexOf("*", i + 1)
                if (end != -1) {
                    pushStyle(SpanStyle(color = AccentTeal))
                    append(text.substring(i + 1, end))
                    pop(); i = end + 1
                } else { append(text[i]); i++ }
            }
            text.startsWith("`", i) -> {
                val end = text.indexOf("`", i + 1)
                if (end != -1) {
                    pushStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = AccentYellow, background = BgSurface3))
                    append(text.substring(i + 1, end))
                    pop(); i = end + 1
                } else { append(text[i]); i++ }
            }
            else -> { append(text[i]); i++ }
        }
    }
}
