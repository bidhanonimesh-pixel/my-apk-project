package com.januai.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(limit: Int = 20): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: MessageEntity): Long

    @Query("DELETE FROM messages")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun count(): Int
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE key = :key")
    suspend fun get(key: String): MemoryEntity?

    @Query("SELECT * FROM memories WHERE category = :category ORDER BY importance DESC")
    suspend fun getByCategory(category: String): List<MemoryEntity>

    @Query("SELECT * FROM memories ORDER BY importance DESC LIMIT 20")
    suspend fun getTopMemories(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE value LIKE '%' || :query || '%' LIMIT 5")
    suspend fun search(query: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(memory: MemoryEntity)

    @Delete
    suspend fun delete(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE key = :key")
    suspend fun deleteByKey(key: String)
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM cache")
    suspend fun getAll(): List<CacheEntity>

    @Query("SELECT COUNT(*) FROM cache")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: CacheEntity)

    @Query("UPDATE cache SET uses = uses + 1 WHERE id = :id")
    suspend fun incrementUse(id: Long)
}

@Dao
interface ApiConfigDao {
    @Query("SELECT * FROM api_configs WHERE enabled = 1 ORDER BY priority ASC")
    suspend fun getEnabledConfigs(): List<ApiConfigEntity>

    @Query("SELECT * FROM api_configs ORDER BY priority ASC")
    fun getAllConfigs(): Flow<List<ApiConfigEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(config: ApiConfigEntity)

    @Query("DELETE FROM api_configs WHERE name = :name")
    suspend fun delete(name: String)
}
