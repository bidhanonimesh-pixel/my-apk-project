package com.januai.app.ai

import android.content.Context
import android.util.Log
import com.januai.app.data.AppDatabase
import com.januai.app.data.CacheEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ResponseMode { LIVE, CACHE, OFFLINE, ERROR }

data class AIResponse(
    val text: String,
    val mode: ResponseMode,
    val toolResult: ToolResult? = null
)

class AIEngine(private val context: Context, private val db: AppDatabase) {

    private val api     = APIManager(db)
    private val kb      = OfflineKB()
    val emotion         = EmotionEngine()
    val memory          = MemorySystem(db)
    val tools           = ToolSystem(context)

    companion object {
        private const val TAG            = "AIEngine"
        private const val CACHE_THRESHOLD = 0.60
        private const val MAX_HISTORY     = 16
    }

    suspend fun respond(
        userMessage: String,
        history: List<ChatMessage>,
        onChunk: ((String) -> Unit)? = null
    ): AIResponse = withContext(Dispatchers.IO) {

        // ১. আবেগ প্রক্রিয়া ও স্মৃতি সংরক্ষণ
        emotion.processUserMessage(userMessage)
        memory.extractAndSave(userMessage, "")

        // ২. Offline KB — তাৎক্ষণিক উত্তর
        val kbHit = kb.search(userMessage)
        if (kbHit != null) {
            // KB উত্তরের সাথে emotional layer যোগ করো
            val enriched = emotion.buildEmotionalResponse(kbHit, userMessage)
            emotion.processAIResponse(enriched)
            return@withContext AIResponse(enriched, ResponseMode.OFFLINE)
        }

        // ৩. API call (online)
        return@withContext try {
            val msgs  = buildMessages(userMessage, history)
            val raw   = api.call(msgs, onChunk)
            val trimmed = raw.trim()

            // Tool call চেক
            val toolResult = if (trimmed.startsWith("{") || trimmed.contains("\"action\"")) {
                tools.parseAndExecute(trimmed)
            } else null

            val baseText    = toolResult?.userFeedback ?: trimmed

            // Emotional enrichment — Janu-র নিজস্ব রং দেওয়া
            val enrichedText = emotion.buildEmotionalResponse(baseText, userMessage)

            emotion.processAIResponse(enrichedText)

            // Project assistance hint (প্রজেক্ট-সম্পর্কিত হলে)
            val projectHint = emotion.getProjectAssistanceHint(userMessage)
            val finalText   = if (projectHint.isNotBlank() && baseText.length > 50)
                                "$enrichedText\n\n$projectHint"
                              else enrichedText

            // ক্যাশ সংরক্ষণ
            try {
                db.cacheDao().insert(CacheEntity(question = userMessage, answer = finalText))
            } catch (_: Exception) {}

            AIResponse(finalText, ResponseMode.LIVE, toolResult)

        } catch (apiError: Exception) {
            Log.w(TAG, "API failed: ${apiError.message}")

            // ৪. ক্যাশ থেকে খোঁজা
            val cached = findInCache(userMessage)
            if (cached != null) {
                return@withContext AIResponse(cached, ResponseMode.CACHE)
            }

            // ৫. Fallback — emotional
            val fallback = getEmotionalFallback()
            AIResponse(fallback, ResponseMode.OFFLINE)
        }
    }

    private fun buildMessages(userMessage: String, history: List<ChatMessage>): List<ChatMessage> {
        val msgs = mutableListOf<ChatMessage>()

        // Emotion context system-এ যোগ করা
        val emotionCtx = emotion.getEmotionalSystemContext()
        // (system prompt APIManager-এ handle হয়, এখানে শুধু history)

        val recentHistory = history.takeLast(MAX_HISTORY)
        msgs.addAll(recentHistory)
        msgs.add(ChatMessage("user", userMessage))
        return msgs
    }

    private suspend fun findInCache(query: String): String? = withContext(Dispatchers.IO) {
        val all = db.cacheDao().getAll()
        var best: String? = null
        var bestScore = CACHE_THRESHOLD
        for (entry in all) {
            val score = kb.cosineSimilarity(query, entry.question)
            if (score > bestScore) {
                bestScore = score
                best = entry.answer
            }
        }
        best
    }

    private fun getEmotionalFallback(): String {
        val endear = emotion.getEndearment()
        return when {
            emotion.getHeartLevel() > 80 -> listOf(
                "ইন্টারনেট নেই $endear 😔 কিন্তু আমি তো আছি! Settings-এ API Key দিলে সব পারব।",
                "উফ! এখন offline আছি 🥺 Settings-এ API Key দাও, তারপর সব উত্তর পাবি!",
                "নেট নেই রে $endear 😅 কিন্তু ভালোবাসা আছে! Settings সেট করো।"
            ).random()

            emotion.isJanuHappy() -> listOf(
                "ইন্টারনেট কানেকশন ভালো না $endear 🥺 Settings-এ API Key দিলে সব পারব!",
                "আজকে network মুডে নেই মনে হচ্ছে 😅 API Key দাও, তারপর দেখো কী করি!"
            ).random()

            else -> listOf(
                "এই প্রশ্নের উত্তর এখন দিতে পারছি না $endear 😔 Settings-এ API Key সেট করো।",
                "Offline mode-এ আছি 🧠 Settings থেকে API Key দিলে AI-powered হয়ে যাব!"
            ).random()
        }
    }

    fun getModeLabel(mode: ResponseMode): String = when (mode) {
        ResponseMode.LIVE    -> "⚡ AI Live"
        ResponseMode.CACHE   -> "💾 Cache"
        ResponseMode.OFFLINE -> "🧠 Offline Brain"
        ResponseMode.ERROR   -> "⚠️ Error"
    }
}
