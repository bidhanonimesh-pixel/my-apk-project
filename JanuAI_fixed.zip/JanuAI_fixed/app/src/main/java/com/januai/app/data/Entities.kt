package com.januai.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,       // "user" | "ai"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val emotion: String = "neutral",
    val mode: String = "offline"  // "live" | "cache" | "offline"
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val key: String,
    val value: String,
    val category: String = "general",  // "user_info" | "preference" | "fact" | "general"
    val importance: Int = 5,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cache")
data class CacheEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val question: String,
    val answer: String,
    val uses: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "api_configs")
data class ApiConfigEntity(
    @PrimaryKey val name: String,
    val url: String,
    val key: String = "",
    val model: String,
    val enabled: Boolean = true,
    val priority: Int = 0
)
