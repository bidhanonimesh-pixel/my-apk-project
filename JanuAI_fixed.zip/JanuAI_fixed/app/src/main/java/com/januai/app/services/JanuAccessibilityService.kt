package com.januai.app.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JanuAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JanuA11y"
        var instance: JanuAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility Service connected ✓")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> { /* can be used for screen monitoring */ }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> { /* notification handling */ }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ── Public API for ToolSystem ──

    fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        return node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    fun findAndClick(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        return if (nodes.isNotEmpty()) {
            nodes.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else false
    }

    fun performGlobalBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun performSwipeDown() {
        val displayMetrics = resources.displayMetrics
        val w = displayMetrics.widthPixels.toFloat()
        val h = displayMetrics.heightPixels.toFloat()
        val path = Path().apply {
            moveTo(w / 2, h * 0.1f)
            lineTo(w / 2, h * 0.7f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun skipAd(): Boolean {
        val keywords = listOf("Skip Ad", "Skip", "এড়িয়ে যান", "বাতিল", "Close", "×")
        for (kw in keywords) {
            if (findAndClick(kw)) return true
        }
        return false
    }

    fun readScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        extractText(root, sb)
        return sb.toString().take(1000)
    }

    private fun extractText(node: AccessibilityNodeInfo?, sb: StringBuilder) {
        node ?: return
        node.text?.let { sb.appendLine(it) }
        for (i in 0 until node.childCount) extractText(node.getChild(i), sb)
    }
}
