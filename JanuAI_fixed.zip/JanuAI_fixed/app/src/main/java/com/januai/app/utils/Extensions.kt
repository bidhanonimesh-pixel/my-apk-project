package com.januai.app.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Long.toTimeString(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(this))

fun Long.toDateTimeString(): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(this))

fun String.truncate(max: Int = 80): String =
    if (length > max) take(max) + "…" else this

fun String.containsAny(keywords: List<String>, ignoreCase: Boolean = true): Boolean =
    keywords.any { this.contains(it, ignoreCase) }

fun String.isValidUrl(): Boolean =
    startsWith("http://") || startsWith("https://")

fun extractJsonBlock(text: String): String? {
    val start = text.indexOf('{')
    val end = text.lastIndexOf('}')
    return if (start != -1 && end > start) text.substring(start, end + 1) else null
}
