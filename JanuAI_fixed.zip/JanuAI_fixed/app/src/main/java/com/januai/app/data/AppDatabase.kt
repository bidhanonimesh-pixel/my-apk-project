package com.januai.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [MessageEntity::class, MemoryEntity::class, CacheEntity::class, ApiConfigEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun cacheDao(): CacheDao
    abstract fun apiConfigDao(): ApiConfigDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "janu_ai.db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch { seedDefaults(context) }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
            }
        }

        private suspend fun seedDefaults(context: Context) {
            val db = get(context)
            val defaultConfigs = listOf(
                ApiConfigEntity("Anthropic",    "https://api.anthropic.com/v1/messages",                         "", "claude-3-5-haiku-20241022",          true, 0),
                ApiConfigEntity("OR-Llama",     "https://openrouter.ai/api/v1/chat/completions",                 "", "meta-llama/llama-3.1-8b-instruct:free", true, 1),
                ApiConfigEntity("OR-Gemma",     "https://openrouter.ai/api/v1/chat/completions",                 "", "google/gemma-2-9b-it:free",           true, 2),
                ApiConfigEntity("OR-Mistral",   "https://openrouter.ai/api/v1/chat/completions",                 "", "mistralai/mistral-7b-instruct:free",  true, 3),
                ApiConfigEntity("Groq",         "https://api.groq.com/openai/v1/chat/completions",               "", "llama-3.1-8b-instant",               true, 4),
                ApiConfigEntity("Gemini",       "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "", "gemini-2.0-flash", true, 5),
            )
            defaultConfigs.forEach { db.apiConfigDao().upsert(it) }
        }
    }
}
