package com.januai.app.ai

import com.januai.app.data.AppDatabase
import com.januai.app.data.MemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MemorySystem(private val db: AppDatabase) {

    suspend fun remember(key: String, value: String, category: String = "general", importance: Int = 5) {
        withContext(Dispatchers.IO) {
            db.memoryDao().upsert(MemoryEntity(key, value, category, importance))
        }
    }

    suspend fun recall(key: String): String? {
        return withContext(Dispatchers.IO) {
            db.memoryDao().get(key)?.value
        }
    }

    suspend fun search(query: String): List<MemoryEntity> {
        return withContext(Dispatchers.IO) {
            db.memoryDao().search(query)
        }
    }

    suspend fun getContext(): String {
        return withContext(Dispatchers.IO) {
            val top = db.memoryDao().getTopMemories()
            if (top.isEmpty()) return@withContext ""
            val sb = StringBuilder("Known facts about user:\n")
            top.forEach { sb.append("• ${it.key}: ${it.value}\n") }
            sb.toString()
        }
    }

    suspend fun extractAndSave(userText: String, aiResponse: String) {
        withContext(Dispatchers.IO) {
            Regex("""আমার নাম\s+(\S+)""", RegexOption.IGNORE_CASE).find(userText)?.let {
                remember("user_name", it.groupValues[1], "user_info", 10)
            }
            Regex("""আমার বয়স\s+(\d+)""").find(userText)?.let {
                remember("user_age", it.groupValues[1], "user_info", 8)
            }
            Regex("""আমি\s+(\S+)\s+(?:থাকি|এ থাকি|তে থাকি)""", RegexOption.IGNORE_CASE).find(userText)?.let {
                remember("user_location", it.groupValues[1], "user_info", 7)
            }
            Regex("""(?:আমি|আমার)\s+(?:ভালো লাগে|পছন্দ)\s+(.+)""", RegexOption.IGNORE_CASE).find(userText)?.let {
                remember("user_interest", it.groupValues[1].take(50), "preference", 6)
            }
        }
    }
}
