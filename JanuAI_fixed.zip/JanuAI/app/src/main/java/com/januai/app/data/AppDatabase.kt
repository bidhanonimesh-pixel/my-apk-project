package com.januai.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MessageEntity::class, MemoryEntity::class, CacheEntity::class, ApiConfigEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun cacheDao(): CacheDao
    abstract fun apiConfigDao(): ApiConfigDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDb(context).also { INSTANCE = it }
            }

        private fun buildDb(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "janu_ai.db"
            )
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()

        /** Call this once after get() to seed default API configs */
        suspend fun seedIfEmpty(db: AppDatabase) {
            val existing = db.apiConfigDao().getEnabledConfigs()
            if (existing.isNotEmpty()) return
            listOf(
                ApiConfigEntity("Anthropic",  "https://api.anthropic.com/v1/messages",                                             "", "claude-3-5-haiku-20241022",             true, 0),
                ApiConfigEntity("OR-Llama",   "https://openrouter.ai/api/v1/chat/completions",                                     "", "meta-llama/llama-3.1-8b-instruct:free", true, 1),
                ApiConfigEntity("OR-Gemma",   "https://openrouter.ai/api/v1/chat/completions",                                     "", "google/gemma-2-9b-it:free",             true, 2),
                ApiConfigEntity("OR-Mistral", "https://openrouter.ai/api/v1/chat/completions",                                     "", "mistralai/mistral-7b-instruct:free",    true, 3),
                ApiConfigEntity("Groq",       "https://api.groq.com/openai/v1/chat/completions",                                   "", "llama-3.1-8b-instant",                 true, 4),
                ApiConfigEntity("Gemini",     "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",           "", "gemini-2.0-flash",                     true, 5),
            ).forEach { db.apiConfigDao().upsert(it) }
        }
    }
}
