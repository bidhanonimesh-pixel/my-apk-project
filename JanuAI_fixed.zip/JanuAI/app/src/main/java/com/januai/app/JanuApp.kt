package com.januai.app

import android.app.Application
import com.januai.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JanuApp : Application() {
    val database by lazy { AppDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        // Pre-warm DB and seed defaults
        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.seedIfEmpty(database)
        }
    }
}
