package com.januai.app.ai

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import org.json.JSONObject

data class ToolResult(
    val success: Boolean,
    val userFeedback: String,
    val toolName: String
)

class ToolSystem(private val context: Context) {

    companion object { private const val TAG = "ToolSystem" }

    fun parseAndExecute(text: String): ToolResult? {
        val json = extractJSON(text) ?: return null
        return try {
            val obj = JSONObject(json)
            val action = obj.optString("action", "")
            val params = obj.optJSONObject("params") ?: JSONObject()
            val response = obj.optString("response", "")
            if (action.isBlank()) return null
            execute(action, params, response)
        } catch (e: Exception) {
            Log.w(TAG, "Tool parse error: ${e.message}")
            null
        }
    }

    private fun execute(action: String, params: JSONObject, response: String): ToolResult {
        return when (action) {
            "open_youtube" -> {
                val query = params.optString("query", "")
                openYouTube(query)
                ToolResult(true, response.ifEmpty { "YouTube খুলছি! 🎬" }, action)
            }
            "play_music" -> {
                val query = params.optString("query", "")
                playMusic(query)
                ToolResult(true, response.ifEmpty { "গান বাজাচ্ছি! 🎵" }, action)
            }
            "open_app" -> {
                val pkg = params.optString("package", "")
                val name = params.optString("name", pkg)
                val ok = openApp(pkg)
                ToolResult(ok, if (ok) response.ifEmpty { "$name খুলছি! 📱" } else "$name খুলতে পারলাম না 😔", action)
            }
            "toggle_wifi" -> {
                val enable = params.optBoolean("enable", true)
                toggleWifi(enable)
                ToolResult(true, response.ifEmpty { "WiFi ${if (enable) "চালু" else "বন্ধ"} করছি! 📶" }, action)
            }
            "toggle_bluetooth" -> {
                val enable = params.optBoolean("enable", true)
                toggleBluetooth(enable)
                ToolResult(true, response.ifEmpty { "Bluetooth ${if (enable) "চালু" else "বন্ধ"} করছি! 🔵" }, action)
            }
            "set_volume" -> {
                val level = params.optInt("level", 50)
                setVolume(level)
                ToolResult(true, response.ifEmpty { "Volume ${level}% করলাম! 🔊" }, action)
            }
            "set_alarm" -> {
                val hour = params.optInt("hour", 7)
                val minute = params.optInt("minute", 0)
                val label = params.optString("label", "Janu Alarm")
                setAlarm(hour, minute, label)
                ToolResult(true, response.ifEmpty { "Alarm set! ⏰ ${hour.toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}" }, action)
            }
            "web_search" -> {
                val query = params.optString("query", "")
                webSearch(query)
                ToolResult(true, response.ifEmpty { "\"$query\" খুঁজছি! 🔍" }, action)
            }
            "get_weather" -> {
                openWeather()
                ToolResult(true, response.ifEmpty { "আবহাওয়া দেখছি! 🌤️" }, action)
            }
            "call_number" -> {
                val number = params.optString("number", "")
                callNumber(number)
                ToolResult(true, response.ifEmpty { "$number এ কল করছি! 📞" }, action)
            }
            "send_whatsapp" -> {
                val number = params.optString("number", "")
                val msg = params.optString("message", "")
                sendWhatsApp(number, msg)
                ToolResult(true, response.ifEmpty { "WhatsApp বার্তা পাঠাচ্ছি! 💬" }, action)
            }
            "take_photo" -> {
                takePhoto()
                ToolResult(true, response.ifEmpty { "Camera খুলছি! 📷" }, action)
            }
            "open_url" -> {
                val url = params.optString("url", "")
                openUrl(url)
                ToolResult(true, response.ifEmpty { "খুলছি! 🌐" }, action)
            }
            "flash_on" -> {
                setFlash(true)
                ToolResult(true, response.ifEmpty { "Flashlight চালু! 🔦" }, action)
            }
            "flash_off" -> {
                setFlash(false)
                ToolResult(true, response.ifEmpty { "Flashlight বন্ধ!" }, action)
            }
            "get_battery" -> {
                val level = getBatteryLevel()
                ToolResult(true, "🔋 Battery: **$level%**", action)
            }
            "set_brightness" -> {
                val level = params.optInt("level", 80)
                openBrightnessSetting()
                ToolResult(true, response.ifEmpty { "Brightness settings খুলছি! ☀️" }, action)
            }
            else -> ToolResult(false, "এই কাজটা এখনো শিখিনি 😔 (action: $action)", action)
        }
    }

    private fun openYouTube(query: String) {
        try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        }
    }

    private fun playMusic(query: String) {
        try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.spotify.music")
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            openYouTube(query) // fallback to YouTube
        }
    }

    private fun openApp(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            if (intent != null) { context.startActivity(intent); true } else false
        } catch (_: Exception) { false }
    }

    private fun toggleWifi(enable: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.startActivity(Intent(Settings.Panel.ACTION_WIFI).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = enable
        }
    }

    private fun toggleBluetooth(enable: Boolean) {
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = bm?.adapter
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } else {
            @Suppress("DEPRECATION")
            if (enable) adapter?.enable() else adapter?.disable()
        }
    }

    private fun setVolume(level: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (level * max / 100).coerceIn(0, max), 0)
    }

    private fun setAlarm(hour: Int, minute: Int, label: String) {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun webSearch(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun openWeather() {
        val uri = Uri.parse("https://wttr.in/Jamalpur")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun callNumber(number: String) {
        val uri = Uri.parse("tel:$number")
        context.startActivity(Intent(Intent.ACTION_CALL, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun sendWhatsApp(number: String, message: String) {
        try {
            val uri = Uri.parse("https://wa.me/${number.replace("+","").replace(" ","")}?text=${Uri.encode(message)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        } catch (_: Exception) {}
    }

    private fun takePhoto() {
        context.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun openUrl(url: String) {
        val uri = Uri.parse(if (url.startsWith("http")) url else "https://$url")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun setFlash(on: Boolean) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return
            cm.setTorchMode(cameraId, on)
        } catch (e: Exception) { Log.w(TAG, "Flash error: ${e.message}") }
    }

    private fun getBatteryLevel(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun openBrightnessSetting() {
        context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }

    private fun extractJSON(text: String): String? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        return if (start != -1 && end > start) text.substring(start, end + 1) else null
    }
}

