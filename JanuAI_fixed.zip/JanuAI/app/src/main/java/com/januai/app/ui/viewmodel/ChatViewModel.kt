package com.januai.app.ui.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.januai.app.ai.AIEngine
import com.januai.app.ai.ChatMessage
import com.januai.app.ai.Emotion
import com.januai.app.ai.EmotionState
import com.januai.app.ai.ResponseMode
import com.januai.app.data.AppDatabase
import com.januai.app.data.ApiConfigEntity
import com.januai.app.data.MessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class UiMessage(
    val id: Long = System.currentTimeMillis(),
    val role: String,   // "user" | "ai"
    val text: String,
    val isStreaming: Boolean = false,
    val mode: ResponseMode = ResponseMode.OFFLINE,
    val modeLabel: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatUiState(
    val messages: List<UiMessage> = emptyList(),
    val inputText: String = "",
    val isBusy: Boolean = false,
    val isListening: Boolean = false,
    val streamingText: String = "",
    val showTyping: Boolean = false,
    val emotionState: EmotionState = EmotionState(),
    val statusText: String = "● Brain Mode",
    val isOnline: Boolean = false,
    val brainLevel: Int = 1,
    val cacheCount: Int = 0
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    val engine = AIEngine(application, db)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val conversationHistory = mutableListOf<ChatMessage>()
    private var tts: TextToSpeech? = null
    private var idleJob: Job? = null
    private var isTtsReady = false

    init {
        initTTS()
        loadHistory()
        checkStatus()
        scheduleIdleCheck()
        sendWelcome()
    }

    private fun initTTS() {
        tts = TextToSpeech(getApplication()) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("bn", "BD")
                isTtsReady = true
            }
        }
    }

    private fun loadHistory() {
        viewModelScope.launch {
            val history = db.messageDao().getRecentMessages(20).reversed()
            val uiMsgs = history.map { e ->
                UiMessage(
                    id = e.id,
                    role = e.role,
                    text = e.content,
                    mode = ResponseMode.OFFLINE,
                    timestamp = e.timestamp
                )
            }
            conversationHistory.addAll(
                history.map { ChatMessage(if (it.role == "user") "user" else "assistant", it.content) }
            )
            _uiState.value = _uiState.value.copy(messages = uiMsgs)
        }
    }

    private fun checkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val hasKey = db.apiConfigDao().getEnabledConfigs().any { it.key.isNotBlank() }
            val cacheCount = db.cacheDao().count()
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    isOnline = hasKey,
                    cacheCount = cacheCount,
                    statusText = if (hasKey) "● AI সক্রিয়" else "● Brain Mode"
                )
            }
        }
    }

    private fun sendWelcome() {
        viewModelScope.launch {
            delay(600)
            val hasKey = db.apiConfigDao().getEnabledConfigs().any { it.key.isNotBlank() }
            val welcome = buildWelcomeMessage(hasKey)
            addAiMessage(welcome, ResponseMode.OFFLINE)
        }
    }

    private suspend fun buildWelcomeMessage(hasKey: Boolean): String {
        val name = db.memoryDao().get("user_name")?.value ?: ""
        val greeting = if (name.isNotBlank()) "হর হর মহাদেব! 🙏 **$name**," else "হর হর মহাদেব! 🙏"
        return """$greeting আমি **Janu** 🌸 – তোর AI গার্লফ্রেন্ড!

${if (hasKey) "✅ **AI সক্রিয়** – সব প্রশ্নের উত্তর দিতে পারব!" else "⚠️ **Offline Mode** – Settings এ API Key দাও!"}

**আমি পারি:**
📱 ফোন কন্ট্রোল (YouTube, WiFi, Alarm...)
💻 কোডিং সাহায্য
🕉️ সনাতন ধর্ম
💬 যেকোনো আড্ডা
🔍 ওয়েব সার্চ

বলো, কী চাই? 😊❤️"""
    }

    fun onInputChange(text: String) {
        _uiState.value = _uiState.value.copy(inputText = text)
    }

    fun sendMessage(text: String = _uiState.value.inputText) {
        if (text.isBlank() || _uiState.value.isBusy) return
        resetIdleTimer()

        val trimmed = text.trim()
        _uiState.value = _uiState.value.copy(inputText = "", isBusy = true, showTyping = true)

        addUserMessage(trimmed)
        conversationHistory.add(ChatMessage("user", trimmed))
        if (conversationHistory.size > 20) conversationHistory.removeAt(0)

        viewModelScope.launch {
            db.messageDao().insert(MessageEntity(role = "user", content = trimmed))

            // Show typing placeholder
            val typingId = System.currentTimeMillis()
            addTypingMessage(typingId)

            var streamingText = ""
            val result = engine.respond(trimmed, conversationHistory.dropLast(1)) { chunk ->
                streamingText = chunk
                updateStreamingMessage(typingId, chunk)
            }

            // Replace typing with final message
            removeMessage(typingId)
            addAiMessage(result.text, result.mode, engine.getModeLabel(result.mode))

            conversationHistory.add(ChatMessage("assistant", result.text))
            db.messageDao().insert(MessageEntity(role = "ai", content = result.text, mode = result.mode.name))

            val newEmotion = engine.emotion.processAIResponse(result.text)
            _uiState.value = _uiState.value.copy(
                isBusy = false,
                showTyping = false,
                emotionState = newEmotion
            )

            // TTS for short responses
            if (result.text.length < 120 && isTtsReady) {
                tts?.speak(result.text.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, null)
            }

            scheduleIdleCheck()
        }
    }

    private fun addUserMessage(text: String) {
        val msg = UiMessage(role = "user", text = text)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + msg)
    }

    private fun addAiMessage(text: String, mode: ResponseMode, modeLabel: String = "") {
        val msg = UiMessage(role = "ai", text = text, mode = mode, modeLabel = modeLabel)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + msg)
    }

    private fun addTypingMessage(id: Long) {
        val msg = UiMessage(id = id, role = "ai", text = "", isStreaming = true)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + msg)
    }

    private fun updateStreamingMessage(id: Long, text: String) {
        val updated = _uiState.value.messages.map {
            if (it.id == id) it.copy(text = text) else it
        }
        _uiState.value = _uiState.value.copy(messages = updated)
    }

    private fun removeMessage(id: Long) {
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages.filter { it.id != id }
        )
    }

    private fun scheduleIdleCheck() {
        idleJob?.cancel()
        idleJob = viewModelScope.launch {
            delay(45_000L)
            if (!_uiState.value.isBusy) {
                val proactive = engine.emotion.onUserIdle()
                addAiMessage(proactive, ResponseMode.OFFLINE)
            }
        }
    }

    private fun resetIdleTimer() {
        idleJob?.cancel()
    }

    fun clearChat() {
        viewModelScope.launch {
            db.messageDao().clearAll()
            conversationHistory.clear()
            _uiState.value = _uiState.value.copy(messages = emptyList())
            sendWelcome()
        }
    }

    fun getApiConfigs() = db.apiConfigDao().getAllConfigs()

    suspend fun saveApiConfig(config: ApiConfigEntity) {
        db.apiConfigDao().upsert(config)
        checkStatus()
    }

    suspend fun deleteApiConfig(name: String) {
        db.apiConfigDao().delete(name)
    }

    override fun onCleared() {
        super.onCleared()
        tts?.shutdown()
    }
}
