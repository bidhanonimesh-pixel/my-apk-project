package com.example

import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShieldProTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF070B14) // Deep space black/blue
                ) { innerPadding ->
                    ShieldDashboard(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun ShieldProTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = Color(0xFF00FFCC),
        onPrimary = Color(0xFF000000),
        background = Color(0xFF070B14),
        surface = Color(0xFF0F1626),
        onSurface = Color.White
    )
    MaterialTheme(
        colorScheme = darkColorScheme,
        content = content
    )
}

@Composable
fun ShieldDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var isAccessibilityEnabled by remember { mutableStateOf(false) }
    var isBatteryOptimizedIgnored by remember { mutableStateOf(false) }
    var isDeviceAdminEnabled by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            isAccessibilityEnabled = checkAccessibilityStatus(context)
            isBatteryOptimizedIgnored = checkBatteryOptimization(context)
            isDeviceAdminEnabled = checkDeviceAdmin(context)
            delay(1000)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header
        Text(
            text = "SHIELD PRO",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 4.sp,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            text = "ULTIMATE PROTECTION ENGINE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00FFCC),
            letterSpacing = 2.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
        )

        // Center Animated Orb
        val infiniteTransition = rememberInfiniteTransition()
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(1500, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            )
        )

        Box(
            modifier = Modifier
                .size(200.dp)
                .scale(pulseScale),
            contentAlignment = Alignment.Center
        ) {
            // Outer glow ring
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF00FFCC).copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        )
                    )
            )
            // Inner solid circle
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF0A182F),
                                Color(0xFF0F264A)
                            )
                        )
                    )
                    .border(2.dp, Color(0xFF00FFCC).copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFF00FFCC),
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Active background defense.",
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Actions
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            
            var showBlockedSitesDialog by remember { mutableStateOf(false) }
            
            if (showBlockedSitesDialog) {
                AlertDialog(
                    onDismissRequest = { showBlockedSitesDialog = false },
                    containerColor = Color(0xFF0F1626),
                    title = { Text("Blocked Threat Database", color = Color(0xFF00FFCC), fontWeight = FontWeight.Bold) },
                    text = { 
                        Text("The following explicit search terms and websites are actively monitored and immediately blocked by the ShieldPro Accessibility Engine:\n\npornhub, xnxx, xvideos, xhamster, brazzers, eporner, spankbang, youporn, redtube, tube8, javhd, rule34, hentai, sex, nhentai, javdo\n\nAdditionally, millions of adult and ad domains are blocked at the network level via the DNS Cloaking Engine.", 
                        color = Color.White) 
                    },
                    confirmButton = {
                        TextButton(onClick = { showBlockedSitesDialog = false }) {
                            Text("CLOSE", color = Color(0xFF00FFCC))
                        }
                    }
                )
            }

            // DNS / Adult Block
            NeonFeatureCard(
                title = "Total Ad & Adult Block",
                subtitle = "Uses Global DNS to block 100% bad sites.",
                icon = Icons.Default.Lock,
                statusColor = Color(0xFF00FFCC),
                isActive = true,
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("DNS", "family.adguard-dns.com")
                    clipboard.setPrimaryClip(clip)
                    
                    Toast.makeText(context, "Copied: family.adguard-dns.com", Toast.LENGTH_LONG).show()
                    val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    try {
                        context.startActivity(intent)
                        Toast.makeText(context, "Go to 'Private DNS', select Private DNS provider hostname, and paste.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {}
                }
            )

            // Auto-Skip Ads (Accessibility)
            NeonFeatureCard(
                title = "Auto-Skip Ads Engine",
                subtitle = "Automatically clicks 'Skip Ad' in videos.",
                icon = Icons.Default.CheckCircle,
                statusColor = if (isAccessibilityEnabled) Color(0xFF00FFCC) else Color(0xFFFF3366),
                isActive = isAccessibilityEnabled,
                onClick = {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    context.startActivity(intent)
                    Toast.makeText(context, "Turn on ShieldPro in Settings", Toast.LENGTH_LONG).show()
                }
            )

            // Battery Optimization Avoidance
            NeonFeatureCard(
                title = "Smart Eco Mode (Battery Health)",
                subtitle = "Monitors background actively while keeping your phone's battery health untouched and cool.",
                icon = Icons.Default.Warning,
                statusColor = if (isBatteryOptimizedIgnored) Color(0xFF00FFCC) else Color(0xFFFFB800),
                isActive = isBatteryOptimizedIgnored,
                onClick = {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = Uri.parse("package:${context.packageName}")
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Could not open Battery Settings.", Toast.LENGTH_SHORT).show()
                    }
                }
            )

            // Uninstall Protection
            NeonFeatureCard(
                title = "Uninstall Protection",
                subtitle = "App locks itself to prevent easy deletion.",
                icon = Icons.Default.Lock,
                statusColor = if (isDeviceAdminEnabled) Color(0xFF00FFCC) else Color(0xFF8A2BE2),
                isActive = isDeviceAdminEnabled,
                onClick = {
                    if (!isDeviceAdminEnabled) {
                        val compName = ComponentName(context, ShieldDeviceAdmin::class.java)
                        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "ShieldPro requires this to prevent unauthorized uninstallation and keep your device ad-free and safe.")
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    } else {
                        Toast.makeText(context, "Protection is already ACTIVE.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            
            // View Database
            NeonFeatureCard(
                title = "View Blocked Sites List",
                subtitle = "See what ShieldPro explicitly blocks.",
                icon = Icons.Default.CheckCircle,
                statusColor = Color(0xFF3B82F6),
                isActive = true,
                onClick = {
                    showBlockedSitesDialog = true
                }
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun NeonFeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    statusColor: Color,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1626)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F2B44))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon space
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(statusColor.copy(alpha = 0.1f))
                    .border(1.dp, statusColor.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = subtitle, color = Color(0xFF8C9DBA), fontSize = 12.sp, lineHeight = 16.sp)
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // Custom Neon Switch
            Box(
                modifier = Modifier
                    .width(44.dp)
                    .height(24.dp)
                    .clip(CircleShape)
                    .background(if (isActive) statusColor.copy(alpha = 0.2f) else Color(0xFF1F2B44))
                    .border(1.dp, if (isActive) statusColor else Color.DarkGray, CircleShape)
                    .padding(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .align(if (isActive) Alignment.CenterEnd else Alignment.CenterStart)
                        .clip(CircleShape)
                        .background(if (isActive) statusColor else Color.Gray)
                        .let {
                            if (isActive) it.border(1.dp, Color.White, CircleShape) else it
                        }
                )
            }
        }
    }
}

// OS Check Functions
fun checkAccessibilityStatus(context: Context): Boolean {
    var accessibilityEnabled = 0
    try {
        accessibilityEnabled = Settings.Secure.getInt(
            context.applicationContext.contentResolver,
            Settings.Secure.ACCESSIBILITY_ENABLED
        )
    } catch (e: Settings.SettingNotFoundException) {
        return false
    }
    if (accessibilityEnabled == 1) {
        val settingValue = Settings.Secure.getString(
            context.applicationContext.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        if (settingValue != null) {
            return settingValue.contains(context.packageName + "/" + ShieldAccessibilityService::class.java.canonicalName)
        }
    }
    return false
}

fun checkBatteryOptimization(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    return pm?.isIgnoringBatteryOptimizations(context.packageName) == true
}

fun checkDeviceAdmin(context: Context): Boolean {
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    val comp = ComponentName(context, ShieldDeviceAdmin::class.java)
    return dpm?.isAdminActive(comp) == true
}
