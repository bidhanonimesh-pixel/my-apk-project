package com.example.shieldpro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

/**
 * ShieldPro v5 — AccessibilityService
 *
 * Fixes vs v4:
 * 1. Schedule lock anti-loop: cooldown prevents Home-spam
 * 2. Ad-skip: smart node traversal, icon/image buttons, content-desc check
 * 3. Battery: only typeWindowStateChanged for most checks; typeWindowContentChanged
 *    only when ad-skip or adult scan is actually needed, with per-pkg throttle
 * 4. No notification — removed foreground notification (user request)
 * 5. False-positive adult fix: biology/medical terms removed; only site-level keywords
 * 6. android:exported removed from manifest for this service — safe
 * 7. Overlay: we NEVER draw overlay; blockContent uses GLOBAL_ACTION_HOME only
 * 8. Home loop guard: 2-second per-package cooldown on blockContent
 * 9. URL filter: browser URL bar scan for blocked domains
 * 10. Custom auto-actions: user-defined label→click rules
 */
class ShieldAccessibilityService : AccessibilityService() {

    private val TAG = "ShieldSvc"

    // ── Built-in ad-skip labels ───────────────────────────────────────────────
    // ONLY specific multi-word phrases — never bare "skip"
    private val adSkipPhrases = listOf(
        "skip ad", "skip ads", "skip video ad", "skip advertisement",
        "close ad", "close ads", "dismiss ad", "remove ad",
        "no thanks", "not interested", "skip intro"
    )

    // Content-descriptions that YouTube/other apps put on the skip button
    // (icon-only buttons — no visible text)
    private val adSkipDescriptions = listOf(
        "skip ad", "skip ads", "skip video", "skip advertisement",
        "close ad", "dismiss ad"
    )

    // ── Adult site domains (exact-domain approach, no generic words) ──────────
    private val builtinAdultDomains = setOf(
        "pornhub", "xnxx", "xvideos", "xhamster", "brazzers", "eporner",
        "spankbang", "youporn", "redtube", "tube8", "javhd", "rule34",
        "nhentai", "javdo", "hentaihaven", "hentai2read", "hanime",
        "aznude", "celebjihad", "fapello", "faphouse", "leakmafia",
        "onlyfans", "chaturbate", "bongacams", "myfreecams",
        "camsoda", "jerkmate", "flirt4free", "livejasmin",
        "sexchat", "adultfriendfinder", "ashleymadison",
        "redgifs", "erothots", "thothub", "simpcity",
        "motherless", "gelbooru", "danbooru", "e621", "paheal",
        "thotsbay", "nudostar",
        // Bengali romanized (site/URL level only)
        "bangla-sex", "bd-sex", "bd-porn", "desi-porn",
        "xxxvideo", "freeporn", "hotporn", "pornsite",
        "adultvideo", "sexvideo", "xxxmovie", "xxxtube",
        // Bengali unicode (URL-encoded won't pass, but raw text in address bar might)
        "বাংলা সেক্স", "চোদাচুদি"
    )

    // Browser package names — for URL bar scanning
    private val browserPkgs = setOf(
        "com.android.chrome", "org.mozilla.firefox", "com.opera.browser",
        "com.microsoft.emmx", "com.brave.browser", "com.sec.android.app.sbrowser",
        "com.UCMobile.intl", "com.opera.mini.native", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.duckduckgo.mobile.android"
    )

    // Reels triggers: pkg → list of URL/text tokens (empty = block whole app)
    private val reelsTriggers = mapOf(
        "com.google.android.youtube"  to listOf("shorts", "#shorts"),
        "com.zhiliaoapp.musically"    to emptyList<String>(),
        "com.ss.android.ugc.trill"   to emptyList<String>(),
        "com.instagram.android"       to listOf("reels", "reel"),
        "com.facebook.katana"         to listOf("reels", "watch"),
        "com.facebook.lite"           to listOf("reels")
    )

    // ── Cooldown state ────────────────────────────────────────────────────────
    private var lastAdultBlock  = 0L
    private var lastAdSkip      = 0L
    private var lastReelBlock   = 0L
    private var lastSchedBlock  = 0L          // FIX: schedule anti-loop
    private val lastBlockPerPkg = HashMap<String, Long>() // FIX: per-pkg home-loop guard

    private val ADULT_CD  = 2_000L
    private val AD_CD     =   700L
    private val REEL_CD   = 2_000L
    private val SCHED_CD  = 3_000L           // min 3 s between schedule-lock HOME presses
    private val PKG_CD    = 2_000L           // per-pkg anti-loop

    // ── App usage timer ───────────────────────────────────────────────────────
    private var fgPackage   = ""
    private var fgStartTime = 0L

    // ── Content-changed throttle per package (battery saving) ─────────────────
    private val lastContentScan = HashMap<String, Long>()
    private val CONTENT_THROTTLE = 800L       // ms between heavy scans per pkg

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences(ShieldConstants.PREF_NAME, MODE_PRIVATE)
        dailyReset()
        // Dynamically set flags — less heavy than XML flagRetrieveInteractiveWindows always
        serviceInfo = serviceInfo?.also { info ->
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            info.notificationTimeout = 600L   // balanced: not too aggressive
        }
        Log.d(TAG, "ShieldPro v5 connected")
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        flushUsage()
    }

    // ── Main event router ─────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            if (event == null) return
            val pkg = event.packageName?.toString() ?: return

            // Skip own UI, system UI, launchers
            if (isSystemOrSelf(pkg)) return

            // Whitelist check
            val whitelist = prefs.getStringSet(ShieldConstants.KEY_WHITELIST, emptySet()) ?: emptySet()
            if (whitelist.contains(pkg)) return

            val evType = event.eventType

            // ── Window state changed: foreground app changed ───────────────
            if (evType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                handleFgChange(pkg)
            }

            // ── Schedule lock (anti-loop protected) ───────────────────────
            if (isScheduleLocked(pkg)) {
                val now = System.currentTimeMillis()
                if (now - lastSchedBlock >= SCHED_CD && !isRecentlyBlocked(pkg, now)) {
                    lastSchedBlock = now
                    markBlocked(pkg, now)
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    inc(ShieldConstants.KEY_ADULT_TODAY, ShieldConstants.KEY_ADULT_TOTAL)
                    showToast("🌙 ShieldPro: Night Lock Active!")
                }
                return
            }

            // ── App timer exceeded ─────────────────────────────────────────
            if (timerExceeded(pkg)) {
                blockContent(pkg, "app_timer", adult = false)
                return
            }

            // ── Content-changed events: throttle heavily ───────────────────
            if (evType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                val now = System.currentTimeMillis()
                val last = lastContentScan[pkg] ?: 0L
                if (now - last < CONTENT_THROTTLE) return
                lastContentScan[pkg] = now
            }

            // ── Reels / Shorts block ───────────────────────────────────────
            if (prefs.getBoolean(ShieldConstants.KEY_REELS_BLOCK, false)
                && isReelsEvent(pkg, event)) {
                blockReels(pkg)
                return
            }

            // ── URL / browser domain block ─────────────────────────────────
            if (pkg in browserPkgs) {
                checkBrowserUrl(pkg)
            }

            // ── Adult keyword scan (text from event only — no full tree walk) ─
            val eventText = combineEventText(event)
            if (eventText.isNotEmpty()) {
                val customAdult = prefs.getStringSet(ShieldConstants.KEY_CUSTOM_ADULT, emptySet()) ?: emptySet()
                val allDomains  = builtinAdultDomains + customAdult
                for (kw in allDomains) {
                    if (eventText.contains(kw, ignoreCase = true)) {
                        blockContent(pkg, kw, adult = true)
                        return
                    }
                }
            }

            // ── Ad-skip ────────────────────────────────────────────────────
            val now = System.currentTimeMillis()
            if (now - lastAdSkip >= AD_CD) {
                trySkipAd(pkg)
            }

            // ── Custom auto-actions ────────────────────────────────────────
            tryCustomActions(pkg)

        } catch (t: Throwable) {
            Log.e(TAG, "Event error", t)
        }
    }

    // ── Smart Ad-Skip ─────────────────────────────────────────────────────────
    // Handles: text nodes, content-description nodes, icon-only buttons

    private fun trySkipAd(pkg: String) {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return
        try {
            // 1. Text-based search
            for (phrase in adSkipPhrases) {
                val nodes = root.findAccessibilityNodeInfosByText(phrase)
                for (node in nodes) {
                    try {
                        val label = node.text?.toString()?.lowercase()?.trim() ?: ""
                        if (isExactAdSkipLabel(label)) {
                            if (tryClickNode(node)) {
                                onAdSkipped(pkg)
                                return
                            }
                        }
                    } finally { try { node.recycle() } catch (_: Exception) {} }
                }
            }

            // 2. Content-description search (icon buttons — YouTube skip)
            for (desc in adSkipDescriptions) {
                if (tryClickByDescription(root, desc)) {
                    onAdSkipped(pkg)
                    return
                }
            }

            // 3. Walk the whole tree looking for skip-like clickable nodes
            //    Only for known video apps to avoid false-positives
            if (isVideoApp(pkg)) {
                if (deepSkipScan(root, pkg)) return
            }

        } catch (e: Exception) {
            Log.e(TAG, "Ad-skip error", e)
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun isExactAdSkipLabel(text: String): Boolean {
        return text == "skip ad" || text == "skip ads" || text == "skip video ad" ||
               text == "skip advertisement" || text == "close ad" || text == "close ads" ||
               text == "dismiss ad" || text == "remove ad" ||
               text == "no thanks" || text == "not interested" ||
               text.startsWith("skip ad") || text.startsWith("close ad")
        // "skip intro" and bare "skip" are intentionally excluded
    }

    private fun tryClickByDescription(root: AccessibilityNodeInfo, desc: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(desc)
        // also check contentDescription attribute
        for (node in nodes) {
            try {
                val cd = node.contentDescription?.toString()?.lowercase()?.trim() ?: ""
                if (cd.contains(desc)) {
                    if (tryClickNode(node)) return true
                }
            } finally { try { node.recycle() } catch (_: Exception) {} }
        }
        // Manual walk for contentDescription (findByText doesn't search contentDesc on all APIs)
        return findAndClickByDesc(root, desc)
    }

    private fun findAndClickByDesc(node: AccessibilityNodeInfo, target: String): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (desc.contains(target) && node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try {
                if (findAndClickByDesc(child, target)) return true
            } finally { try { child.recycle() } catch (_: Exception) {} }
        }
        return false
    }

    /** Deep scan for YouTube-style skip button — has class ImageButton or Button near ad indicator */
    private fun deepSkipScan(root: AccessibilityNodeInfo, pkg: String): Boolean {
        // Look for ad-indicator text nodes first; if found, try siblings/nearby clickables
        val adIndicators = listOf("ad", "advertisement", "sponsored")
        for (indicator in adIndicators) {
            val found = root.findAccessibilityNodeInfosByText(indicator)
            for (node in found) {
                try {
                    val text = node.text?.toString()?.lowercase() ?: ""
                    // Only small "Ad" labels, not content containing "ad"
                    if (text.length <= 15 && text.contains(indicator)) {
                        // Look for a nearby clickable
                        val parent = try { node.parent } catch (_: Exception) { null }
                        if (parent != null) {
                            try {
                                for (i in 0 until parent.childCount) {
                                    val sibling = try { parent.getChild(i) } catch (_: Exception) { null } ?: continue
                                    try {
                                        val sibText = (sibling.text ?: sibling.contentDescription)?.toString()?.lowercase() ?: ""
                                        if ((sibText.contains("skip") || sibText.contains("close"))
                                            && !sibText.contains("comment") && !sibText.contains("description")) {
                                            if (sibling.isClickable) {
                                                val clicked = sibling.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                                if (clicked) { onAdSkipped(pkg); return true }
                                            }
                                        }
                                    } finally { try { sibling.recycle() } catch (_: Exception) {} }
                                }
                            } finally { try { parent.recycle() } catch (_: Exception) {} }
                        }
                    }
                } finally { try { node.recycle() } catch (_: Exception) {} }
            }
        }
        return false
    }

    private fun tryClickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        // Walk up max 3 parents
        var cur: AccessibilityNodeInfo? = try { node.parent } catch (_: Exception) { null }
        var depth = 0
        while (cur != null && depth < 3) {
            if (cur.isClickable) {
                val ok = cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                try { cur.recycle() } catch (_: Exception) {}
                return ok
            }
            val next = try { cur.parent } catch (_: Exception) { null }
            try { cur.recycle() } catch (_: Exception) {}
            cur = next
            depth++
        }
        return false
    }

    private fun onAdSkipped(pkg: String) {
        lastAdSkip = System.currentTimeMillis()
        inc(ShieldConstants.KEY_ADS_TODAY, ShieldConstants.KEY_ADS_TOTAL)
        Log.d(TAG, "Ad skipped in $pkg")
    }

    private fun isVideoApp(pkg: String) =
        pkg.contains("youtube") || pkg.contains("facebook") ||
        pkg.contains("instagram") || pkg.contains("tiktok") ||
        pkg.contains("musically") || pkg.contains("ugc.trill") ||
        pkg.contains("dailymotion") || pkg.contains("vimeo")

    // ── Browser URL filter ────────────────────────────────────────────────────

    private fun checkBrowserUrl(pkg: String) {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        try {
            // URL bars have viewIdResourceName containing "url_bar" or "address_bar"
            val urlText = findUrlBarText(root) ?: return
            val url = urlText.lowercase()
            val customBlock = prefs.getStringSet(ShieldConstants.KEY_URL_BLOCK, emptySet()) ?: emptySet()
            val allBlocked  = builtinAdultDomains + customBlock
            for (kw in allBlocked) {
                if (url.contains(kw, ignoreCase = true)) {
                    blockContent(pkg, kw, adult = true)
                    return
                }
            }
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun findUrlBarText(node: AccessibilityNodeInfo): String? {
        val resId = node.viewIdResourceName ?: ""
        if ((resId.contains("url") || resId.contains("address") || resId.contains("omnibox"))
            && node.text != null) {
            return node.text.toString()
        }
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try {
                val result = findUrlBarText(child)
                if (result != null) return result
            } finally { try { child.recycle() } catch (_: Exception) {} }
        }
        return null
    }

    // ── Custom auto-actions ───────────────────────────────────────────────────
    // Format stored: "label text::package" or "label text::*"

    private fun tryCustomActions(pkg: String) {
        val actions = prefs.getStringSet(ShieldConstants.KEY_AUTO_ACTIONS, emptySet()) ?: return
        if (actions.isEmpty()) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        try {
            for (entry in actions) {
                val parts = entry.split("::")
                if (parts.size != 2) continue
                val label  = parts[0].trim()
                val target = parts[1].trim()
                if (target != "*" && !pkg.contains(target)) continue
                val nodes = root.findAccessibilityNodeInfosByText(label)
                for (node in nodes) {
                    try {
                        val nodeText = node.text?.toString()?.trim() ?: ""
                        if (nodeText.equals(label, ignoreCase = true)) {
                            tryClickNode(node)
                            break
                        }
                    } finally { try { node.recycle() } catch (_: Exception) {} }
                }
            }
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    // ── Content block ─────────────────────────────────────────────────────────

    private fun blockContent(pkg: String, reason: String, adult: Boolean) {
        val now = System.currentTimeMillis()
        val cd  = if (adult) ADULT_CD else AD_CD
        val last = if (adult) lastAdultBlock else lastAdSkip

        if (now - last < cd) return
        if (isRecentlyBlocked(pkg, now)) return   // anti-loop guard

        if (adult) lastAdultBlock = now else lastAdSkip = now
        markBlocked(pkg, now)

        if (adult) inc(ShieldConstants.KEY_ADULT_TODAY, ShieldConstants.KEY_ADULT_TOTAL)
        else       inc(ShieldConstants.KEY_ADS_TODAY,   ShieldConstants.KEY_ADS_TOTAL)

        performGlobalAction(GLOBAL_ACTION_HOME)

        val msg = when (reason) {
            "app_timer" -> "⏱️ ShieldPro: Time Limit Reached!"
            else        -> "🛡️ ShieldPro: Content Blocked!"
        }
        showToast(msg)
    }

    private fun isRecentlyBlocked(pkg: String, now: Long): Boolean {
        val last = lastBlockPerPkg[pkg] ?: 0L
        return now - last < PKG_CD
    }

    private fun markBlocked(pkg: String, now: Long) {
        lastBlockPerPkg[pkg] = now
    }

    // ── Reels / Shorts block ──────────────────────────────────────────────────

    private fun isReelsEvent(pkg: String, event: AccessibilityEvent): Boolean {
        val triggers = reelsTriggers[pkg] ?: return false
        if (triggers.isEmpty()) return true
        val text = combineEventText(event)
        return triggers.any { text.contains(it, ignoreCase = true) }
    }

    private fun blockReels(pkg: String) {
        val now = System.currentTimeMillis()
        if (now - lastReelBlock < REEL_CD) return
        if (isRecentlyBlocked(pkg, now)) return
        lastReelBlock = now
        markBlocked(pkg, now)
        inc(ShieldConstants.KEY_REELS_TODAY, ShieldConstants.KEY_REELS_TOTAL)
        performGlobalAction(GLOBAL_ACTION_HOME)
        showToast("📵 ShieldPro: Reels/Shorts Blocked!")
    }

    // ── Schedule lock ─────────────────────────────────────────────────────────

    private fun isScheduleLocked(pkg: String): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_SCHEDULE_ON, false)) return false
        // Schedule whitelist: certain apps still allowed
        val schedWhitelist = prefs.getStringSet(ShieldConstants.KEY_SCHED_WHITELIST, emptySet()) ?: emptySet()
        if (schedWhitelist.contains(pkg)) return false

        val now   = Calendar.getInstance()
        val nowM  = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val startM = prefs.getInt(ShieldConstants.KEY_SCHED_START_H, 22) * 60 +
                     prefs.getInt(ShieldConstants.KEY_SCHED_START_M, 0)
        val endM   = prefs.getInt(ShieldConstants.KEY_SCHED_END_H, 6) * 60 +
                     prefs.getInt(ShieldConstants.KEY_SCHED_END_M, 0)
        // Midnight-wrap support (e.g. 22:00–06:00)
        return if (startM > endM) nowM >= startM || nowM < endM
               else               nowM in startM until endM
    }

    // ── App timer ─────────────────────────────────────────────────────────────

    private fun handleFgChange(pkg: String) {
        if (pkg == fgPackage) return
        flushUsage()
        fgPackage   = pkg
        fgStartTime = System.currentTimeMillis()
    }

    private fun flushUsage() {
        if (fgPackage.isEmpty() || fgStartTime == 0L) return
        val elapsed = System.currentTimeMillis() - fgStartTime
        val key     = usageKey(fgPackage) ?: return
        prefs.edit().putLong(key, prefs.getLong(key, 0) + elapsed).apply()
        fgStartTime = 0L
    }

    private fun usageKey(pkg: String): String? = when {
        pkg.contains("youtube")   -> ShieldConstants.KEY_USE_YT_TODAY
        pkg.contains("tiktok") || pkg.contains("musically") || pkg.contains("ugc.trill")
                                  -> ShieldConstants.KEY_USE_TT_TODAY
        pkg.contains("instagram") -> ShieldConstants.KEY_USE_IG_TODAY
        pkg.contains("facebook")  -> ShieldConstants.KEY_USE_FB_TODAY
        else                      -> null
    }

    private fun timerExceeded(pkg: String): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_APP_TIMER_ON, false)) return false
        val (limitKey, useKey) = when {
            pkg.contains("youtube")   -> ShieldConstants.KEY_TIMER_YT_MINS to ShieldConstants.KEY_USE_YT_TODAY
            pkg.contains("tiktok") || pkg.contains("musically") || pkg.contains("ugc.trill") ->
                ShieldConstants.KEY_TIMER_TT_MINS to ShieldConstants.KEY_USE_TT_TODAY
            pkg.contains("instagram") -> ShieldConstants.KEY_TIMER_IG_MINS to ShieldConstants.KEY_USE_IG_TODAY
            pkg.contains("facebook")  -> ShieldConstants.KEY_TIMER_FB_MINS to ShieldConstants.KEY_USE_FB_TODAY
            else -> return false
        }
        val limitMs = prefs.getInt(limitKey, 0) * 60_000L
        if (limitMs == 0L) return false
        // Include current foreground session time not yet flushed
        val flushedMs = prefs.getLong(useKey, 0)
        val liveMs    = if (pkg == fgPackage) System.currentTimeMillis() - fgStartTime else 0L
        return (flushedMs + liveMs) >= limitMs
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun isSystemOrSelf(pkg: String) =
        pkg == packageName ||
        pkg.contains("systemui") ||
        pkg.contains("launcher") ||
        pkg.contains("inputmethod")

    private fun combineEventText(event: AccessibilityEvent): String {
        val t = event.text?.joinToString(" ") ?: ""
        val d = event.contentDescription?.toString() ?: ""
        return "$t $d".trim().lowercase()
    }

    private fun inc(todayKey: String, totalKey: String) {
        prefs.edit()
            .putInt(todayKey, prefs.getInt(todayKey, 0) + 1)
            .putInt(totalKey, prefs.getInt(totalKey, 0) + 1)
            .apply()
    }

    private fun showToast(msg: String) {
        mainHandler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun dailyReset() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (prefs.getString(ShieldConstants.KEY_LAST_RESET, "") == today) return
        prefs.edit()
            .putString(ShieldConstants.KEY_LAST_RESET, today)
            .putInt(ShieldConstants.KEY_ADS_TODAY, 0)
            .putInt(ShieldConstants.KEY_ADULT_TODAY, 0)
            .putInt(ShieldConstants.KEY_REELS_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_YT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_TT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_IG_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_FB_TODAY, 0)
            .apply()
    }
}
