package com.example.shieldpro

import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.security.MessageDigest

// ── Colours ───────────────────────────────────────────────────────────────────
private val Cyan   = Color(0xFF00FFCC)
private val Purple = Color(0xFF8A2BE2)
private val Red    = Color(0xFFFF3366)
private val Amber  = Color(0xFFFFB800)
private val BgDark = Color(0xFF060614)
private val BgMid  = Color(0xFF0B142E)
private val BgCard = Color.White.copy(alpha = 0.04f)

enum class Screen { HOME, STATS, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ShieldProTheme { MainApp() } }
    }
}

@Composable
fun ShieldProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary    = Cyan,
            onPrimary  = Color.Black,
            background = BgDark,
            surface    = BgMid,
            onSurface  = Color.White
        ),
        content = content
    )
}

private fun hashPin(pin: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) }
}

@Composable
fun MainApp() {
    val ctx   = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(ShieldConstants.PREF_NAME, Context.MODE_PRIVATE) }
    var screen        by remember { mutableStateOf(Screen.HOME) }
    var authenticated by remember { mutableStateOf(false) }
    val pinEnabled = prefs.getBoolean(ShieldConstants.KEY_PIN_ENABLED, false)

    AppBackground {
        if (pinEnabled && !authenticated) {
            PinLockScreen(prefs) { authenticated = true }
        } else {
            Scaffold(
                modifier       = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                bottomBar      = { GlassNav(screen) { screen = it } }
            ) { pad ->
                AnimatedContent(
                    targetState  = screen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label        = "screen"
                ) { s ->
                    when (s) {
                        Screen.HOME     -> HomeScreen(Modifier.padding(pad), prefs)
                        Screen.STATS    -> StatsScreen(Modifier.padding(pad), prefs)
                        Screen.SETTINGS -> SettingsScreen(Modifier.padding(pad), prefs)
                    }
                }
            }
        }
    }
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0A1A), BgMid, Color(0xFF041528))))
    ) {
        Box(Modifier.offset((-60).dp, (-60).dp).size(220.dp).background(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.12f), Color.Transparent)), CircleShape))
        Box(Modifier.align(Alignment.TopEnd).offset(60.dp, 120.dp).size(280.dp).background(
            Brush.radialGradient(listOf(Purple.copy(alpha = 0.12f), Color.Transparent)), CircleShape))
        content()
    }
}

// ── Bottom Nav ────────────────────────────────────────────────────────────────

@Composable
fun GlassNav(current: Screen, onSelect: (Screen) -> Unit) {
    Box(
        Modifier.navigationBarsPadding().fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp).height(68.dp)
            .clip(RoundedCornerShape(34.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(34.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically) {
            NavItem(Icons.Default.Lock,  "Home",     current == Screen.HOME)     { onSelect(Screen.HOME) }
            NavItem(Icons.Default.Star,  "Stats",    current == Screen.STATS)    { onSelect(Screen.STATS) }
            NavItem(Icons.Default.Build, "Settings", current == Screen.SETTINGS) { onSelect(Screen.SETTINGS) }
        }
    }
}

@Composable
fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape)
            .background(if (selected) Cyan.copy(alpha = 0.18f) else Color.Transparent),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (selected) Cyan else Color.Gray, modifier = Modifier.size(22.dp))
        }
        Text(label, fontSize = 10.sp, color = if (selected) Cyan else Color.Gray)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// HOME SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun HomeScreen(modifier: Modifier, prefs: SharedPreferences) {
    val ctx = LocalContext.current
    var accessOk  by remember { mutableStateOf(false) }
    var batteryOk by remember { mutableStateOf(false) }
    var adminOk   by remember { mutableStateOf(false) }
    var adsToday  by remember { mutableStateOf(0) }
    var adultToday by remember { mutableStateOf(0) }
    var reelsToday by remember { mutableStateOf(0) }

    val lco = LocalLifecycleOwner.current
    DisposableEffect(lco) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME) {
                accessOk   = checkAccess(ctx)
                batteryOk  = checkBattery(ctx)
                adminOk    = checkAdmin(ctx)
                adsToday   = prefs.getInt(ShieldConstants.KEY_ADS_TODAY, 0)
                adultToday = prefs.getInt(ShieldConstants.KEY_ADULT_TODAY, 0)
                reelsToday = prefs.getInt(ShieldConstants.KEY_REELS_TODAY, 0)
            }
        }
        lco.lifecycle.addObserver(obs)
        onDispose { lco.lifecycle.removeObserver(obs) }
    }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Text("SHIELD PRO", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
            color = Color.White, letterSpacing = 5.sp)
        Text("ULTIMATE CYBER DEFENSE", fontSize = 11.sp, fontWeight = FontWeight.Bold,
            color = Cyan, letterSpacing = 3.sp)
        Spacer(Modifier.height(28.dp))

        // Shield circle
        Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().clip(CircleShape)
                .background(Brush.radialGradient(listOf(Cyan.copy(0.18f), Color.Transparent))))
            Box(Modifier.fillMaxSize().clip(CircleShape)
                .border(1.dp, Cyan.copy(0.3f), CircleShape))
            Box(Modifier.size(130.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF081C17), Color(0xFF093144))))
                .border(2.dp, Brush.linearGradient(listOf(Cyan, Purple)), CircleShape),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(52.dp))
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatPill("$adsToday Ads", Cyan)
            StatPill("$adultToday Adult", Red)
            StatPill("$reelsToday Reels", Purple)
        }
        Spacer(Modifier.height(8.dp))
        Text("Blocked Today", fontSize = 12.sp, color = Color.White.copy(0.5f))
        Spacer(Modifier.height(28.dp))

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            GlassCard("DNS Firewall", "family.adguard-dns.com — blocks millions of bad sites",
                Icons.Default.Lock, Cyan, true) {
                val clip = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("dns", "family.adguard-dns.com"))
                Toast.makeText(ctx, "Copied! Paste in Private DNS settings", Toast.LENGTH_LONG).show()
                try { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (_: Exception) {}
            }
            GlassCard("Auto-Skip Engine", "Tap ads, skips them in milliseconds",
                Icons.Default.CheckCircle, if (accessOk) Cyan else Red, accessOk) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(ctx, "Enable ShieldPro in Accessibility", Toast.LENGTH_LONG).show()
            }
            GlassCard("Smart Eco Mode", "Keeps ShieldPro alive without draining battery",
                Icons.Default.Warning, if (batteryOk) Cyan else Amber, batteryOk) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .apply { data = Uri.parse("package:${ctx.packageName}") })
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Battery settings → ShieldPro → Unrestricted", Toast.LENGTH_LONG).show()
                }
            }
            GlassCard("Uninstall Protection", "Prevents unauthorized removal",
                Icons.Default.Lock, if (adminOk) Cyan else Purple, adminOk) {
                if (!adminOk) {
                    val comp = ComponentName(ctx, ShieldDeviceAdmin::class.java)
                    ctx.startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Prevents unauthorised removal of ShieldPro.")
                    })
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun StatPill(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// STATS SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun StatsScreen(modifier: Modifier, prefs: SharedPreferences) {
    var adsToday   by remember { mutableStateOf(0) }
    var adultToday by remember { mutableStateOf(0) }
    var reelsToday by remember { mutableStateOf(0) }
    var adsTotal   by remember { mutableStateOf(0) }
    var adultTotal by remember { mutableStateOf(0) }
    var reelsTotal by remember { mutableStateOf(0) }
    var ytMs by remember { mutableStateOf(0L) }
    var ttMs by remember { mutableStateOf(0L) }
    var igMs by remember { mutableStateOf(0L) }
    var fbMs by remember { mutableStateOf(0L) }

    val lco = LocalLifecycleOwner.current
    DisposableEffect(lco) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME) {
                adsToday   = prefs.getInt(ShieldConstants.KEY_ADS_TODAY, 0)
                adultToday = prefs.getInt(ShieldConstants.KEY_ADULT_TODAY, 0)
                reelsToday = prefs.getInt(ShieldConstants.KEY_REELS_TODAY, 0)
                adsTotal   = prefs.getInt(ShieldConstants.KEY_ADS_TOTAL, 0)
                adultTotal = prefs.getInt(ShieldConstants.KEY_ADULT_TOTAL, 0)
                reelsTotal = prefs.getInt(ShieldConstants.KEY_REELS_TOTAL, 0)
                ytMs = prefs.getLong(ShieldConstants.KEY_USE_YT_TODAY, 0)
                ttMs = prefs.getLong(ShieldConstants.KEY_USE_TT_TODAY, 0)
                igMs = prefs.getLong(ShieldConstants.KEY_USE_IG_TODAY, 0)
                fbMs = prefs.getLong(ShieldConstants.KEY_USE_FB_TODAY, 0)
            }
        }
        lco.lifecycle.addObserver(obs)
        onDispose { lco.lifecycle.removeObserver(obs) }
    }

    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(20.dp))
        ScreenHeader("Statistics", Icons.Default.Star)

        SectionLabel("Today's Blocks")
        val todayMax = maxOf(adsToday, adultToday, reelsToday, 1)
        StatBar("Ads Skipped",          adsToday,   todayMax, Cyan,   Icons.Default.CheckCircle)
        StatBar("Adult Blocked",        adultToday, todayMax, Red,    Icons.Default.Lock)
        StatBar("Reels/Shorts Blocked", reelsToday, todayMax, Purple, Icons.Default.Block)

        Spacer(Modifier.height(8.dp))
        SectionLabel("Lifetime Totals")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TotalCard("Ads\nSkipped",   adsTotal,   Cyan,   Modifier.weight(1f))
            TotalCard("Adult\nBlocked", adultTotal, Red,    Modifier.weight(1f))
            TotalCard("Reels\nBlocked", reelsTotal, Purple, Modifier.weight(1f))
        }

        Spacer(Modifier.height(8.dp))
        SectionLabel("App Screen Time Today")
        UsageBar("YouTube",   ytMs, Cyan)
        UsageBar("TikTok",    ttMs, Red)
        UsageBar("Instagram", igMs, Purple)
        UsageBar("Facebook",  fbMs, Amber)

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun StatBar(label: String, value: Int, maxVal: Int, color: Color, icon: ImageVector) {
    val frac = if (maxVal == 0) 0f else value.toFloat() / maxVal
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp))
        .background(BgCard).border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(16.dp)).padding(16.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("$value", color = color, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(0.1f))) {
                Box(Modifier.fillMaxWidth(frac).height(6.dp).clip(RoundedCornerShape(3.dp))
                    .background(Brush.horizontalGradient(listOf(color.copy(0.6f), color))))
            }
        }
    }
}

@Composable
fun TotalCard(label: String, value: Int, color: Color, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(BgCard)
        .border(1.dp, color.copy(0.3f), RoundedCornerShape(16.dp)).padding(16.dp),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", color = color, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text(label, color = Color.White.copy(0.6f), fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 15.sp)
        }
    }
}

@Composable
fun UsageBar(app: String, ms: Long, color: Color) {
    val mins    = ms / 60_000
    val hrs     = mins / 60
    val rem     = mins % 60
    val display = if (hrs > 0) "${hrs}h ${rem}m" else "${mins}m"
    Box(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
        .background(BgCard).border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(14.dp))
        .padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(app, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(display, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun SettingsScreen(modifier: Modifier, prefs: SharedPreferences) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(20.dp))
        ScreenHeader("Settings", Icons.Default.Build)
        SectionCustomKeywords(prefs)
        SectionWhitelist(prefs)
        SectionPinLock(prefs)
        SectionSchedule(prefs)      // ← has proper TimePicker now
        SectionReels(prefs)
        SectionAppTimer(prefs)
        SectionAutoActions(prefs)   // ← new: custom click actions
        SectionUrlBlock(prefs)      // ← new: URL domain block
        Spacer(Modifier.height(40.dp))
    }
}

// ── Custom Keywords ───────────────────────────────────────────────────────────
@Composable
fun SectionCustomKeywords(prefs: SharedPreferences) {
    var keywords by remember {
        mutableStateOf(prefs.getStringSet(ShieldConstants.KEY_CUSTOM_ADULT, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var input by remember { mutableStateOf("") }

    SectionLabel("Custom Block Keywords")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Add your own keywords to the adult block list:", color = Color.White.copy(0.7f), fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Enter keyword…", color = Color.Gray) },
                    colors = textFieldColors(), modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(12.dp))
                IconButton(onClick = {
                    val kw = input.trim().lowercase()
                    if (kw.isNotEmpty()) {
                        keywords = (keywords + kw).toMutableSet()
                        prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_ADULT, keywords).apply()
                        input = ""
                    }
                }) { Icon(Icons.Default.Add, null, tint = Cyan) }
            }
            if (keywords.isEmpty()) {
                Text("No custom keywords yet.", color = Color.White.copy(0.4f), fontSize = 12.sp)
            } else {
                keywords.toList().forEach { kw ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(0.05f)).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("🚫  $kw", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Close, null, tint = Red, modifier = Modifier.size(18.dp).clickable {
                            keywords = (keywords - kw).toMutableSet()
                            prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_ADULT, keywords).apply()
                        })
                    }
                }
            }
        }
    }
}

// ── Whitelist ─────────────────────────────────────────────────────────────────
@Composable
fun SectionWhitelist(prefs: SharedPreferences) {
    var list  by remember {
        mutableStateOf(prefs.getStringSet(ShieldConstants.KEY_WHITELIST, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var input by remember { mutableStateOf("") }

    SectionLabel("App Whitelist")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Excluded apps won't be scanned (e.g. com.google.maps):", color = Color.White.copy(0.7f), fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Package name…", color = Color.Gray) },
                    colors = textFieldColors(), modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(12.dp))
                IconButton(onClick = {
                    val pkg = input.trim()
                    if (pkg.isNotEmpty()) {
                        list = (list + pkg).toMutableSet()
                        prefs.edit().putStringSet(ShieldConstants.KEY_WHITELIST, list).apply()
                        input = ""
                    }
                }) { Icon(Icons.Default.Add, null, tint = Cyan) }
            }
            if (list.isEmpty()) {
                Text("No whitelisted apps.", color = Color.White.copy(0.4f), fontSize = 12.sp)
            } else {
                list.toList().forEach { pkg ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(0.05f)).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("✅  $pkg", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Close, null, tint = Red, modifier = Modifier.size(18.dp).clickable {
                            list = (list - pkg).toMutableSet()
                            prefs.edit().putStringSet(ShieldConstants.KEY_WHITELIST, list).apply()
                        })
                    }
                }
            }
        }
    }
}

// ── PIN Lock ──────────────────────────────────────────────────────────────────
@Composable
fun SectionPinLock(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_PIN_ENABLED, false)) }
    var showSet by remember { mutableStateOf(false) }
    var pin1    by remember { mutableStateOf("") }
    var pin2    by remember { mutableStateOf("") }
    var error   by remember { mutableStateOf("") }
    val ctx = LocalContext.current

    SectionLabel("PIN Lock")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PIN Lock", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (enabled) "App protected — PIN required to open" else "Tap to set a PIN",
                        color = Color.White.copy(0.6f), fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = { on ->
                    if (on) showSet = true
                    else { enabled = false; prefs.edit().putBoolean(ShieldConstants.KEY_PIN_ENABLED, false).apply() }
                }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(0.3f)))
            }
            if (showSet) {
                OutlinedTextField(pin1, { pin1 = it.take(6) },
                    label = { Text("New PIN", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true, colors = textFieldColors(), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pin2, { pin2 = it.take(6) },
                    label = { Text("Confirm PIN", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true, colors = textFieldColors(), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth())
                if (error.isNotEmpty()) Text(error, color = Red, fontSize = 12.sp)
                Button(onClick = {
                    when {
                        pin1.length < 4 -> error = "PIN must be at least 4 digits"
                        pin1 != pin2    -> error = "PINs do not match"
                        else -> {
                            prefs.edit()
                                .putString(ShieldConstants.KEY_PIN_HASH, hashPin(pin1))
                                .putBoolean(ShieldConstants.KEY_PIN_ENABLED, true).apply()
                            enabled = true; showSet = false; pin1 = ""; pin2 = ""; error = ""
                            Toast.makeText(ctx, "PIN set!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = Cyan), modifier = Modifier.fillMaxWidth()) {
                    Text("Save PIN", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            if (enabled && !showSet) {
                TextButton(onClick = { showSet = true; pin1 = ""; pin2 = ""; error = "" }) {
                    Text("Change PIN", color = Cyan)
                }
            }
        }
    }
}

// ── Schedule Lock — with proper Time Picker ───────────────────────────────────
@Composable
fun SectionSchedule(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_SCHEDULE_ON, false)) }
    var startH  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_START_H, 22)) }
    var startM  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_START_M, 0)) }
    var endH    by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_END_H, 6)) }
    var endM    by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_END_M, 0)) }

    // Which picker is open: "start" | "end" | null
    var pickerOpen by remember { mutableStateOf<String?>(null) }

    fun save() = prefs.edit()
        .putBoolean(ShieldConstants.KEY_SCHEDULE_ON, enabled)
        .putInt(ShieldConstants.KEY_SCHED_START_H, startH)
        .putInt(ShieldConstants.KEY_SCHED_START_M, startM)
        .putInt(ShieldConstants.KEY_SCHED_END_H, endH)
        .putInt(ShieldConstants.KEY_SCHED_END_M, endM).apply()

    SectionLabel("Schedule Lock (Night Mode)")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto Lock", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Full block during set hours", color = Color.White.copy(0.6f), fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = { enabled = it; save() },
                    colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(0.3f)))
            }

            if (enabled) {
                // ── Start time picker ─────────────────────────────────────────
                Text("🌙 Lock Starts At", color = Color.White.copy(0.85f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                TimePickerRow(
                    hour   = startH,
                    minute = startM,
                    color  = Amber,
                    onHourChange   = { startH = it; save() },
                    onMinuteChange = { startM = it; save() }
                )

                HorizontalDivider(color = Color.White.copy(0.08f))

                // ── End time picker ───────────────────────────────────────────
                Text("☀️ Unlock At", color = Color.White.copy(0.85f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                TimePickerRow(
                    hour   = endH,
                    minute = endM,
                    color  = Cyan,
                    onHourChange   = { endH = it; save() },
                    onMinuteChange = { endM = it; save() }
                )

                // Summary badge
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                    .background(Amber.copy(0.12f)).padding(12.dp)) {
                    Text("⏰ Locked: %02d:%02d – %02d:%02d".format(startH, startM, endH, endM),
                        color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Inline time picker row — hour scrollable (0–23) + minute scrollable (0–59)
 * Uses +/- buttons for reliable UX without requiring TimePickerDialog (API 23+)
 */
@Composable
fun TimePickerRow(
    hour: Int, minute: Int, color: Color,
    onHourChange: (Int) -> Unit, onMinuteChange: (Int) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(color.copy(0.08f)).padding(8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        // Hour stepper
        SpinnerColumn(
            value   = hour,
            min     = 0,
            max     = 23,
            label   = "HH",
            color   = color,
            onChange = onHourChange
        )
        Text(":", color = color, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 8.dp))
        // Minute stepper
        SpinnerColumn(
            value   = minute,
            min     = 0,
            max     = 59,
            label   = "MM",
            color   = color,
            onChange = onMinuteChange
        )
    }
}

@Composable
fun SpinnerColumn(value: Int, min: Int, max: Int, label: String, color: Color, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onChange(if (value >= max) min else value + 1) }) {
            Icon(Icons.Default.KeyboardArrowUp, null, tint = color, modifier = Modifier.size(28.dp))
        }
        Box(
            Modifier.size(64.dp, 44.dp).clip(RoundedCornerShape(8.dp))
                .background(color.copy(0.15f)).border(1.dp, color.copy(0.4f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("%02d".format(value), color = color, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        IconButton(onClick = { onChange(if (value <= min) max else value - 1) }) {
            Icon(Icons.Default.KeyboardArrowDown, null, tint = color, modifier = Modifier.size(28.dp))
        }
    }
}

// ── Reels Block ───────────────────────────────────────────────────────────────
@Composable
fun SectionReels(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_BLOCK, false)) }

    SectionLabel("Reels / Shorts / TikTok Block")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Block Reels & Shorts", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it; prefs.edit().putBoolean(ShieldConstants.KEY_REELS_BLOCK, it).apply()
                }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(0.3f)))
            }
            HorizontalDivider(color = Color.White.copy(0.08f))
            Text("When ON, all these are blocked:", color = Color.White.copy(0.55f), fontSize = 12.sp)
            listOf("YouTube Shorts", "TikTok (entire app)", "Instagram Reels", "Facebook Reels/Watch").forEach {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(if (enabled) Cyan else Color.Gray))
                    Spacer(Modifier.width(8.dp))
                    Text(it, color = if (enabled) Color.White else Color.Gray, fontSize = 13.sp)
                }
            }
        }
    }
}

// ── App Timer ─────────────────────────────────────────────────────────────────
@Composable
fun SectionAppTimer(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_APP_TIMER_ON, false)) }
    var ytMins  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_YT_MINS, 60).toFloat()) }
    var ttMins  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_TT_MINS, 30).toFloat()) }
    var igMins  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_IG_MINS, 45).toFloat()) }
    var fbMins  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_FB_MINS, 45).toFloat()) }

    SectionLabel("App Screen Time Limit")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("App Timer", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Auto-block after daily limit", color = Color.White.copy(0.6f), fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it; prefs.edit().putBoolean(ShieldConstants.KEY_APP_TIMER_ON, it).apply()
                }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(0.3f)))
            }
            if (enabled) {
                TimerSlider("YouTube",   ytMins, Cyan)   { ytMins = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_YT_MINS, it.toInt()).apply() }
                TimerSlider("TikTok",    ttMins, Red)    { ttMins = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_TT_MINS, it.toInt()).apply() }
                TimerSlider("Instagram", igMins, Purple) { igMins = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_IG_MINS, it.toInt()).apply() }
                TimerSlider("Facebook",  fbMins, Amber)  { fbMins = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_FB_MINS, it.toInt()).apply() }
            }
        }
    }
}

@Composable
fun TimerSlider(app: String, value: Float, color: Color, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(app, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("${value.toInt()} min/day", color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = 10f..300f, steps = 28,
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color))
    }
}

// ── Custom Auto-Actions (NEW) ─────────────────────────────────────────────────
@Composable
fun SectionAutoActions(prefs: SharedPreferences) {
    var actions by remember {
        mutableStateOf(prefs.getStringSet(ShieldConstants.KEY_AUTO_ACTIONS, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var labelInput by remember { mutableStateOf("") }
    var pkgInput   by remember { mutableStateOf("") }

    SectionLabel("Custom Auto-Click Actions")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Define button labels to auto-click. Leave package as * for all apps.",
                color = Color.White.copy(0.7f), fontSize = 13.sp
            )
            OutlinedTextField(
                value = labelInput, onValueChange = { labelInput = it },
                placeholder = { Text("Button label (e.g. \"Close\")", color = Color.Gray) },
                colors = textFieldColors(), modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pkgInput, onValueChange = { pkgInput = it },
                    placeholder = { Text("Package or *", color = Color.Gray) },
                    colors = textFieldColors(), modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(12.dp))
                IconButton(onClick = {
                    val lbl = labelInput.trim()
                    val pkg = pkgInput.trim().ifEmpty { "*" }
                    if (lbl.isNotEmpty()) {
                        val entry = "$lbl::$pkg"
                        actions = (actions + entry).toMutableSet()
                        prefs.edit().putStringSet(ShieldConstants.KEY_AUTO_ACTIONS, actions).apply()
                        labelInput = ""; pkgInput = ""
                    }
                }) { Icon(Icons.Default.Add, null, tint = Cyan) }
            }
            if (actions.isEmpty()) {
                Text("No auto-actions yet.", color = Color.White.copy(0.4f), fontSize = 12.sp)
            } else {
                actions.toList().forEach { entry ->
                    val parts = entry.split("::")
                    val lbl   = parts.getOrElse(0) { entry }
                    val pkg   = parts.getOrElse(1) { "*" }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(0.05f)).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("🖱️ $lbl", color = Color.White, fontSize = 13.sp)
                            Text("App: $pkg", color = Color.Gray, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Close, null, tint = Red, modifier = Modifier.size(18.dp).clickable {
                            actions = (actions - entry).toMutableSet()
                            prefs.edit().putStringSet(ShieldConstants.KEY_AUTO_ACTIONS, actions).apply()
                        })
                    }
                }
            }
        }
    }
}

// ── URL / Domain Block (NEW) ──────────────────────────────────────────────────
@Composable
fun SectionUrlBlock(prefs: SharedPreferences) {
    var domains by remember {
        mutableStateOf(prefs.getStringSet(ShieldConstants.KEY_URL_BLOCK, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var input by remember { mutableStateOf("") }

    SectionLabel("Browser URL Block (Extra Domains)")
    SettingsCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Add extra domain keywords to block in Chrome/Firefox/etc:",
                color = Color.White.copy(0.7f), fontSize = 13.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("e.g. badsite.com", color = Color.Gray) },
                    colors = textFieldColors(), modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(12.dp))
                IconButton(onClick = {
                    val d = input.trim().lowercase()
                    if (d.isNotEmpty()) {
                        domains = (domains + d).toMutableSet()
                        prefs.edit().putStringSet(ShieldConstants.KEY_URL_BLOCK, domains).apply()
                        input = ""
                    }
                }) { Icon(Icons.Default.Add, null, tint = Cyan) }
            }
            if (domains.isEmpty()) {
                Text("No extra domains. Built-in list is always active.", color = Color.White.copy(0.4f), fontSize = 12.sp)
            } else {
                domains.toList().forEach { d ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(0.05f)).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("🌐  $d", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Close, null, tint = Red, modifier = Modifier.size(18.dp).clickable {
                            domains = (domains - d).toMutableSet()
                            prefs.edit().putStringSet(ShieldConstants.KEY_URL_BLOCK, domains).apply()
                        })
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PIN LOCK SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun PinLockScreen(prefs: SharedPreferences, onUnlock: () -> Unit) {
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val storedHash = prefs.getString(ShieldConstants.KEY_PIN_HASH, "") ?: ""

    AppBackground {
        Column(
            Modifier.fillMaxSize().padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Lock, null, tint = Cyan, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(12.dp))
            Text("SHIELD PRO", fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
            Text("Enter your PIN", fontSize = 14.sp, color = Color.White.copy(0.6f))
            Spacer(Modifier.height(32.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(4) { i ->
                    Box(Modifier.size(18.dp).clip(CircleShape)
                        .background(if (i < entry.length) Cyan else Color.White.copy(0.2f)))
                }
            }
            if (error) {
                Spacer(Modifier.height(8.dp))
                Text("Incorrect PIN", color = Red, fontSize = 13.sp)
            }
            Spacer(Modifier.height(28.dp))

            val keys = listOf(
                listOf("1","2","3"), listOf("4","5","6"),
                listOf("7","8","9"), listOf("","0","⌫")
            )
            keys.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    row.forEach { k ->
                        Box(Modifier.size(72.dp).clip(CircleShape)
                            .background(if (k.isEmpty()) Color.Transparent else Color.White.copy(0.08f))
                            .border(if (k.isEmpty()) 0.dp else 1.dp, Color.White.copy(0.12f), CircleShape)
                            .clickable(enabled = k.isNotEmpty()) {
                                when (k) {
                                    "⌫" -> if (entry.isNotEmpty()) entry = entry.dropLast(1)
                                    else -> {
                                        if (entry.length < 6) entry += k
                                        if (entry.length == 4 || entry.length == 6) {
                                            if (hashPin(entry) == storedHash) onUnlock()
                                            else { error = true; entry = "" }
                                        }
                                    }
                                }
                            }, contentAlignment = Alignment.Center) {
                            if (k.isNotEmpty()) Text(k, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHARED COMPOSABLES
// ═══════════════════════════════════════════════════════════════════════════════

@Composable
fun ScreenHeader(title: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 20.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 2.sp)
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
fun SettingsCard(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(BgCard)
        .border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(20.dp)).padding(16.dp)) { content() }
}

@Composable
fun GlassCard(title: String, subtitle: String, icon: ImageVector, color: Color, active: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BgCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(0.08f))) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp))
                .background(color.copy(0.15f)).border(1.dp, color.copy(0.35f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Color.White.copy(0.55f), fontSize = 12.sp, lineHeight = 16.sp)
            }
            Spacer(Modifier.width(10.dp))
            Box(Modifier.width(44.dp).height(24.dp).clip(CircleShape)
                .background(if (active) color.copy(0.2f) else Color.White.copy(0.1f))
                .border(1.dp, if (active) color else Color.White.copy(0.15f), CircleShape).padding(3.dp)) {
                Box(Modifier.size(16.dp).align(if (active) Alignment.CenterEnd else Alignment.CenterStart)
                    .clip(CircleShape).background(if (active) color else Color.Gray))
            }
        }
    }
}

@Composable
fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = Cyan,
    unfocusedBorderColor = Color.White.copy(0.2f),
    focusedTextColor     = Color.White,
    unfocusedTextColor   = Color.White,
    cursorColor          = Cyan
)

// ── Utility ───────────────────────────────────────────────────────────────────

fun checkAccess(ctx: Context): Boolean {
    val enabled = try {
        Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED)
    } catch (_: Exception) { return false }
    if (enabled != 1) return false
    val services = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return services.contains("${ctx.packageName}/${ShieldAccessibilityService::class.java.canonicalName}")
}

fun checkBattery(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
    return pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true
}

fun checkAdmin(ctx: Context): Boolean {
    val dpm  = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    val comp = ComponentName(ctx, ShieldDeviceAdmin::class.java)
    return dpm?.isAdminActive(comp) == true
}
