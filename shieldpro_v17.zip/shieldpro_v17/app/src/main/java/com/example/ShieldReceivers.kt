package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.app.admin.DeviceAdminReceiver

// ── Boot Receiver ─────────────────────────────────────────────────────────────
class ShieldBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("ShieldBoot", "Boot received: ${intent.action}")
        // Accessibility service OS automatically restarts if enabled
        // But schedule a watchdog alarm just in case
        scheduleWatchdog(context)
    }
}

// ── FIX 3: Restart Receiver — security/boost apps kill করলে restart হবে ──────
class ShieldRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("ShieldRestart", "Restart signal received — rescheduling watchdog")
        scheduleWatchdog(context)
    }
}

// ── Watchdog Alarm Receiver — 60s পর পর check করে ───────────────────────────
class ShieldWatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("ShieldWatchdog", "Watchdog tick — service keepalive")
        // Schedule next watchdog
        scheduleWatchdog(context)
    }
}

// ── Helper: 60 second watchdog alarm set করো ─────────────────────────────────
fun scheduleWatchdog(context: Context) {
    try {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ShieldWatchdogReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, 0x5AFE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // 60 seconds later
        alarmMgr.set(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 60_000L,
            pi
        )
    } catch (e: Exception) {
        Log.e("ShieldWatchdog", "Failed to schedule watchdog", e)
    }
}

// ── Device Admin Receiver ─────────────────────────────────────────────────────
class ShieldDeviceAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("ShieldAdmin", "Device Admin Enabled — uninstall protection active")
        scheduleWatchdog(context)
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Warning: Disabling this will remove ShieldPro's protection. Are you sure?"
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.d("ShieldAdmin", "Device Admin Disabled")
    }
}
