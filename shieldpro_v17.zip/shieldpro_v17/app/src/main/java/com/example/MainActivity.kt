package com.example

import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.security.MessageDigest

// ── Color tokens ──────────────────────────────────────────────────────────────
private val Cyan   = Color(0xFF00FFCC)
private val Purple = Color(0xFF8A2BE2)
private val Red    = Color(0xFFFF3366)
private val Amber  = Color(0xFFFFB800)
private val Blue   = Color(0xFF3B82F6)
private val BgCard = Color.White.copy(alpha = 0.04f)

// ── Screens ───────────────────────────────────────────────────────────────────
enum class Screen { HOME, STATS, SETTINGS }

// ── Activity ──────────────────────────────────────────────────────────────────
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ShieldTheme { RootApp() } }
    }
}

@Composable
fun ShieldTheme(c: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary   = Cyan, onPrimary = Color.Black,
            background = Color(0xFF060614), surface = Color(0xFF0B142E), onSurface = Color.White
        ), content = c
    )
}

fun hashPin(pin: String): String {
    val b = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
    return b.joinToString("") { "%02x".format(it) }
}

// ── Root ──────────────────────────────────────────────────────────────────────
@Composable
fun RootApp() {
    val ctx   = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(ShieldConstants.PREF_NAME, Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var authed by remember { mutableStateOf(false) }
    val pinOn  = prefs.getBoolean(ShieldConstants.KEY_PIN_ENABLED, false)

    AppBg {
        if (pinOn && !authed) {
            PinScreen(prefs) { authed = true }
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(), containerColor = Color.Transparent,
                bottomBar = { BottomNav(screen) { screen = it } }
            ) { pad ->
                AnimatedContent(screen, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "nav") { s ->
                    when (s) {
                        Screen.HOME     -> HomeScreen(Modifier.padding(pad), prefs)
                        Screen.STATS    -> StatsScreen(Modifier.padding(pad), prefs)
                        Screen.SETTINGS -> SettingsScreen(Modifier.padding(pad), prefs)
                    }
                }
            }
        }
    }
}

@Composable
fun AppBg(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
        listOf(Color(0xFF0B0A1A), Color(0xFF0B142E), Color(0xFF041528))
    ))) {
        Box(Modifier.offset((-60).dp, (-60).dp).size(220.dp).background(
            Brush.radialGradient(listOf(Cyan.copy(.1f), Color.Transparent)), CircleShape))
        Box(Modifier.align(Alignment.TopEnd).offset(60.dp,120.dp).size(280.dp).background(
            Brush.radialGradient(listOf(Purple.copy(.1f), Color.Transparent)), CircleShape))
        content()
    }
}

// ── Bottom Nav ────────────────────────────────────────────────────────────────
@Composable
fun BottomNav(cur: Screen, sel: (Screen) -> Unit) {
    Box(
        Modifier.navigationBarsPadding().fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp).height(66.dp)
            .clip(RoundedCornerShape(33.dp)).background(Color.White.copy(.06f))
            .border(1.dp, Color.White.copy(.1f), RoundedCornerShape(33.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            NavItm(Icons.Default.Lock,  "Home",     cur == Screen.HOME)     { sel(Screen.HOME) }
            NavItm(Icons.Default.Star,  "Stats",    cur == Screen.STATS)    { sel(Screen.STATS) }
            NavItm(Icons.Default.Build, "Settings", cur == Screen.SETTINGS) { sel(Screen.SETTINGS) }
        }
    }
}

@Composable
fun NavItm(icon: ImageVector, lbl: String, sel: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(40.dp).clip(CircleShape)
            .background(if (sel) Cyan.copy(.18f) else Color.Transparent),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (sel) Cyan else Color.Gray, modifier = Modifier.size(21.dp))
        }
        Text(lbl, fontSize = 10.sp, color = if (sel) Cyan else Color.Gray)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// HOME SCREEN
// ══════════════════════════════════════════════════════════════════════════════
@Composable
fun HomeScreen(modifier: Modifier, prefs: SharedPreferences) {
    val ctx = LocalContext.current
    var accOk  by remember { mutableStateOf(false) }
    var batOk  by remember { mutableStateOf(false) }
    var admOk  by remember { mutableStateOf(false) }
    var adsT   by remember { mutableStateOf(0) }
    var adtT   by remember { mutableStateOf(0) }
    var reeT   by remember { mutableStateOf(0) }

    val lco = LocalLifecycleOwner.current
    DisposableEffect(lco) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME) {
                accOk = checkAccess(ctx); batOk = checkBattery(ctx); admOk = checkAdmin(ctx)
                adsT = prefs.getInt(ShieldConstants.KEY_ADS_TODAY, 0)
                adtT = prefs.getInt(ShieldConstants.KEY_ADULT_TODAY, 0)
                reeT = prefs.getInt(ShieldConstants.KEY_REELS_TODAY, 0)
            }
        }
        lco.lifecycle.addObserver(obs)
        onDispose { lco.lifecycle.removeObserver(obs) }
    }

    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Text("SHIELD PRO", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
            color = Color.White, letterSpacing = 5.sp)
        Text("ULTIMATE CYBER DEFENSE", fontSize = 11.sp, color = Cyan, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        // Shield
        Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(
                Brush.radialGradient(listOf(Cyan.copy(.15f), Color.Transparent))))
            Box(Modifier.fillMaxSize().clip(CircleShape).border(1.dp, Cyan.copy(.3f), CircleShape))
            Box(Modifier.size(120.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF081C17), Color(0xFF093144))))
                .border(2.dp, Brush.linearGradient(listOf(Cyan, Purple)), CircleShape),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("$adsT Ads",     Cyan)
            Pill("$adtT Adult",   Red)
            Pill("$reeT Reels",   Purple)
        }
        Text("Blocked Today", fontSize = 11.sp, color = Color.White.copy(.45f),
            modifier = Modifier.padding(top = 4.dp, bottom = 22.dp))

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // DNS
            GCard("DNS Firewall", "family.adguard-dns.com — network-level block",
                Icons.Default.Lock, Cyan, true) {
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("dns", "family.adguard-dns.com"))
                Toast.makeText(ctx, "Copied! Paste in Private DNS setting", Toast.LENGTH_LONG).show()
                try { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (e: Exception) {}
            }
            GCard("Auto-Skip Engine", "Detects & clicks Skip Ad in milliseconds",
                Icons.Default.CheckCircle, if (accOk) Cyan else Red, accOk) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(ctx, "Enable ShieldPro in Accessibility", Toast.LENGTH_LONG).show()
            }
            GCard("Smart Eco Mode", "Keeps ShieldPro alive without battery drain",
                Icons.Default.BatteryFull, if (batOk) Cyan else Amber, batOk) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .apply { data = Uri.parse("package:${ctx.packageName}") })
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Battery → ShieldPro → Unrestricted", Toast.LENGTH_LONG).show()
                }
            }
            GCard("Uninstall Protection", "Prevents unauthorized removal of ShieldPro",
                Icons.Default.Security, if (admOk) Cyan else Purple, admOk) {
                if (!admOk) ctx.startActivity(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                            ComponentName(ctx, ShieldDeviceAdmin::class.java))
                        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Prevents unauthorised removal of ShieldPro.")
                    })
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(color.copy(.14f))
        .border(1.dp, color.copy(.4f), RoundedCornerShape(20.dp))
        .padding(horizontal = 12.dp, vertical = 5.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// STATS SCREEN
// ══════════════════════════════════════════════════════════════════════════════
@Composable
fun StatsScreen(modifier: Modifier, prefs: SharedPreferences) {
    var adsT by remember { mutableStateOf(0) }; var adtT by remember { mutableStateOf(0) }
    var reeT by remember { mutableStateOf(0) }; var adsA by remember { mutableStateOf(0) }
    var adtA by remember { mutableStateOf(0) }; var reeA by remember { mutableStateOf(0) }
    var ytMs by remember { mutableStateOf(0L) }; var ttMs by remember { mutableStateOf(0L) }
    var igMs by remember { mutableStateOf(0L) }; var fbMs by remember { mutableStateOf(0L) }

    val lco = LocalLifecycleOwner.current
    DisposableEffect(lco) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME) {
                adsT = prefs.getInt(ShieldConstants.KEY_ADS_TODAY,   0)
                adtT = prefs.getInt(ShieldConstants.KEY_ADULT_TODAY,  0)
                reeT = prefs.getInt(ShieldConstants.KEY_REELS_TODAY,  0)
                adsA = prefs.getInt(ShieldConstants.KEY_ADS_TOTAL,   0)
                adtA = prefs.getInt(ShieldConstants.KEY_ADULT_TOTAL,  0)
                reeA = prefs.getInt(ShieldConstants.KEY_REELS_TOTAL,  0)
                ytMs = prefs.getLong(ShieldConstants.KEY_USE_YT_TODAY, 0)
                ttMs = prefs.getLong(ShieldConstants.KEY_USE_TT_TODAY, 0)
                igMs = prefs.getLong(ShieldConstants.KEY_USE_IG_TODAY, 0)
                fbMs = prefs.getLong(ShieldConstants.KEY_USE_FB_TODAY, 0)
            }
        }
        lco.lifecycle.addObserver(obs)
        onDispose { lco.lifecycle.removeObserver(obs) }
    }

    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(20.dp))
        ScrHdr("Statistics", Icons.Default.Star)

        // Today bars
        SecLabel("Today's Blocks")
        val mx = maxOf(adsT, adtT, reeT, 1)
        StatBar("Ads Skipped",    adsT, mx, Cyan,   Icons.Default.CheckCircle)
        StatBar("Adult Blocked",  adtT, mx, Red,    Icons.Default.Block)
        StatBar("Reels Blocked",  reeT, mx, Purple,  Icons.Default.VideocamOff)

        // Totals
        SecLabel("Lifetime Totals")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TotCard("Ads",   adsA, Cyan,   Modifier.weight(1f))
            TotCard("Adult", adtA, Red,    Modifier.weight(1f))
            TotCard("Reels", reeA, Purple, Modifier.weight(1f))
        }

        // Screen time
        SecLabel("App Screen Time Today")
        UsageBar("YouTube",   ytMs, Cyan)
        UsageBar("TikTok",    ttMs, Red)
        UsageBar("Instagram", igMs, Purple)
        UsageBar("Facebook",  fbMs, Amber)

        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun StatBar(label: String, v: Int, mx: Int, color: Color, icon: ImageVector) {
    val f = if (mx == 0) 0f else v.toFloat() / mx
    Box(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
        .background(BgCard).border(1.dp, Color.White.copy(.07f), RoundedCornerShape(14.dp)).padding(14.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = color, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(8.dp))
                Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    modifier = Modifier.weight(1f))
                Text("$v", color = color, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
            Spacer(Modifier.height(7.dp))
            Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(.1f))) {
                Box(Modifier.fillMaxWidth(f).height(5.dp).clip(RoundedCornerShape(3.dp))
                    .background(Brush.horizontalGradient(listOf(color.copy(.5f), color))))
            }
        }
    }
}

@Composable
fun TotCard(label: String, v: Int, color: Color, mod: Modifier) {
    Box(mod.clip(RoundedCornerShape(14.dp)).background(BgCard)
        .border(1.dp, color.copy(.3f), RoundedCornerShape(14.dp)).padding(14.dp),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$v", color = color, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Color.White.copy(.55f), fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun UsageBar(app: String, ms: Long, color: Color) {
    val mins = ms / 60_000
    val display = if (mins >= 60) "${mins/60}h ${mins%60}m" else "${mins}m"
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp))
        .background(BgCard).border(1.dp, Color.White.copy(.07f), RoundedCornerShape(12.dp))
        .padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Text(app, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(display, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// SETTINGS SCREEN
// ══════════════════════════════════════════════════════════════════════════════
@Composable
fun SettingsScreen(modifier: Modifier, prefs: SharedPreferences) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(20.dp))
        ScrHdr("Settings", Icons.Default.Build)

        SecAdSkip(prefs)
        SecAdultBlock(prefs)
        SecReels(prefs)
        SecCustomKeywords(prefs)
        SecAutoPress(prefs)
        SecWhitelist(prefs)
        SecPinLock(prefs)
        SecSchedule(prefs)
        SecAppTimer(prefs)

        Spacer(Modifier.height(40.dp))
    }
}

// ── Custom Block Keywords ─────────────────────────────────────────────────────
@Composable
fun SecCustomKeywords(prefs: SharedPreferences) {
    var kws by remember {
        mutableStateOf<MutableSet<String>>(prefs.getStringSet(ShieldConstants.KEY_CUSTOM_ADULT, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var inp by remember { mutableStateOf("") }

    SecLabel("Custom Block Keywords")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Add your own adult keywords to block list (min 4 chars):",
                color = Color.White.copy(.65f), fontSize = 12.sp)
            AddRow(inp, "Enter keyword…", { inp = it }) {
                val k = inp.trim().lowercase()
                if (k.length >= 4) {
                    kws = (kws + k).toMutableSet()
                    prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_ADULT, kws).apply()
                    inp = ""
                }
            }
            ChipList(kws.toList()) { removed ->
                kws = (kws - removed).toMutableSet()
                prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_ADULT, kws).apply()
            }
        }
    }
}

// ── Custom Auto-Press ─────────────────────────────────────────────────────────
@Composable
fun SecAutoPress(prefs: SharedPreferences) {
    var targets by remember {
        mutableStateOf<MutableSet<String>>(prefs.getStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var inp by remember { mutableStateOf("") }

    SecLabel("Custom Auto-Press Targets")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("যে button এর text দেখলে auto-click করবে। e.g. 'Allow', 'Got it', 'Skip', 'Later'.\nCase-insensitive, partial match কাজ করে।",
                color = Color.White.copy(.65f), fontSize = 12.sp, lineHeight = 16.sp)
            AddRow(inp, "Button text (e.g. Allow)…", { inp = it }) {
                val k = inp.trim()
                if (k.isNotEmpty()) {
                    targets = (targets + k).toMutableSet()
                    prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, targets).apply()
                    inp = ""
                }
            }
            if (targets.isEmpty()) {
                Text("No targets added. ❌ icon দিয়ে remove করুন।", color = Color.White.copy(.35f), fontSize = 12.sp)
            } else {
                targets.toList().forEach { t ->
                    ChipRow("👆  $t") {
                        targets = (targets - t).toMutableSet()
                        prefs.edit().putStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, targets).apply()
                    }
                }
            }
        }
    }
}

// ── Whitelist ─────────────────────────────────────────────────────────────────
@Composable
fun SecWhitelist(prefs: SharedPreferences) {
    var wl  by remember {
        mutableStateOf<MutableSet<String>>(prefs.getStringSet(ShieldConstants.KEY_WHITELIST, emptySet())?.toMutableSet() ?: mutableSetOf())
    }
    var inp by remember { mutableStateOf("") }

    SecLabel("App Whitelist")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Package names to exclude from scanning (e.g. com.google.maps):",
                color = Color.White.copy(.65f), fontSize = 12.sp)
            AddRow(inp, "Package name…", { inp = it }) {
                val k = inp.trim()
                if (k.isNotEmpty()) {
                    wl = (wl + k).toMutableSet()
                    prefs.edit().putStringSet(ShieldConstants.KEY_WHITELIST, wl).apply()
                    inp = ""
                }
            }
            ChipList(wl.toList(), prefix = "✅  ") { removed ->
                wl = (wl - removed).toMutableSet()
                prefs.edit().putStringSet(ShieldConstants.KEY_WHITELIST, wl).apply()
            }
        }
    }
}

// ── PIN Lock ──────────────────────────────────────────────────────────────────
@Composable
fun SecPinLock(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_PIN_ENABLED, false)) }
    var showSet by remember { mutableStateOf(false) }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val ctx = LocalContext.current

    SecLabel("PIN Lock")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PIN Lock", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (enabled) "PIN required to open app" else "Disabled — tap switch to set",
                        color = Color.White.copy(.55f), fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = { on ->
                    if (on) showSet = true
                    else { enabled = false; prefs.edit().putBoolean(ShieldConstants.KEY_PIN_ENABLED, false).apply() }
                }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f)))
            }
            if (showSet) {
                OutlinedTextField(p1, { p1 = it.take(6) }, label = { Text("New PIN (4–6 digits)", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(), singleLine = true,
                    colors = tfColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(p2, { p2 = it.take(6) }, label = { Text("Confirm PIN", color = Color.Gray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(), singleLine = true,
                    colors = tfColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth())
                if (err.isNotEmpty()) Text(err, color = Red, fontSize = 12.sp)
                Button(onClick = {
                    when {
                        p1.length < 4  -> err = "PIN must be 4–6 digits"
                        p1 != p2       -> err = "PINs do not match"
                        else -> {
                            prefs.edit().putString(ShieldConstants.KEY_PIN_HASH, hashPin(p1))
                                .putBoolean(ShieldConstants.KEY_PIN_ENABLED, true).apply()
                            enabled = true; showSet = false; p1 = ""; p2 = ""; err = ""
                            Toast.makeText(ctx, "PIN set successfully!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                    modifier = Modifier.fillMaxWidth()) {
                    Text("Save PIN", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            if (enabled && !showSet) {
                TextButton(onClick = { showSet = true; p1 = ""; p2 = ""; err = "" }) {
                    Text("Change PIN", color = Cyan)
                }
            }
        }
    }
}

// ── Schedule Lock — with native TimePickerDialog ──────────────────────────────
@Composable
fun SecSchedule(prefs: SharedPreferences) {
    var enabled by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_SCHEDULE_ON, false)) }
    var sH by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_START_H, 22)) }
    var sM by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_START_M, 0)) }
    var eH by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_END_H, 6)) }
    var eM by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_SCHED_END_M, 0)) }
    val ctx = LocalContext.current

    fun save() = prefs.edit()
        .putBoolean(ShieldConstants.KEY_SCHEDULE_ON, enabled)
        .putInt(ShieldConstants.KEY_SCHED_START_H, sH).putInt(ShieldConstants.KEY_SCHED_START_M, sM)
        .putInt(ShieldConstants.KEY_SCHED_END_H,   eH).putInt(ShieldConstants.KEY_SCHED_END_M,   eM)
        .apply()

    SecLabel("Schedule Lock (Night Mode)")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto Lock", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Fully blocks phone during set hours", color = Color.White.copy(.55f), fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = { enabled = it; save() },
                    colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f)))
            }
            if (enabled) {
                // ── Two time-picker buttons (native Android dialog) ────────
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TimeBtn("🔒 Lock Start", sH, sM, Red, Modifier.weight(1f)) { h, m ->
                        sH = h; sM = m; save()
                    }
                    TimeBtn("🔓 Unlock At", eH, eM, Cyan, Modifier.weight(1f)) { h, m ->
                        eH = h; eM = m; save()
                    }
                }
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                    .background(Amber.copy(.1f)).padding(12.dp)) {
                    Text("⏰ Lock: %02d:%02d  →  Unlock: %02d:%02d".format(sH, sM, eH, eM),
                        color = Amber, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Text("(Midnight-wrap supported — e.g. 22:00 → 06:00)",
                    color = Color.White.copy(.4f), fontSize = 11.sp)
            }
        }
    }
}

/** Tappable time display that opens Android's native TimePickerDialog */
@Composable
fun TimeBtn(label: String, h: Int, m: Int, color: Color, mod: Modifier, onPick: (Int, Int) -> Unit) {
    val ctx = LocalContext.current
    Box(
        mod.clip(RoundedCornerShape(14.dp)).background(color.copy(.1f))
            .border(1.dp, color.copy(.35f), RoundedCornerShape(14.dp))
            .clickable {
                TimePickerDialog(ctx, { _, ph, pm -> onPick(ph, pm) }, h, m, true).show()
            }
            .padding(14.dp)
    ) {
        Column {
            Text(label, color = color.copy(.8f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text("%02d:%02d".format(h, m), color = color, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        }
    }
}

// ── Ad Skip — per app ─────────────────────────────────────────────────────────
@Composable
fun SecAdSkip(prefs: SharedPreferences) {
    var on    by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_ON, true)) }
    var yt    by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_YT, true)) }
    var fb    by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_FB, true)) }
    var insta by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_INSTA, true)) }
    var brow  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_BROWSER, true)) }
    var other by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_OTHER, true)) }

    fun save() = prefs.edit()
        .putBoolean(ShieldConstants.KEY_AD_SKIP_ON, on)
        .putBoolean(ShieldConstants.KEY_AD_SKIP_YT, yt)
        .putBoolean(ShieldConstants.KEY_AD_SKIP_FB, fb)
        .putBoolean(ShieldConstants.KEY_AD_SKIP_INSTA, insta)
        .putBoolean(ShieldConstants.KEY_AD_SKIP_BROWSER, brow)
        .putBoolean(ShieldConstants.KEY_AD_SKIP_OTHER, other)
        .apply()

    SecLabel("Ad Auto-Skip")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            MasterSwitch("Ad Auto-Skip", "Detects & clicks Skip Ad automatically", Cyan, on) {
                on = it; save()
            }
            if (on) {
                HorizontalDivider(color = Color.White.copy(.07f), modifier = Modifier.padding(vertical = 6.dp))
                AppSwitchRow("▶  YouTube", yt, Cyan) { yt = it; save() }
                AppSwitchRow("📘  Facebook", fb, Blue) { fb = it; save() }
                AppSwitchRow("📸  Instagram", insta, Purple) { insta = it; save() }
                AppSwitchRow("🌐  Browsers", brow, Amber) { brow = it; save() }
                AppSwitchRow("📱  Other Apps", other, Color.Gray) { other = it; save() }
            }
        }
    }
}

// ── Adult Block — per app ─────────────────────────────────────────────────────
@Composable
fun SecAdultBlock(prefs: SharedPreferences) {
    var on    by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_ON, true)) }
    var brow  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_BROWSER, true)) }
    var yt    by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_YT, true)) }
    var other by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_OTHER, true)) }

    fun save() = prefs.edit()
        .putBoolean(ShieldConstants.KEY_ADULT_BLOCK_ON, on)
        .putBoolean(ShieldConstants.KEY_ADULT_BLOCK_BROWSER, brow)
        .putBoolean(ShieldConstants.KEY_ADULT_BLOCK_YT, yt)
        .putBoolean(ShieldConstants.KEY_ADULT_BLOCK_OTHER, other)
        .apply()

    SecLabel("Adult Content Block")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            MasterSwitch("Adult Block", "Blocks harmful & adult content", Red, on) {
                on = it; save()
            }
            if (on) {
                HorizontalDivider(color = Color.White.copy(.07f), modifier = Modifier.padding(vertical = 6.dp))
                AppSwitchRow("🌐  Browsers (URL block)", brow, Amber) { brow = it; save() }
                AppSwitchRow("▶  YouTube", yt, Red) { yt = it; save() }
                AppSwitchRow("📱  Other Apps", other, Color.Gray) { other = it; save() }
            }
        }
    }
}

// ── Reels Block — per app ─────────────────────────────────────────────────────
@Composable
fun SecReels(prefs: SharedPreferences) {
    var on  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_BLOCK, false)) }
    var yt  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_YT, true)) }
    var tt  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_TT, true)) }
    var ig  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_IG, true)) }
    var fb  by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_REELS_FB, true)) }

    fun save() = prefs.edit()
        .putBoolean(ShieldConstants.KEY_REELS_BLOCK, on)
        .putBoolean(ShieldConstants.KEY_REELS_YT, yt)
        .putBoolean(ShieldConstants.KEY_REELS_TT, tt)
        .putBoolean(ShieldConstants.KEY_REELS_IG, ig)
        .putBoolean(ShieldConstants.KEY_REELS_FB, fb)
        .apply()

    SecLabel("Reels / Shorts Block")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            MasterSwitch("Block Short-form Video", "Instantly exits when Reels/Shorts detected", Purple, on) {
                on = it; save()
            }
            if (on) {
                HorizontalDivider(color = Color.White.copy(.07f), modifier = Modifier.padding(vertical = 6.dp))
                AppSwitchRow("▶  YouTube Shorts", yt, Red) { yt = it; save() }
                AppSwitchRow("🎵  TikTok (entire app)", tt, Color(0xFF00F2EA)) { tt = it; save() }
                AppSwitchRow("📸  Instagram Reels", ig, Purple) { ig = it; save() }
                AppSwitchRow("📘  Facebook Reels", fb, Blue) { fb = it; save() }
            }
        }
    }
}

// ── App Timer ─────────────────────────────────────────────────────────────────
@Composable
fun SecAppTimer(prefs: SharedPreferences) {
    var on   by remember { mutableStateOf(prefs.getBoolean(ShieldConstants.KEY_APP_TIMER_ON, false)) }
    var ytM  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_YT_MINS, 60).toFloat()) }
    var ttM  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_TT_MINS, 30).toFloat()) }
    var igM  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_IG_MINS, 45).toFloat()) }
    var fbM  by remember { mutableStateOf(prefs.getInt(ShieldConstants.KEY_TIMER_FB_MINS, 45).toFloat()) }

    SecLabel("App Screen Time Limit")
    SCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("App Timer", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Auto-block when daily limit reached", color = Color.White.copy(.55f), fontSize = 12.sp)
                }
                Switch(checked = on, onCheckedChange = { on = it; prefs.edit().putBoolean(ShieldConstants.KEY_APP_TIMER_ON, it).apply() },
                    colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Cyan.copy(.3f)))
            }
            if (on) {
                TSlider("YouTube",   ytM, Cyan)   { ytM = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_YT_MINS, it.toInt()).apply() }
                TSlider("TikTok",    ttM, Red)    { ttM = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_TT_MINS, it.toInt()).apply() }
                TSlider("Instagram", igM, Purple) { igM = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_IG_MINS, it.toInt()).apply() }
                TSlider("Facebook",  fbM, Amber)  { fbM = it; prefs.edit().putInt(ShieldConstants.KEY_TIMER_FB_MINS, it.toInt()).apply() }
            }
        }
    }
}

@Composable
fun TSlider(app: String, v: Float, color: Color, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(app, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("${v.toInt()} min/day", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Slider(v, onChange, valueRange = 10f..300f, steps = 28,
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color))
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// PIN SCREEN
// ══════════════════════════════════════════════════════════════════════════════
@Composable
fun PinScreen(prefs: SharedPreferences, onUnlock: () -> Unit) {
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val hash = prefs.getString(ShieldConstants.KEY_PIN_HASH, "") ?: ""

    AppBg {
        Column(Modifier.fillMaxSize().padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Lock, null, tint = Cyan, modifier = Modifier.size(60.dp))
            Spacer(Modifier.height(10.dp))
            Text("SHIELD PRO", fontSize = 22.sp, color = Color.White,
                fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
            Text("Enter PIN to continue", fontSize = 13.sp, color = Color.White.copy(.55f))
            Spacer(Modifier.height(28.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(4) { i ->
                    Box(Modifier.size(16.dp).clip(CircleShape)
                        .background(if (i < entry.length) Cyan else Color.White.copy(.2f)))
                }
            }
            if (error) { Spacer(Modifier.height(6.dp)); Text("Incorrect PIN", color = Red, fontSize = 12.sp) }
            Spacer(Modifier.height(26.dp))

            val rows = listOf(listOf("1","2","3"), listOf("4","5","6"), listOf("7","8","9"), listOf("","0","⌫"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { k ->
                        Box(Modifier.size(70.dp).clip(CircleShape)
                            .background(if (k.isEmpty()) Color.Transparent else Color.White.copy(.08f))
                            .border(if (k.isEmpty()) 0.dp else 1.dp, Color.White.copy(.1f), CircleShape)
                            .clickable(enabled = k.isNotEmpty()) {
                                when (k) {
                                    "⌫" -> if (entry.isNotEmpty()) entry = entry.dropLast(1)
                                    else -> {
                                        if (entry.length < 6) {
                                            entry += k
                                            if (entry.length >= 4 && hashPin(entry) == hash) { onUnlock(); return@clickable }
                                            if (entry.length == 6 && hashPin(entry) != hash) { error = true; entry = "" }
                                        }
                                    }
                                }
                            }, contentAlignment = Alignment.Center) {
                            if (k.isNotEmpty()) Text(k, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// SHARED COMPOSABLES
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun ScrHdr(title: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 18.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 2.sp)
    }
}

@Composable
fun SecLabel(text: String) {
    Text(text, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
}

@Composable
fun SCard(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(BgCard)
        .border(1.dp, Color.White.copy(.07f), RoundedCornerShape(18.dp)).padding(14.dp)) { content() }
}

@Composable
fun GCard(title: String, sub: String, icon: ImageVector, color: Color, active: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BgCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.07f))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(color.copy(.14f))
                .border(1.dp, color.copy(.35f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(3.dp))
                Text(sub, color = Color.White.copy(.5f), fontSize = 12.sp, lineHeight = 15.sp)
            }
            Spacer(Modifier.width(10.dp))
            Box(Modifier.width(42.dp).height(22.dp).clip(CircleShape)
                .background(if (active) color.copy(.2f) else Color.White.copy(.1f))
                .border(1.dp, if (active) color else Color.White.copy(.15f), CircleShape)
                .padding(3.dp)) {
                Box(Modifier.size(14.dp).align(if (active) Alignment.CenterEnd else Alignment.CenterStart)
                    .clip(CircleShape).background(if (active) color else Color.Gray))
            }
        }
    }
}

@Composable
fun AddRow(value: String, ph: String, onChange: (String) -> Unit, onAdd: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value, onChange, placeholder = { Text(ph, color = Color.Gray) },
            colors = tfColors(), modifier = Modifier.weight(1f), singleLine = true,
            shape = RoundedCornerShape(12.dp))
        IconButton(onClick = onAdd) { Icon(Icons.Default.Add, null, tint = Cyan) }
    }
}

@Composable
fun ChipList(items: List<String>, prefix: String = "🚫  ", onRemove: (String) -> Unit) {
    if (items.isEmpty()) {
        Text("None added yet.", color = Color.White.copy(.35f), fontSize = 12.sp)
    } else {
        items.forEach { ChipRow("$prefix$it") { onRemove(it) } }
    }
}

@Composable
fun ChipRow(label: String, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(Color.White.copy(.05f))
        .padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Default.Close, null, tint = Red,
            modifier = Modifier.size(17.dp).clickable(onClick = onRemove))
    }
}

@Composable
fun tfColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = Color.White.copy(.2f),
    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan
)

// ── Master toggle row ─────────────────────────────────────────────────────────
@Composable
fun MasterSwitch(title: String, sub: String, color: Color, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = Color.White.copy(.55f), fontSize = 12.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor  = color,
                checkedTrackColor  = color.copy(.3f),
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = Color.White.copy(.1f)
            )
        )
    }
}

// ── Per-app sub-toggle row ────────────────────────────────────────────────────
@Composable
fun AppSwitchRow(label: String, checked: Boolean, color: Color, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(.03f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = if (checked) Color.White else Color.White.copy(.4f),
            fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor   = color,
                checkedTrackColor   = color.copy(.25f),
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = Color.White.copy(.08f)
            )
        )
    }
}

// ── OS check functions ────────────────────────────────────────────────────────
fun checkAccess(ctx: Context): Boolean {
    val en = try { Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED) }
             catch (e: Exception) { return false }
    if (en != 1) return false
    val svcs = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return svcs.contains("${ctx.packageName}/${ShieldAccessibilityService::class.java.canonicalName}")
}

fun checkBattery(ctx: Context): Boolean =
    (ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager)
        ?.isIgnoringBatteryOptimizations(ctx.packageName) == true

fun checkAdmin(ctx: Context): Boolean {
    val dpm  = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    val comp = ComponentName(ctx, ShieldDeviceAdmin::class.java)
    return dpm?.isAdminActive(comp) == true
}
